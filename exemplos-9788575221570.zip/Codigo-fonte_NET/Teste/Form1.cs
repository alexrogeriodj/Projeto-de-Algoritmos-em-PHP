using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// Biblioteca utilizada na conex�o ODBC
using System.Data.Odbc;

namespace Teste
{
    public partial class Form1 : Form
    {
        // Vari�veis globais de conex�o
        string myConnectionString = "driver={PostgreSQL ANSI};"
            + " Server=localhost; uid=root; pwd=*******; database=INTEGRACAO";
        OdbcConnection myConn;
        OdbcCommand myCmd = new OdbcCommand();

        public Form1()
        {
            InitializeComponent();

            // Cria a conex�o ODBC
            myConn = new OdbcConnection(myConnectionString);
            myCmd.Connection = myConn;

            AtualizaDados();
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Atualiza os campos do formul�rio baseado na linha selecionada no Grid
            textBoxID.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBoxAUTOR.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxLIVRO.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxEDITORA.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        public void AtualizaDados()
        {
            // Abre e realiza uma consulta SQL
            StringBuilder SQL = new StringBuilder();
            SQL.Append("SELECT * FROM LIVROS");
            myCmd.CommandText = SQL.ToString();
            myConn.Open();

            // Armazena o resultado
            OdbcDataReader result = myCmd.ExecuteReader(CommandBehavior.CloseConnection);

            // Organiza a forma de apresenta��o dos dados via DataTable
            DataTable dt = new DataTable("Resultado");
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("AUTOR", typeof(String));
            dt.Columns.Add("LIVRO", typeof(String));
            dt.Columns.Add("EDITORA", typeof(String));

            // Para cada linha de retorno, adiciona no DataTable
            DataRow dr;
            while (result.Read())
            {
                // Cria uma nova linha do tipo DataRow
                dr = dt.NewRow();

                // Insere todos os campos do registro
                dr["ID"] = result.GetInt32(result.GetOrdinal("ID"));
                dr["AUTOR"] = result.GetString(result.GetOrdinal("AUTOR"));
                dr["LIVRO"] = result.GetString(result.GetOrdinal("LIVRO"));
                dr["EDITORA"] = result.GetString(result.GetOrdinal("EDITORA"));

                // Adiciona a linha DataRow no objeto DataTable
                dt.Rows.Add(dr);
            }

            // Converte o DataTable para o DataGrid
            dataGridView.DataSource = dt.DefaultView;

            // Encerra a conex�o
            myConn.Close();

            // Limpa os campos do formul�rio caso tenham sido utilizados
            textBoxID.Text = "";
            textBoxAUTOR.Text = "";
            textBoxLIVRO.Text = "";
            textBoxEDITORA.Text = "";
        }

        private void buttonCRIAR_Click(object sender, EventArgs e)
        {
            // Cria a string de inser��o de dados
            StringBuilder SQL = new StringBuilder();
            SQL.Append("INSERT INTO LIVROS (AUTOR, LIVRO, EDITORA) VALUES ");
            SQL.Append("('" + textBoxAUTOR.Text + "', ");
            SQL.Append("'" + textBoxLIVRO.Text + "', ");
            SQL.Append("'" + textBoxEDITORA.Text + "')");
            myCmd.CommandText = SQL.ToString();

            // Abre a conex�o com o banco, executa e fecha a conex�o
            myConn.Open();
            myCmd.ExecuteReader(CommandBehavior.CloseConnection);
            myConn.Close();

            // Atualiza as informa��es na tela
            AtualizaDados();
        }

        private void buttonALTERAR_Click(object sender, EventArgs e)
        {
            // Cria a string de atualiza��o de dados
            StringBuilder SQL = new StringBuilder();
            SQL.Append("UPDATE LIVROS SET ");
            SQL.Append("AUTOR = '" + textBoxAUTOR.Text + "', ");
            SQL.Append("LIVRO = '" + textBoxLIVRO.Text + "', ");
            SQL.Append("EDITORA = '" + textBoxEDITORA.Text + "' ");
            SQL.Append("WHERE ID = " + textBoxID.Text);
            myCmd.CommandText = SQL.ToString();

            // Abre a conex�o com o banco, executa a altera��o e fecha a conex�o
            myConn.Open();
            myCmd.ExecuteReader(CommandBehavior.CloseConnection);
            myConn.Close();

            // Atualiza as informa��es na tela
            AtualizaDados();
        }

        private void buttonEXCLUIR_Click(object sender, EventArgs e)
        {
            // Cria a string de atualiza��o de dados
            StringBuilder SQL = new StringBuilder();
            SQL.Append("DELETE FROM LIVROS WHERE ID = " + textBoxID.Text);
            myCmd.CommandText = SQL.ToString();

            // Abre a conex�o com o banco, executa a altera��o e fecha a conex�o
            myConn.Open();
            myCmd.ExecuteReader(CommandBehavior.CloseConnection);
            myConn.Close();

            // Atualiza as informa��es na tela
            AtualizaDados();
        }
    }
}