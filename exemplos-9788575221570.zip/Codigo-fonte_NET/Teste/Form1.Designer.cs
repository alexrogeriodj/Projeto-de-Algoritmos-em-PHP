namespace Teste
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxAUTOR = new System.Windows.Forms.TextBox();
            this.textBoxLIVRO = new System.Windows.Forms.TextBox();
            this.textBoxEDITORA = new System.Windows.Forms.TextBox();
            this.labelID = new System.Windows.Forms.Label();
            this.labelAUTOR = new System.Windows.Forms.Label();
            this.labelLIVRO = new System.Windows.Forms.Label();
            this.labelEDITORA = new System.Windows.Forms.Label();
            this.buttonCRIAR = new System.Windows.Forms.Button();
            this.buttonALTERAR = new System.Windows.Forms.Button();
            this.buttonEXCLUIR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(12, 12);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(435, 150);
            this.dataGridView.TabIndex = 0;
            this.dataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellClick);
            // 
            // textBoxID
            // 
            this.textBoxID.Enabled = false;
            this.textBoxID.Location = new System.Drawing.Point(102, 182);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(40, 20);
            this.textBoxID.TabIndex = 1;
            // 
            // textBoxAUTOR
            // 
            this.textBoxAUTOR.Location = new System.Drawing.Point(102, 208);
            this.textBoxAUTOR.Name = "textBoxAUTOR";
            this.textBoxAUTOR.Size = new System.Drawing.Size(176, 20);
            this.textBoxAUTOR.TabIndex = 2;
            // 
            // textBoxLIVRO
            // 
            this.textBoxLIVRO.Location = new System.Drawing.Point(102, 234);
            this.textBoxLIVRO.Name = "textBoxLIVRO";
            this.textBoxLIVRO.Size = new System.Drawing.Size(176, 20);
            this.textBoxLIVRO.TabIndex = 3;
            // 
            // textBoxEDITORA
            // 
            this.textBoxEDITORA.Location = new System.Drawing.Point(102, 260);
            this.textBoxEDITORA.Name = "textBoxEDITORA";
            this.textBoxEDITORA.Size = new System.Drawing.Size(176, 20);
            this.textBoxEDITORA.TabIndex = 4;
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(75, 185);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(21, 13);
            this.labelID.TabIndex = 5;
            this.labelID.Text = "ID:";
            // 
            // labelAUTOR
            // 
            this.labelAUTOR.AutoSize = true;
            this.labelAUTOR.Location = new System.Drawing.Point(48, 211);
            this.labelAUTOR.Name = "labelAUTOR";
            this.labelAUTOR.Size = new System.Drawing.Size(48, 13);
            this.labelAUTOR.TabIndex = 6;
            this.labelAUTOR.Text = "AUTOR:";
            // 
            // labelLIVRO
            // 
            this.labelLIVRO.AutoSize = true;
            this.labelLIVRO.Location = new System.Drawing.Point(54, 237);
            this.labelLIVRO.Name = "labelLIVRO";
            this.labelLIVRO.Size = new System.Drawing.Size(42, 13);
            this.labelLIVRO.TabIndex = 7;
            this.labelLIVRO.Text = "LIVRO:";
            // 
            // labelEDITORA
            // 
            this.labelEDITORA.AutoSize = true;
            this.labelEDITORA.Location = new System.Drawing.Point(38, 263);
            this.labelEDITORA.Name = "labelEDITORA";
            this.labelEDITORA.Size = new System.Drawing.Size(58, 13);
            this.labelEDITORA.TabIndex = 8;
            this.labelEDITORA.Text = "EDITORA:";
            // 
            // buttonCRIAR
            // 
            this.buttonCRIAR.Location = new System.Drawing.Point(324, 199);
            this.buttonCRIAR.Name = "buttonCRIAR";
            this.buttonCRIAR.Size = new System.Drawing.Size(75, 23);
            this.buttonCRIAR.TabIndex = 9;
            this.buttonCRIAR.Text = "Criar";
            this.buttonCRIAR.UseVisualStyleBackColor = true;
            this.buttonCRIAR.Click += new System.EventHandler(this.buttonCRIAR_Click);
            // 
            // buttonALTERAR
            // 
            this.buttonALTERAR.Location = new System.Drawing.Point(324, 228);
            this.buttonALTERAR.Name = "buttonALTERAR";
            this.buttonALTERAR.Size = new System.Drawing.Size(75, 23);
            this.buttonALTERAR.TabIndex = 10;
            this.buttonALTERAR.Text = "Alterar";
            this.buttonALTERAR.UseVisualStyleBackColor = true;
            this.buttonALTERAR.Click += new System.EventHandler(this.buttonALTERAR_Click);
            // 
            // buttonEXCLUIR
            // 
            this.buttonEXCLUIR.Location = new System.Drawing.Point(324, 257);
            this.buttonEXCLUIR.Name = "buttonEXCLUIR";
            this.buttonEXCLUIR.Size = new System.Drawing.Size(75, 23);
            this.buttonEXCLUIR.TabIndex = 11;
            this.buttonEXCLUIR.Text = "Excluir";
            this.buttonEXCLUIR.UseVisualStyleBackColor = true;
            this.buttonEXCLUIR.Click += new System.EventHandler(this.buttonEXCLUIR_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 294);
            this.Controls.Add(this.buttonEXCLUIR);
            this.Controls.Add(this.buttonALTERAR);
            this.Controls.Add(this.buttonCRIAR);
            this.Controls.Add(this.labelEDITORA);
            this.Controls.Add(this.labelLIVRO);
            this.Controls.Add(this.labelAUTOR);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.textBoxEDITORA);
            this.Controls.Add(this.textBoxLIVRO);
            this.Controls.Add(this.textBoxAUTOR);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.dataGridView);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxAUTOR;
        private System.Windows.Forms.TextBox textBoxLIVRO;
        private System.Windows.Forms.TextBox textBoxEDITORA;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label labelAUTOR;
        private System.Windows.Forms.Label labelLIVRO;
        private System.Windows.Forms.Label labelEDITORA;
        private System.Windows.Forms.Button buttonCRIAR;
        private System.Windows.Forms.Button buttonALTERAR;
        private System.Windows.Forms.Button buttonEXCLUIR;
    }
}

