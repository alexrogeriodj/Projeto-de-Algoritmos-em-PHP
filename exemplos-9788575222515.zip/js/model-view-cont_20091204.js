/*
*  model-view-cont.js
*
*  This file contains the JavaScript that supports MVC and MVC-based modules.
*/

// Place the objects within their own namespace; create it if needed.
if (!window.MVC)
{
   MVC = {};
}

MVC.Connect = function()
{
   this.req = null;
   this.timeout = MVC.Connect.Timeout;
   this.collpol = MVC.Connect.Ignore;
};

// Set up a default for timeouts with Ajax requests (in milliseconds).
MVC.Connect.Timeout = 5000;

// These are the possible values used for setting the collision policy.
MVC.Connect.Ignore = 0;
MVC.Connect.Change = 1;

MVC.Connect.prototype.connect = function(method, url, post)
{
   // Allow only one connection through the YUI Connection Manager at a
   // time. Handle collisions based on the setting for collision policy.
   if (this.req && YAHOO.util.Connect.isCallInProgress(this.req))
   {
      if (this.collpol == MVC.Connect.Change)
      {
         this.abort();
      }
      else
      {
         return;
      }
   }

   // Use this as a semaphore of sorts to keep the critical section as
   // small as possible (even though JavaScript doesn't have semaphores).
   this.req = {};

   // This ensures access to the Connect (and derived object) instance in
   // the update, abandon, and recover methods. It generates a closure.
   var obj = this;

   function handleSuccess(o)
   {
      // Call the method implemented in the derived object for success.
      obj.update(o);
      obj.req = null;
   }

   function handleFailure(o)
   {
      if (o.status == -1)
      {
         // Call the method provided by the derived object for timeouts.
         obj.abandon(o);
         obj.req = null;
      }
      else
      {
         // Call the method provided by the derived object for failures.
         obj.recover(o);
         obj.req = null;
      }
   }

   // Set up the callback object to pass to the YUI Connection Manager.
   var callback =
   {
      success: handleSuccess,
      failure: handleFailure,
      timeout: this.timeout
   };

   // Establish the Ajax connection through the YUI Connection Manager.
   if (arguments.length > 2)
   {
      this.req = YAHOO.util.Connect.asyncRequest
      (
         method,
         url,
         callback,
         post
      );
   }
   else
   {
      this.req = YAHOO.util.Connect.asyncRequest
      (
         method,
         url,
         callback
      );
   }
};

MVC.Connect.prototype.abort = function()
{
   if (this.req && YAHOO.util.Connect.isCallInProgress(this.req))
   {
      YAHOO.util.Connect.abort(this.req);
      this.req = null;
   }
};

MVC.Connect.prototype.setTimeout = function(value)
{
   this.timeout = value;
};

MVC.Connect.prototype.setCollisionPolicy = function(value)
{
   this.collpol = value;
};

MVC.Connect.prototype.update = function(o)
{
   // The default for this method is to do nothing. A derived object must
   // define its own version to do something specific to the application.
};

MVC.Connect.prototype.abandon = function(o)
{
   // The default for this method is to do nothing. A derived object must
   // define its own version to do something specific to the application.
};

MVC.Connect.prototype.recover = function(o)
{
   // The default for this method is to do nothing. A derived object must
   // define its own version to do something specific to the application.
};

MVC.Model = function()
{
   MVC.Connect.call(this);

   this.state = {};
   this.views = new Array();
};

// Model objects are derived from the Connect object (to handle Ajax).
MVC.Model.prototype = new MVC.Connect();

MVC.Model.prototype.init = function()
{
   // Set up an empty state and notify the views for the first time.
   this.state = {};
   this.notify();
};

MVC.Model.prototype.setState = function(mixed, url, post)
{
   switch (arguments.length)
   {
      case 1:
         // One argument means the state for the model should be set
         // to the local object passed in mixed.
         this.state = mixed;
         this.notify();
         break;

      case 2:
         // Two arguments means set the state by fetching it remotely
         // using Ajax via the method in mixed (GET).
         this.connect(mixed, url);
         break;

      case 3:
         // Three arguments means set the state by fetching it remotely
         // using an Ajax POST; pass the POST data as the last argument.
         // If you do a GET with three arguments, the third is ignored.
         this.connect(mixed, url, post);
         break;
   }
};

MVC.Model.prototype.getState = function()
{
   return this.state;
};

MVC.Model.prototype.update = function(o)
{
   var r;

   // We're using JSON because the data stored as the state of the model
   // is an object.
   try
   {
      // This is where the response text is converted into a real object.
      r = json_parse(o.responseText);
   }
   catch(err)
   {
      // Handle if there is an issue creating the real JavaScript object.
      r = "";
   }

   if (typeof r != "object")
   {
      // If we don't get an object as a response, treat it as a failure.
      this.recover(o);
   }
   else
   {
      // Store the state and notify the views only when we're successful.
      this.state = r;
      this.notify();
   }
};

MVC.Model.prototype.subscribe = function(view)
{
   // Subscribe the view by inserting it into the list of subscribers.
   this.views.push(view);
};

MVC.Model.prototype.unsubscribe = function(view)
{
   var n = this.views.length;
   var t = new Array();

   // Unsubscribe the view by removing it from the list of subscribers.
   for (var i = 0; i < n; i++)
   {
      if (this.views[i].id != view.id)
         t.push(this.views[i]);
   }

   this.views = t;
};

MVC.Model.prototype.notify = function()
{
   var n = this.views.length;

   // Notifying all views means to invoke the update method of each view.
   for (var i = 0; i < n; i++)
   {
      this.views[i].update(this);
   }
};

MVC.View = function()
{
   this.model = null;
   this.id = null;
};

MVC.View.prototype.attach = function(m, i)
{
   // Make sure to unsubscribe from any model that is already attached.
   if (this.model != null)
      this.model.unsubscribe(this);

   this.model = m;
   this.id = i;

   // Subscribe to the current model to start getting its notifications.
   this.model.subscribe(this);
};

MVC.View.prototype.update = function()
{
   // The default for updating the view is to do nothing until a derived
   // view can provide more details about what it means to update itself.
};

MVC.MultiSelectModel = function(text, url)
{
   MVC.Model.call(this);

   // All selection lists use an empty string as the marker for the
   // label appearing in the selection list before an option is chosen.
   this.labelValue = "";

   if (text)
      this.labelText = text;
   else
      this.labelText = "Select";

   // This is the URL to contact for loading options.
   this.proc = url;

   // If the model ends up being the model for the first selection list
   // in the chain, the view with this model will set this member.
   this.firstModel = false;
}

MVC.MultiSelectModel.prototype = new MVC.Model();

MVC.MultiSelectModel.prototype.init = function()
{
   if (this.firstModel)
   {
      // Initialize options for the first selection list in the chain.
      this.setState("GET", this.proc);
   }
   else
   {
      // Initialize other selection lists to an empty array of options.
      // Do the view notification explicitly since we're not using the
      // setState method here (which would do the notification itself).
      this.state.options = new Array();
      this.notify();
   }
}

MVC.MultiSelectModel.prototype.abandon = function()
{
   alert("Timeout occurred while trying to load selection options.");
}

MVC.MultiSelectModel.prototype.recover = function()
{
   alert("Problem occurred while trying to load selection options.");
}

MVC.MultiSelectView = function(n, p)
{
   MVC.View.call(this);

   this.name = n;

   if (p)
   {
      // The selection list is not first in the chained selections.
      this.prev = p;
      p.next = this;
      this.disabled = true;
   }
   else
   {
      // This selection list has no predecessor, so it's the first one.
      this.prev = null;
      this.next = null;
      this.disabled = false;
   }
}

MVC.MultiSelectView.prototype = new MVC.View();

MVC.MultiSelectView.prototype.attach = function(m, i)
{
   // This method hooks up a view to its data source, which is a model.
   MVC.View.prototype.attach.call(this, m, i);

   // If the view has no predecessor view, it must be first in the chain.
   if (!this.prev)
      this.model.firstModel = true;

   this.container = document.getElementById(this.id);
}

MVC.MultiSelectView.prototype.update = function()
{
   // Called when a change in the model takes place. Render new options.
   var select = this.getSelect();

   // Remove any existing select element not created by the view.
   if (select && !YAHOO.util.Dom.hasClass(select, "mltsel"))
   {
      select.parentNode.removeChild(select);
      select = null;
   }

   // Insert a new select only the first time the view is being managed.
   if (!select)
   {
      select = document.createElement("select");
      YAHOO.util.Dom.addClass(select, "mltsel");
      select.setAttribute("name", this.name);

      YAHOO.util.Event.addListener
      (
         select,
         "change",
         this.changeHandler,
         this,
         true
      );

      // Insert the select element for the selection list into the DOM.
      if (this.container)
         this.container.appendChild(select);
   }

   if (this.disabled)
      select.disabled = true;
   else
      select.disabled = false;

   var o;
   var options;
   var count;

   // Start the options with the model's label for the selection list.
   select.options.length = 0;
   o = new Option(this.model.labelText, this.model.labelValue);
   select.options[select.options.length] = o;

   options = this.model.state.options;
   count = options.length;

   // Load the rest of the selection list remaining with the options.
   for (var i = 0; i < count; i++)
   {
      o = new Option(options[i].text, options[i].value);
      select.options[select.options.length] = o;
   }
}

MVC.MultiSelectView.prototype.changeHandler = function(e)
{
   // Handle changes in one of the selection lists by adjusting others.
   var select = this.getSelect();
   var option = select.options[select.selectedIndex].value;

   if (option == "")
   {
      // The selection list has been set back to its initial state;
      // selection lists beyond it in the chain must be reset as well.
      this.reset(this.next);
   }
   else
   {
      if (this.next)
      {
         // Use Ajax to get options for the next selection in the chain.
         if (this.next.model.proc.indexOf("?") == -1)
            option = "?value=" + option;
         else
            option = "&value=" + option;

         this.next.model.setState("GET", this.next.model.proc + option);
         this.next.enable();

         // Move to the next selection list in the chain and reset all
         // views beyond it (when a choice has been made out of order).
         var iter = this.next;

         if (iter)
            this.reset(iter.next);
      }
   }
}

MVC.MultiSelectView.prototype.reset = function(view)
{
   // Initialize all selection lists after the given one in the chain.
   var iter = view;

   while (iter)
   {
      iter.model.init();
      iter.disable();
      iter = iter.next;
   }
}

MVC.MultiSelectView.prototype.enable = function()
{
   var select = this.getSelect();

   this.disabled = false;

   if (select)
      select.disabled = this.disabled;
}

MVC.MultiSelectView.prototype.disable = function()
{
   var select = this.getSelect();

   this.disabled = true;

   if (select)
      select.disabled = this.disabled;
}

MVC.MultiSelectView.prototype.getSelect = function()
{

   var elements;

   // Retrieve the current select element used by the selection list.
   if (this.container)
      elements = this.container.getElementsByTagName("select");
   else
      return null;

   if (elements.length > 0)
      return elements[0];
   else
      return null;
}

MVC.MultiSelect = function(text, url, id, name, prev)
{
   // Pass a string for the selection list in text, or pass null for a
   // default label; url is the URL to fetch options, id is the ID of
   // the container in which to place the selection list, name is the
   // select name attribute, and prev is the predecessor list, or null.
   t = (text) ? text : null;
   p = (prev) ? prev.view : null;

   this.model = new MVC.MultiSelectModel(t, url);
   this.view  = new MVC.MultiSelectView(name, p);
   this.view.attach(this.model, id);
}

MVC.MultiSelect.prototype.init = function()
{
   // Call this method once the chain of selections has been set up.
   this.model.init();
}

MVC.MultiSelect.prototype.getSelect = function()
{
   // Return the select element currently in use by the selection list
   // so that you can make whatever customizations are needed (e.g., you
   // can append your own handlers or perform various DOM operations).
   return this.view.getSelect();
}
