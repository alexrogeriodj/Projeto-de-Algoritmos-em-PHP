/*
*  sitewide.js
*
*  This file contains JavaScript for components used across the entire site.
*/

PictureSlider = function()
{
   // Set up references to the elements needed for the slider and viewer.
   this.slider = document.getElementById("picsld");

   if (this.slider)
   {
      this.tab = this.slider.getElementsByTagName("table");
      this.tab = (this.tab && this.tab.length > 0) ? this.tab[0] : null;
   }

   if (this.slider)
   {
      this.lb = YAHOO.util.Dom.getElementsByClassName
      (
         "btnl",
         "img",
         this.slider
      );

      this.lb = (this.lb && this.lb.length > 0) ? this.lb[0] : null;

      this.rb = YAHOO.util.Dom.getElementsByClassName
      (
         "btnr",
         "img",
         this.slider
      );

      this.rb = (this.rb && this.rb.length > 0) ? this.rb[0] : null;
   }

   this.viewer = document.getElementById("picvwr");

   // You pass values for the following parameters to the module's
   // constructor in PHP. The module's get_js method in PHP dynamically
   // generates the JavaScript to set these members from those values.
   this.stripWidth = 0;
   this.totalCount = 0;
   this.totalWidth = 0;

   // This lock is needed to ensure that one left or right move of the
   // slider runs to completion; otherwise, misalignment could happen.
   this.lock = false;
};

PictureSlider.prototype = new Object();

PictureSlider.prototype.slideL = function()
{
   // Moving to the left adjusts the slider in a positive direction.
   this.adjust(+(this.stripWidth));
};

PictureSlider.prototype.slideR = function()
{
   // Moving to the right adjusts the slider in a negative direction.
   this.adjust(-(this.stripWidth));
};

PictureSlider.prototype.adjust = function(amt)
{
   // If already locked, do nothing; otherwise, get the lock and go.
   if (this.lock)
      return;
   else
      this.lock = true;

   var anim;
   var ease = YAHOO.util.Easing.easeOut;
   var pos = parseInt(YAHOO.util.Dom.getStyle(this.tab, "left"));

   // Prevent moving past either end of the slider during an adjustment.
   if (amt > 0)
   {
      if (pos + amt > 0)
      amt = 0;
   }

   if (amt < 0)
   {
      if (pos + amt <= -(this.totalWidth))
      amt = 0;
   }

   // The following creates a closure that ensures access to members
   // of the PictureSlider instance from inside the update method.
   var obj = this;

   function handleComplete()
   {
      obj.update();
      obj.lock = false;
   }

   // Do the sliding animation if there is any amount to move; otherwise,
   // just call update directly to ensure the arrow buttons are updated.
   if (amt != 0)
   {
      anim = new YAHOO.util.Anim(this.tab, {left: {by: amt}}, 0.5, ease);
      anim.onComplete.subscribe(handleComplete);
      anim.animate();
   }
   else
   {
      this.update();
      this.lock = false;
   }
};

// PictureSlider.prototype.update is in get_js of the PictureSlider module
// so that paths for images can be generated dynamically for your install.

PictureSlider.prototype.select = function(targ, n, img, text, attr)
{
   var sld;
   var el;

   // Switch the selection by changing the frame with the selected class.
   el = YAHOO.util.Dom.getElementsByClassName
   (
      "selected",
      "div",
      this.slider
   );

   if (el && el.length > 0)
      YAHOO.util.Dom.removeClass(el[0], "selected");

   if (targ)
      YAHOO.util.Dom.addClass(targ, "selected");

   // Reload the picture viewer with the current selection in the slider.
   this.reload(img, text, attr);

   // Update the text indicating the position of the selected picture.
   el = YAHOO.util.Dom.getElementsByClassName
   (
      "sldpos",
      "div",
      this.slider
   );

   if (el && el.length > 0)
   {
      el[0].innerHTML = "Showing picture <strong>" + n + "</strong> of "
         + this.totalCount;
   }
};

PictureSlider.prototype.reload = function(img, text, attr)
{
   // Handle the case of no viewer associated with the picture slider.
   if (!this.viewer) return;

   var el;

   // Get the image viewer and change the image currently being shown.
   el = YAHOO.util.Dom.getElementsByClassName
   (
      "vwrimg",
      "div",
      this.viewer
   );

   if (el && el.length > 0)
   {
      el = el[0].getElementsByTagName("img");

      if (el && el.length > 0)
      {
         el[0].src = img;
         el[0].alt = text;
      }
   }

   // Change the attribution in the picture viewer for the selection.
   el = this.viewer.getElementsByTagName("cite");

   if (el && el.length > 0)
      el[0].childNodes[0].nodeValue = "courtesy of " + attr;

   // Change the caption in the picture viewer based on the selection.
   el = YAHOO.util.Dom.getElementsByClassName
   (
      "vwrcap",
      "div",
      this.viewer
   );

   if (el && el.length > 0)
      el[0].childNodes[0].nodeValue = text;
};

PictureSlider.prototype.loaded = function()
{
   // Fire this from your initialization method for the picture slider.
   var el;

   el = YAHOO.util.Dom.getElementsByClassName
   (
      "sldtab",
      "div",
      this.slider
   );

   YAHOO.util.Dom.setStyle
   (
      el[0],
      "visibility",
      "visible"
   );
};
