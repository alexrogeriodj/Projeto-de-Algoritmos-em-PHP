<?php
if (empty($_GET["req"]))
   $req = "";
else
   $req = $_GET["req"];

if (empty($_GET["value"]))
   $car_id = "";
else
   $car_id = $_GET["value"];

if (is_mk_req($req) || is_md_req($req, $car_id) || is_tr_req($req, $car_id))
{
   switch ($req)
   {
      case "md":
         $models = get_models_list($car_id);

         foreach ($models as $m => $unused)
         {
            $details = get_model_details($m);
            $y = "'".substr($details["Model Year"], 2, 2);

            // Place the models in multiple arrays of models, each keyed by
            // model year so that we can sort by model year independently.
            $models_by_year[$details["Model Year"]][] = array
            (
               "value" => $m,
               "text"  => $y." ".$details["Model Name"]
            );
         }

         // Sort the subsets of models so that recent model years go first.
         krsort($models_by_year);

         // Within each model year, sort models in ascending order by name.
         foreach ($models_by_year as $year => $models)
         {
            usort($models, "sort_text");
            foreach ($models as $o) $options[] = $o;
         }

         $result = array
         (
            "options" => $options
         );

         break;

      case "tr":
         $trims = get_trims_list($car_id);

         foreach ($trims as $t => $unused)
         {
            get_trim_snapshot(array($t), $details);

            $options[] = array
            (
               "value" => $t,
               "text"  => $details[$t]["Trim Name"]
            );
         }

         usort($options, "sort_text");

         $result = array
         (
            "options" => $options
         );

         break;

      default:
         $makes = get_makes();

         foreach ($makes as $m => $name)
         {
            $options[] = array
            (
               "value" => $m,
               "text"  => $name
            );
         }

         usort($options, "sort_text");

         $result = array
         (
            "options" => $options
         );
   }
}
else
{
   // It's an error if no ID is provided when a type is specified; return an
   // empty array of options for this case.
   $result = array
   (
      "options" => array()
   );
}

header("Content-Type: application/json");

// Set Expires to ensure current data, regardless of browser cache settings.
header("Expires: 0");

echo json_encode($result);

function sort_text($i, $j)
{
   return strcasecmp($i["text"], $j["text"]);
}

function is_mk_req($req)
{
   return ($req == "mk" || empty($req));
}

function is_md_req($req, $cid)
{
   return ($req == "md" && !empty($cid));
}

function is_tr_req($req, $cid)
{
   return ($req == "tr" && !empty($cid));
}

// The methods below just hardcode some fake data for demonstration purposes.
function get_makes()
{
   return array
   (
      "bmw"       => "BMW",
      "honda"     => "Honda",
      "toyota"    => "Toyota"
   );
}

function get_models_list($make_id)
{
   switch ($make_id)
   {
      case "bmw":
         $models = array
         (
            "0001"         => "09 3-Series",
            "0002"         => "09 5-Series"
         );

         break;

      case "honda":
         $models = array
         (
            "0003"         => "08 Accord",
            "0004"         => "09 Civic"
         );

         break;

      case "toyota":
         $models = array
         (
            "0005"         => "09 Corolla",
            "0006"         => "09 Camry"
         );

         break;

      default:
         $models = array();
   }

   return $models;
}

function get_model_details($model_id)
{
   switch ($model_id)
   {
      case "0001":
         $details = array
         (
            "Model Year"   => "2009",
            "Model Name"   => "3-Series"
         );

         break;

      case "0002":
         $details = array
         (
            "Model Year"   => "2009",
            "Model Name"   => "5-Series"
         );

         break;

      case "0003":
         $details = array
         (
            "Model Year"   => "2008",
            "Model Name"   => "Accord"
         );

         break;

      case "0004":
         $details = array
         (
            "Model Year"   => "2009",
            "Model Name"   => "Civic"
         );

         break;

      case "0005":
         $details = array
         (
            "Model Year"   => "2009",
            "Model Name"   => "Corolla"
         );

         break;

      case "0006":
         $details = array
         (
            "Model Year"   => "2009",
            "Model Name"   => "Camry"
         );

         break;

      default:
         $details = array();
   }

   return $details;
}

function get_trims_list($model_id)
{
   switch ($model_id)
   {
      case "0001":
         $trims = array
         (
            "000101"       => "328i",
            "000102"       => "335i"
         );

         break;

      case "0002":
         $trims = array
         (
            "000201"       => "535i",
            "000202"       => "550i"
         );

         break;

      case "0003":
         $trims = array
         (
            "000301"       => "Accord 2-Door",
            "000302"       => "Accord 4-Door"
         );

         break;

      case "0004":
         $trims = array
         (
            "000401"       => "Civic 2-Door",
            "000402"       => "Civic 4-Door"
         );

         break;

      case "0005":
         $trims = array
         (
            "000501"       => "Corolla LE",
            "000502"       => "Corolla S"
         );

         break;

      case "0006":
         $trims = array
         (
            "000601"       => "Camry LE",
            "000602"       => "Camry SE"
         );

         break;

      default:
         $trims = array();
   }

   return $trims;
}

function get_trim_snapshot($trims, &$details)
{
   $trim = $trims[0];
   $details[$trim] = array();

   switch ($trim)
   {
      case "000101":

         $details[$trim]["Trim Name"] = "328i";
         break;

      case "000102":

         $details[$trim]["Trim Name"] = "335i";
         break;

      case "000201":

         $details[$trim]["Trim Name"] = "535i";
         break;

      case "000202":

         $details[$trim]["Trim Name"] = "550i";
         break;

      case "000301":

         $details[$trim]["Trim Name"] = "Accord 2-Door";
         break;

      case "000302":

         $details[$trim]["Trim Name"] = "Accord 4-Door";
         break;

      case "000401":

         $details[$trim]["Trim Name"] = "Civic 2-Door";
         break;

      case "000402":

         $details[$trim]["Trim Name"] = "Civic 4-Door";
         break;

      case "000501":

         $details[$trim]["Trim Name"] = "Corolla LE";
         break;

      case "000502":

         $details[$trim]["Trim Name"] = "Corolla S";
         break;

      case "000601":

         $details[$trim]["Trim Name"] = "Camry LE";
         break;

      case "000602":

         $details[$trim]["Trim Name"] = "Camry SE";
         break;

      default:
         $details = array();
   }
}
?>
