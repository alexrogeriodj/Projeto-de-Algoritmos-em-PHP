<?php
if (!empty($_GET["mode"]))
   $mode = $_GET["mode"];
else
   $mode = "";

switch ($mode)
{
   case "tmo":
      // Simulate the server taking too long to come back from the request.
      $status = "\"Timeout test executed at ".date("H:i:s")."\"";

      // Don't sleep for too long since this will prevent a server with one
      // child from handling other requests until this process is finished.
      sleep(2);
      break;

   case "dat":
      // Simulate an error in the data that gets sent back from the server.
      $status = "junk";
      break;

   default:
      // This is the case for a normal response being sent from the server.
      $status = "\"Hello from the server at ".date("H:i:s")."\"";
}

header("Content-Type: application/json");

// Set Expires to ensure current data, regardless of browser cache settings.
header("Expires: 0");

echo <<<EOD
{
   "message": $status
}

EOD;
?>
