<?php
$p = pdf_new();
pdf_open_file($p);

pdf_begin_page($p,595,842);
    // Ret�ngulo
    pdf_rect($p,70,650,200,100);
    pdf_stroke($p);
    // Quadrado preenchido
    pdf_setcolor($p,"fill","rgb", 1, 1, 0);
    pdf_rect($p,350,650,100,100);
    pdf_fill_stroke($p);
    // Retangulo pontilhado
    pdf_setcolor($p,"stroke","rgb", 0, 0, 1);
    pdf_setdash($p,4,6);
    pdf_rect($p,40,600,500,200);
    pdf_stroke($p);
pdf_end_page($p);

pdf_close($p);
$buf = pdf_get_buffer($p);
$tamanho = strlen($buf);
header("Content-type:application/pdf");
header("Content-Length:$tamanho");
header("Content-Disposition:inline; filename=retangulos.pdf");
echo $buf;
pdf_delete($p);
?>
