<?php
$p = pdf_new();
pdf_open_file($p);
pdf_begin_page($p,595,842);

$im = pdf_open_image_file ($p, "jpeg", "postgresql.jpg");
    pdf_place_image($p, $im, 20, 500, 1);
    pdf_place_image($p, $im, 170, 500, 0.75);
    pdf_place_image($p, $im, 280, 500, 0.50);
    pdf_place_image($p, $im, 355, 500, 0.25);
    pdf_place_image($p, $im, 395, 500, 0.10);
pdf_close_image ($p,$im);

pdf_end_page($p);
pdf_close($p);
$buf = pdf_get_buffer($p);
$tamanho = strlen($buf);
header("Content-type:application/pdf");
header("Content-Length:$tamanho");
header("Content-Disposition:inline; filename=imagens.pdf");
echo $buf;
pdf_delete($p);
?>
