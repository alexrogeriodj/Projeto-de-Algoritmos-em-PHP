<?php
define('FPDF_FONTPATH','fpdf/font/');
require_once("fpdf/fpdf.php");

$pdf=new FPDF();
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','B',36);
$pdf->Cell(50,30,'Hello World!');
$pdf->Output();
?>
