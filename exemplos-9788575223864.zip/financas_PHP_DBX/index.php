<html>
<head>
<title>Controle de gastos mensais</title>
</head>
<body>
<h2 align="center"><font color="#00FF00">$$$</font> Controle de gastos mensais <font color="#00FF00">$$$</font></h2>
<p align="center">Digite seus dados de identifica��o para acessar o sistema:</p>
<hr>
<form method="POST" action="login.php">
  <p align="center">Usu�rio: <input type="text" name="usuario" size="20"></p>
  <p align="center">Senha: <input type="password" name="senha" size="20"></p>
  <p align="center"><input type="submit" value="Enviar" name="enviar"></p>
</form>
<hr>
</body>
</html>
