<?php
	setcookie("usuario");
	setcookie("senha");
	header ("Location: index.php");
?>

