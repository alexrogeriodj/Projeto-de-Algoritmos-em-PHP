<?php
include "valida_cookies.inc";
?>
<html>
<body>
Seja bem-vindo ao meu site!!!<br>
Coloque o conte�do do seu site aqui neste espa�o.<br>
<p><a href="logout.php">LOGOUT</a></p>
</body>
</html>

