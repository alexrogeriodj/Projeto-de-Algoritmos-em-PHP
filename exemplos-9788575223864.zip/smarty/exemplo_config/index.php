<?php
error_reporting(E_ERROR);  // usado para evitar exibi��o de avisos (Warnings) em determinadas vers�es do PHP
require('Smarty.class.php');
$smarty = new Smarty;
$smarty->display('index.tpl');
?>
