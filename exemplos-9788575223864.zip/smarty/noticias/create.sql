create table noticias 
(
	id mediumint NOT NULL AUTO_INCREMENT,
	titulo text NOT NULL,
	texto text NOT NULL,
	data_hora datetime NOT NULL,
	primary key(id)
);


insert into noticias (titulo,texto,data_hora) values ('Cl�ssico do futebol mundial na luta pelo ouro', 'Um cl�ssico do futebol mundial decide o torneio masculino dos Jogos Pan-Americanos de Santo Domingo. Brasil e Argentina se enfrentam, as 19h desta sexta-feira (20h de Bras�lia), dia 15, no Est�dio Ol�mpico Juan Pablo Duarte. Se os confrontos entre os rivais costumam ser quentes, a disputa fica ainda mais acirrada quando est� em jogo uma medalha de ouro. O Brasil tentar� o pentacampeonato pan-americano. O Brasil entra em campo com uma d�vida e uma altera��o certa em rela��o ao time que venceu o M�xico por 1 a 0 na semifinal. O zagueiro Irineu substitui Adailton, expulso na semifinal.', '2013-02-15 10:35');

insert into noticias (titulo,texto,data_hora) values ('Brasil bate recorde de medalhas', 'A participa��o brasileira no Pan � a melhor da hist�ria. O pa�s bateu seu pr�prio recorde do total medalhas e de ouros. A melhor marca at� ent�o havia sido conquistada em Winnipeg-99.', '2013-02-15 10:25');

insert into noticias (titulo,texto,data_hora) values ('Brasil � ouro no revezamento 4x100m nado livre', 'O Brasil conquistou o ouro na prova do revezamento 4x100m nado livre dos Jogos Pan-Americanos. Fernando Scherer, Gustavo Borges, Jader Souza e Carlos Jayme deram o bicampeonato ao Brasil na prova que o pa�s ganhou tamb�m em Winnipeg, Canad�, em 1999. Os brasileiros ganharam a prova com o tempo total de 3min18s66, contra 3min23s14 da Venezuela (prata) e 3min23s83 do Canad�.', '2013-02-15 10:15');
