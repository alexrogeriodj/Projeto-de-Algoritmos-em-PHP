<?php

// ------ acesso ao banco de dados ----------
$servidor = "localhost";
$usuario = "juliano";
$senha = "12345";
$banco = "test";

$con = mysql_connect($servidor, $usuario, $senha);
    mysql_select_db ($banco);
    $res = mysql_query("select * from noticias order by data_hora desc limit 3");
    $num_linhas = mysql_numrows($res);

    for($i=0 ; $i<$num_linhas; $i++)
    {
        $array_ids[] = mysql_result($res,$i,"id");
        $array_titulos[] = mysql_result($res,$i,"titulo");
        $array_textos[] = mysql_result($res,$i,"texto");
        $array_datas[] = mysql_result($res,$i,"data_hora");
    }
mysql_close($con);

// ---- define vari�veis e exibe o template ----
require('Smarty.class.php');
$smarty = new Smarty;
$smarty->assign("ids", $array_ids);
$smarty->assign("titulos", $array_titulos);
$smarty->assign("textos", $array_textos);
$smarty->assign("datas", $array_datas);
$smarty->display("index.tpl");
?>
