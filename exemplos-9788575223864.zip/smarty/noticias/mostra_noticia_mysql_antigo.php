<?php
$id_noticia = $_GET['id'];

// ------ acesso ao banco de dados ----------
$servidor = "localhost";
$usuario = "juliano";
$senha = "12345";
$banco = "test";

$con = mysql_connect($servidor, $usuario, $senha);
    mysql_select_db ($banco);
    $res = mysql_query("select titulo,texto,data_hora from noticias where id=$id_noticia");
    $num_linhas = mysql_numrows($res);

    if($num_linhas>0)
    {
        $titulo = mysql_result($res,0,"titulo");
        $texto = mysql_result($res,0,"texto");
        $data = mysql_result($res,0,"data_hora");
    }
mysql_close($con);

// ---- define vari�veis e exibe o template ----
require('Smarty.class.php');
$smarty = new Smarty;
$smarty->assign("titulo", $titulo);
$smarty->assign("texto", $texto);
$smarty->assign("data", $data);
$smarty->display("mostra_noticia.tpl");
?>
