<?php
$titulo = "Livros da Novatec Editora";

// ------ acesso ao banco de dados ----------
$servidor = "localhost";
$usuario = "juliano";
$senha = "12345";
$banco = "test";

$con = mysql_connect($servidor, $usuario, $senha);
    mysql_select_db ($banco);
    $res = mysql_query("select titulo,autor from livros order by titulo");
    $num_linhas = mysql_numrows($res);

    for($i=0 ; $i<$num_linhas; $i++)
    {
        $array_livros[] = mysql_result($res,$i,0);
        $array_autores[] = mysql_result($res,$i,1);
    }
mysql_close($con);

// ---- define vari�veis e exibe o template ----
require('Smarty.class.php');
$smarty = new Smarty;
$smarty->assign("titulo", $titulo);
$smarty->assign("livros", $array_livros);
$smarty->assign("autores", $array_autores);
$smarty->display("index.tpl");
?>
