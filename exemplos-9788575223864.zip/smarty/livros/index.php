<?php
$titulo = "Livros da Novatec Editora";

$array_livros = array(
	"Desenvolvendo Websites com PHP",
	"Prote��o Jur�dica de Software",
	"Virtual Private Network",
	"ASP.NET Guia do Desenvolvedor"
);

$array_autores = array(
	"Juliano Niederauer",
	"Alexandre Coutinho Ferrari",
	"Lino Sarlo da Silva",
	"Felipe Cembranelli"
);

error_reporting(E_ERROR);  // usado para evitar exibi��o de avisos (Warnings) em determinadas vers�es do PHP
require('Smarty.class.php');
$smarty = new Smarty;
$smarty->assign("titulo", $titulo);
$smarty->assign("livros", $array_livros);
$smarty->assign("autores", $array_autores);
$smarty->display("index.tpl");
?>
