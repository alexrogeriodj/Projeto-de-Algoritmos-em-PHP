<?php
error_reporting(E_ERROR);  // usado para evitar exibi��o de avisos (Warnings) em determinadas vers�es do PHP
require('Smarty.class.php');
$smarty = new Smarty;
$data_nascimento = mktime (0, 0, 0, 9, 30, 1978);
$smarty->assign('data', $data_nascimento);
$smarty->display('index.tpl');
?>
