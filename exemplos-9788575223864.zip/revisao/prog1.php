<?php
    // Legal, estou escrevendo meu primeiro programa em PHP
    echo  "<h1 align='center'>Este � meu primeiro programa!</h1>";
?>
