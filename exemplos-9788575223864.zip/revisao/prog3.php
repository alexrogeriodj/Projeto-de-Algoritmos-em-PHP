<html>
<body>
<?php
	$base = 10;
	$altura = 20;
	$area = $base * $altura;
?>
</body>
</html>

