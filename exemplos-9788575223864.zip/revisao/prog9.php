<?php
	class teste
	{
		function Saudacao()
        {
    		echo "Oi pessoal!";
		}
	}
	$objeto = new teste;    // $objeto se torna uma est�ncia da classe lixo
	$objeto -> Saudacao();
?>

