<html>
<body>
<?php
	$num = 50;
	$deslocado = $num >> 1;   // desloca 1 bit para direita
	echo  $deslocado;
?>
</body>
</html>

