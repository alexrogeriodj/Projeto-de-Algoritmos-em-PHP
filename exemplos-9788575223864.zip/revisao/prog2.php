<html>
<body>
<?php
	$data_de_hoje = date ("d/m/Y");
?>
<p align="center">Hoje � dia <?php echo $data_de_hoje; ?></p>
</body>
</html>

