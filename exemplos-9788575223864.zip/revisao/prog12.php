<?php
	$num = 5;
	$resultado = 8 + 3 * 2 + ++$num;
	echo "$num<br>";
	echo $resultado;
?>

