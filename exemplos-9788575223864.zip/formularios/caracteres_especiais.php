<?php
	$texto = "<img src=http://www.niederauer.com.br/figuras/interbase.jpg>";
	$novo_texto =htmlspecialchars($texto);
	echo $texto . "<br>";
	echo  $novo_texto;
?>

