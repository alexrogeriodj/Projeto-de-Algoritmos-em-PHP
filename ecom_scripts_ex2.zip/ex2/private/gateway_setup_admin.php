<?php

// Create an array for the information:
$data = array();

$data['x_trans_id'] = $trans_id;
$data['x_type'] = 'PRIOR_AUTH_CAPTURE';
