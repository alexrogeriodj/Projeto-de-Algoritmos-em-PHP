<?php
class ExemploComboBox
{
    private $comboBox;
    private $comboBoxEntry;
    private $label;
    
    public function __construct()
    {
        $window = new GtkWindow;
        $window->set_default_size(200,100);
        $window->set_border_width(20);
        $window->set_position(GTK::WIN_POS_CENTER);
        
        $vbox = new GtkVBox;
        $window->add($vbox);
        
        $this->comboBox = GtkComboBox::new_text();
        $this->comboBox->insert_text(0, 'Rio Grande do Sul');
        $this->comboBox->insert_text(1, 'Minas Gerais');
        $this->comboBox->insert_text(2, 'S�o Paulo');
        $this->comboBox->insert_text(3, 'Rio de Janeiro');
        $this->comboBox->set_active(1);
        
        $vbox->pack_start($this->comboBox, false, false);
        
        $this->comboBoxEntry = GtkComboBoxEntry::new_text();
        $this->comboBoxEntry->append_text('Estados Unidos');
        $this->comboBoxEntry->append_text('Canad�');
        $this->comboBoxEntry->append_text('Brasil');
        $this->comboBoxEntry->append_text('Jap�o');
        $this->comboBoxEntry->append_text('Austr�lia');
        $this->comboBoxEntry->set_active(1);
        $vbox->pack_start($this->comboBoxEntry, false, false);
        
        $button  = GtkButton::new_from_stock(Gtk::STOCK_DIALOG_QUESTION);
        $button->connect_simple('clicked', array($this, 'onClick'));
        $vbox->pack_start($button, false, false);
        
        $window->show_all();
    }
    
    public function onClick()
    {
        $texto1 = $this->comboBox->get_active()      . ') ' . $this->comboBox->get_active_text();
        $texto2 = $this->comboBoxEntry->get_active() . ') ' . $this->comboBoxEntry->get_active_text();
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK,
                                             "Voc� escolheu:\n$texto1\n$texto2");
        $dialog->run();
        $dialog->destroy();

    }
}

new ExemploComboBox;
Gtk::main();
?>