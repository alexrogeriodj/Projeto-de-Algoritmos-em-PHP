<?php
$window = new GtkWindow;
$window->set_default_size(240,140);
$window->set_border_width(4);

$hbox = new GtkHBox;
$hbox->set_spacing(4);

$window->add($hbox);

$botao1 = new GtkButton('YES');
$botao2 = new GtkButton('NO');

$vbox = new GtkVBox;

$botao1_ = new GtkButton('SIM');
$botao2_ = new GtkButton('N�O');
$vbox->pack_start($botao1_, true, true);
$vbox->pack_start($botao2_, true, true);

$hbox->pack_start($botao1, false, false);
$hbox->pack_start($vbox,   true, true);
$hbox->pack_start($botao2, false, false);

$window->show_all();
Gtk::main();
?>