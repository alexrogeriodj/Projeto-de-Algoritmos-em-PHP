<?php
$window = new GtkWindow;
$window->set_default_size(140,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Bot�o');
$window->set_border_width(20);

$button = new GtkButton('Clique Me');

$window->add($button);

$window->show_all();
Gtk::main();
?>