<?php
$window = new GtkWindow;
$window->set_default_size(240,140);
$window->set_border_width(4);

$box = new GtkHBox;
$box->set_spacing(4);

$window->add($box);

$botao1 = new GtkButton('YES');
$botao2 = new GtkButton('NO');
$botao3 = new GtkButton('CANCEL');

$box->pack_start($botao1, false, false);
$box->pack_start($botao2, true, true);
$box->pack_start($botao3, false, false);
$window->show_all();
Gtk::main();
?>