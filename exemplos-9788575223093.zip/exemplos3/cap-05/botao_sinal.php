<?
$window = new GtkWindow;
$window->set_default_size(120,100);

$vbox = new GtkVBox;

$button = new GtkButton("_Clique me", true);
$button->connect_simple('clicked', 'onClicked');
$vbox->pack_start($button);

$button = new GtkButton("_Pressione me", true);
$button->connect_simple('pressed', 'onPressed');
$vbox->pack_start($button);

$button = new GtkButton("_Release me", true);
$button->connect_simple('released', 'onReleased');
$vbox->pack_start($button);

$button = new GtkButton("_Entra e Sai", true);
$button->connect_simple('enter', 'onEnter');
$button->connect_simple('leave', 'onLeave');
$vbox->pack_start($button);

function onClicked()
{
	echo "clicked\n";
}

function onPressed()
{
	echo "pressed\n";
}

function onReleased()
{
	echo "release\n";
}

function onEnter()
{
	echo "enter\n";
}

function onLeave()
{
	echo "leave\n";
}

$window->add($vbox);
$window->show_all();
Gtk::main();
?>