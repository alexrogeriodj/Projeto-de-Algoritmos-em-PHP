<?
class ExemploMenu
{
    function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_default_size(300,-1);
        
        $MenuBar = new GtkMenuBar;
        $this->window->add($MenuBar);
        
        $MenuArquivo = new GtkMenuItem('_Arquivo');
        $MenuEditar  = new GtkMenuItem('_Editar');
        $MenuAjuda   = new GtkMenuItem('A_juda');
        
        $MenuBar->append($MenuArquivo);
        $MenuBar->append($MenuEditar);
        $MenuBar->append($MenuAjuda);
        
        $SubMenuArquivo = new GtkMenu;
        $MenuArquivo->set_submenu($SubMenuArquivo);
        
        $ItemArquivo1= new GtkImageMenuItem(Gtk::STOCK_NEW);
        $ItemArquivo2= new GtkImageMenuItem(Gtk::STOCK_OPEN);
        $ItemArquivo3= new GtkImageMenuItem(Gtk::STOCK_SAVE);
        $ItemArquivo4= new GtkSeparatorMenuItem;
        $ItemArquivo5= new GtkImageMenuItem(Gtk::STOCK_QUIT);
        
        $SubMenuArquivo->append($ItemArquivo1);
        $SubMenuArquivo->append($ItemArquivo2);
        $SubMenuArquivo->append($ItemArquivo3);
        $SubMenuArquivo->append($ItemArquivo4);
        $SubMenuArquivo->append($ItemArquivo5);
        
        $ItemArquivo1->connect_simple('activate', array($this, 'onArquivoNovo'));
        $ItemArquivo2->connect_simple('activate', array($this, 'onArquivoAbrir'));
        $ItemArquivo5->connect_simple('activate', array('Gtk',   'main_quit'));
        
        $imagem = GtkImage::new_from_file('icons/ico_config.png');
        
        $SubMenuEditar = new GtkMenu;
        $MenuEditar->set_submenu($SubMenuEditar);
        
        $ItemEditar1= new GtkImageMenuItem('Configurar');
        $ItemEditar2= new GtkImageMenuItem('_Copiar');
        $ItemEditar3= new GtkImageMenuItem('Co_lar');
        $ItemEditar1->set_image($imagem);
        $this->item4 = $ItemEditar4= new GtkCheckMenuItem('_Sim/N�o');
        $ItemEditar4->connect_simple('activate', array($this, 'onEditarSim'));
        
        $SubMenuEditar->append($ItemEditar1);
        $SubMenuEditar->append($ItemEditar2);
        $SubMenuEditar->append($ItemEditar3);
        $SubMenuEditar->append($ItemEditar4);
        
        $SubMenuAjuda= new GtkMenu;
        $MenuAjuda->set_submenu($SubMenuAjuda);
        
        $ItemAjuda1= new GtkImageMenuItem(Gtk::STOCK_HELP);
        
        $SubMenuAjuda->append($ItemAjuda1);
        
        $this->window->show_all();
    }

    function onArquivoNovo()
    {
        echo "Criando arquivo...\n";
    }

    function onArquivoAbrir()
    {
        echo "Abrindo Arquivo...\n";
    }

    function onEditarSim()
    {
        if ($this->item4->get_active())
        {
            echo "Sim\n";
        }
        else
        {
            echo "Nao\n";
        }
    }
}

new ExemploMenu;
Gtk::main();
?>
