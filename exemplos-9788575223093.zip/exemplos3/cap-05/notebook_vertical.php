<?php
class ExemploNotebookVertical
{
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Testando Notebook');
        $this->window->connect_simple('destroy', array('Gtk', 'main_quit'));
        $this->window->set_default_size( 300, 180);
        
        $this->notebook = new GtkNotebook;
        $this->notebook->set_tab_pos(Gtk::POS_LEFT);
        
        $this->window->add($this->notebook);
    }

    function addPage1()
    {
        $frame = new GtkFrame('Frame da pagina 1');
        $frame->set_border_width(6);
        $frame->add(new GtkLabel('Conteudo 1'));
        
        $vbox = new GtkVBox;
        
        $rotulo = new GtkLabel('Pagina 1');
        $rotulo->set_angle(90);
        
        $imagem = GtkImage::new_from_stock(Gtk::STOCK_FLOPPY, Gtk::ICON_SIZE_MENU);
        
        $vbox->pack_start($rotulo);
        $vbox->pack_start($imagem);
        $vbox->show_all();
        
        $this->notebook->append_page($frame, $vbox);
    }

    function addPage2()
    {
        $frame = new GtkFrame('Frame da pagina 2');
        $frame->set_border_width(6);
        $frame->add(new GtkLabel('Conteudo 2'));
        
        $vbox = new GtkVBox;
        
        $rotulo = new GtkLabel('Pagina 2');
        $rotulo->set_angle(90);
        
        $imagem = GtkImage::new_from_stock(Gtk::STOCK_DIALOG_QUESTION, Gtk::ICON_SIZE_MENU);
        
        $vbox->pack_start($rotulo);
        $vbox->pack_start($imagem);
        $vbox->show_all();
        
        $this->notebook->append_page($frame, $vbox);    
    }

    function Show()
    {
        $this->window->show_all();
    }
    
}

$exemplo = new ExemploNotebookVertical;
$exemplo->addPage1();
$exemplo->addPage2();
$exemplo->Show();

Gtk::Main();
?>
