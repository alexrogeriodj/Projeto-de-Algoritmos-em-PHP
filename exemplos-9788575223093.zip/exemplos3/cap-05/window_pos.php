<?php
$janela = new GtkWindow;

$screen = $janela->get_screen();
$width  = $screen->get_width();
$height = $screen->get_height();

$janela->set_size_request(200,200);

$janela->move($width - 220, $height - 270);

$janela->show_all();
Gtk::Main();
?>