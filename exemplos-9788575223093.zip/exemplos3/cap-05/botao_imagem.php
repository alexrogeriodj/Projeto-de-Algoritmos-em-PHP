<?
$window = new GtkWindow;
$window->set_default_size(120,120);
$window->set_border_width(20);
$window->set_position(GTK::WIN_POS_CENTER);

$vbox = new GtkVBox;

$button = new GtkButton;
$button->set_label('Configurar');

$imagem = GtkImage::new_from_file('icons/ico_config.png');

$button->set_image($imagem);
$vbox->pack_start($button);

$button = new GtkButton;
$button->set_label('Meus Documentos');

$imagem = GtkImage::new_from_file('icons/ico_house.png');

$button->set_image($imagem);
$vbox->pack_start($button);

$window->add($vbox);
$window->show_all();
gtk::main();
?>