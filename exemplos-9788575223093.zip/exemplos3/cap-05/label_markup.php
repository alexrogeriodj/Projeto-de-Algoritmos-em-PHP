<?
$window = new GtkWindow;
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_border_width(4);
$window->set_default_size(200,200);

$vbox = new GtkVBox;

$label = new GtkLabel();
$label->set_markup('texto: <b>negrito</b>');
$vbox->pack_start($label);

$label = new GtkLabel();
$label->set_markup('texto: <i>italico</i>');
$vbox->pack_start($label);

$label = new GtkLabel();
$label->set_markup('texto: <u>sublinhado</u>');
$vbox->pack_start($label);

$label = new GtkLabel();
$label->set_markup('<b><i><u>negrito, italico e sublinhado</u></i></b>');
$vbox->pack_start($label);

$label = new GtkLabel();
$label->set_markup('<span foreground="blue" background="gray"><b>Texto: Azul fundo cinza</b></span>');
$vbox->pack_start($label);

$label = new GtkLabel();
$label->set_markup('<span foreground="red"  background="orange"><b>Texto: Vermelho fundo laranja</b></span>');
$vbox->pack_start($label);

$window->add($vbox);

$window->show_all();
gtk::main();
?>