<?php
class ExemploColorFontButton
{
    private $window;
    private $colorbutton;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_default_size(200,100);
        $this->window->set_border_width(20);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $vbox = new GtkVBox;
        $this->window->add($vbox);
        
        $this->label      = new GtkLabel('Exemplo');
        
        $this->colorbutton = new GtkColorButton;
        $this->colorbutton->set_color(GdkColor::parse('#00FF00'));
        $this->colorbutton->set_title('Escolha a cor do bot�o');
        
        $this->fontbutton = new GtkFontButton;
        $this->fontbutton->set_font_name('Sans Bold 12');
        $this->fontbutton->set_title('Escolha a fonte do bot�o');
        
        $vbox->pack_start($this->label,      false, false);
        $vbox->pack_start($this->colorbutton, false, false);
        $vbox->pack_start($this->fontbutton, false, false);
        
        $button  = GtkButton::new_from_stock(Gtk::STOCK_REFRESH);
        $button->connect_simple('clicked', array($this, 'onClick'));
        $vbox->pack_start($button, false, false);
        
        $this->window->show_all();
    }
    
    public function onClick()
    {
        $cor = $this->colorbutton->get_color();
        $this->window->modify_bg(Gtk::STATE_NORMAL, $cor);
        
        $font = $this->fontbutton->get_font_name();
        $this->label->set_markup("<span font_desc='$font'>Exemplo !!</span>");
    }
}

new ExemploColorFontButton;
Gtk::main();
?>