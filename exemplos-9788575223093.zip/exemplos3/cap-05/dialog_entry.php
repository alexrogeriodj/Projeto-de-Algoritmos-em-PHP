<?php
$dialogo = new GtkDialog('Di�logo', null, 0,
               array( Gtk::STOCK_OK,     Gtk::RESPONSE_OK,
                      Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));

$dialogo->vbox->pack_start(new GtkLabel('Digite o nome'));
$dialogo->vbox->pack_start($a = new GtkEntry);
$dialogo->show_all();
$resposta = $dialogo->run();

if ($resposta == Gtk::RESPONSE_OK)
{
    echo 'voce digitou ' . $a->get_text() . "\n";
}
else if ($resposta == Gtk::RESPONSE_CANCEL)
{
    echo "voce cancelou\n";
}
$dialogo->destroy();
?>