<?php
$window = new GtkWindow;
$window->set_default_size(200,200);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Layout');
$window->set_border_width(10);

$layout = new GtkLayout;
$layout->set_size(400,300);

$scroll = new GtkScrolledWindow;

$scroll->add($layout);

$window->add($scroll);

$imagem = GtkImage::new_from_file('icons/splash.png');

$layout->put($imagem, 0, 0);

$window->show_all();
Gtk::main();
?>
