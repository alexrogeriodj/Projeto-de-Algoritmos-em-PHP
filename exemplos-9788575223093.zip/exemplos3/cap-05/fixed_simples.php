<?php
$window = new GtkWindow;
$window->set_title('fixed');
$window->set_position(GTK::WIN_POS_CENTER);

$fixed = new GtkFixed;
$window->add($fixed);

$imagem = GtkImage::new_from_file('icons/trabalhando.png');
$fixed->put($imagem, 0, 0);

$label = new GtkLabel();
$label->set_markup('<b>Demonstra��o</b>');
$fixed->put($label, 4, 4);

$entry = new GtkEntry('digite aqui...');
$fixed->put($entry, 80, 140);

$botao = new GtkButton(' bot�o ');
$fixed->put($botao, 220, 240);

$window->show_all();
Gtk::Main();
?>