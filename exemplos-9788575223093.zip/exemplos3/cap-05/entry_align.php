<?php
$window = new GtkWindow;
$window->set_default_size(120,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Entrada de Texto');
$window->set_border_width(20);

$vbox = new GtkVBox;
$label1 = new GtkLabel('C�digo: ');
$label2 = new GtkLabel('Nome: ');
$label3 = new GtkLabel('Senha: ');

$label1->set_size_request(140, -1);
$label2->set_size_request(140, -1);
$label3->set_size_request(140, -1);

$label1->set_alignment(1, 0.5); // xAlign, yAlign
$label2->set_alignment(1, 0.5); // xAlign, yAlign
$label3->set_alignment(1, 0.5); // xAlign, yAlign

$codigo = new GtkEntry('Digite o c�digo.');
$nome   = new GtkEntry('Digite o nome...');
$senha  = new GtkEntry('');
$senha->set_visibility(false);

$hbox1 = new GtkHBox;
$hbox2 = new GtkHBox;
$hbox3 = new GtkHBox;

$hbox1->pack_start($label1);
$hbox1->pack_start($codigo);

$hbox2->pack_start($label2);
$hbox2->pack_start($nome);

$hbox3->pack_start($label3);
$hbox3->pack_start($senha);

$vbox->pack_start($hbox1);
$vbox->pack_start($hbox2);
$vbox->pack_start($hbox3);

$window->add($vbox);
$window->show_all();
Gtk::main();
?>