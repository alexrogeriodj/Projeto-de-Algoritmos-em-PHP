<?php
function onCalculaIMC($hscale1, $hscale2)
{
    $peso   = $hscale1->get_value();
    $altura = $hscale2->get_value();
    
    $indice = $peso / ($altura * $altura);
    
    if ($indice < 18.5)
    {
        $texto = 'abaixo do peso';
    }
    else if ($indice >= 18.5 and $indice <= 25)
    {
        $texto = 'no peso normal';
    }
    else if ($indice > 25 and $indice <= 30)
    {
        $texto = 'acima do peso';
    }
    else if ($indice > 30)
    {
        $texto = 'obeso';
    }
    
    $info = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                 Gtk::BUTTONS_OK, NULL);
    $info->set_markup("indice: <b>$indice</b>\n<i>$texto</i>");
    
    $info->run();
    $info->destroy();
}

$window = new GtkWindow;
$window->set_default_size(400,40);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('HScale');
$window->set_border_width(10);

$vbox = new GtkVBox;

$hbox1 = new GtkHBox;
$hbox2 = new GtkHBox;

$hscale1 = new GtkHScale(new GtkAdjustment(20, 1, 200, 0.1, 10, 0));
$hscale2 = new GtkHScale(new GtkAdjustment(20, 0, 3,   0.1, 0.1, 0));

$hscale1->set_value(70);
$hscale2->set_value(1.75);

$label1 = new GtkLabel('Peso (Kg)');
$label2 = new GtkLabel('Altura (Mt)');
$label1->set_size_request(100, -1);
$label2->set_size_request(100, -1);

$hbox1->pack_start($label1, false, false);
$hbox1->pack_start($hscale1);
$hbox2->pack_start($label2, false, false);
$hbox2->pack_start($hscale2);

$botao = new GtkButton('Calcula �ndice de massa corporal');

$botao->connect_simple('clicked', 'onCalculaIMC', $hscale1, $hscale2);

$vbox->pack_start($hbox1);
$vbox->pack_start($hbox2);
$vbox->pack_start($botao);

$window->add($vbox);

$window->show_all();
Gtk::main();
?>