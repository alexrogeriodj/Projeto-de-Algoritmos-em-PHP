<?php
class ExemploRadioButton
{
    private $window;
    private $ingles;
    private $italiano;
    private $espanhol;
    private $frances;
    private $alemao;

    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('radio');
        $this->window->set_default_size(200,200);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_border_width(20);
        
        $vbox = new GtkVBox;
        $this->window->add($vbox);
        
        $label          = new GtkLabel('Selecione sua linguagem:');
        
        $this->ingles   = new GtkRadioButton(null,          'Ingles');
        $this->italiano = new GtkRadioButton($this->ingles, 'Italiano');
        $this->espanhol = new GtkRadioButton($this->ingles, 'Espanhol');
        $this->frances  = new GtkRadioButton($this->ingles, 'Franc�s');
        $this->alemao   = new GtkRadioButton($this->ingles, 'Alem�o');
        
        $button  = GtkButton::new_from_stock(Gtk::STOCK_OK);
        $button->connect_simple('clicked', array($this, 'onClick'));
        
        $vbox->pack_start($label,           false, false);
        $vbox->pack_start($this->ingles,    false, false);
        $vbox->pack_start($this->italiano,  false, false);
        $vbox->pack_start($this->espanhol,  false, false);
        $vbox->pack_start($this->frances,   false, false);
        $vbox->pack_start($this->alemao,    false, false);
        $vbox->pack_start($button,          false, false);
        
        $this->window->show_all();
    }
    
    public function onClick()
    {
        $texto = '';
        $texto = $this->ingles->get_active()    ? 'Ingles'   : $texto;
        $texto = $this->italiano->get_active()  ? 'Italiano' : $texto;
        $texto = $this->espanhol->get_active()  ? 'Espanhol' : $texto;
        $texto = $this->frances->get_active()   ? 'Franc�s'  : $texto;
        $texto = $this->alemao->get_active()    ? 'Alem�o'   : $texto;
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, "Voc� escolheu: $texto");
        $dialog->run();
        $dialog->destroy();
    }
}

new ExemploRadioButton;
Gtk::main();
?>
