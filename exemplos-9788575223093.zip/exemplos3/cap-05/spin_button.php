<?php
$window = new GtkWindow;
$window->set_default_size(160,160);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Entrada de Texto');
$window->set_border_width(20);

$vbox = new GtkVBox;

$label1 = new GtkLabel('Dia');
$label2 = new GtkLabel('M�s');
$label3 = new GtkLabel('Ano');

$day   = GtkSpinButton::new_with_range(1,31,1);
$month = GtkSpinButton::new_with_range(1,12,1);
$year  = GtkSpinButton::new_with_range(1900,2060,1);

$box1 = new GtkHBox;
$box2 = new GtkHBox;
$box3 = new GtkHBox;

$box1->pack_start($label1);
$box1->pack_start($day);
$box2->pack_start($label2);
$box2->pack_start($month);
$box3->pack_start($label3);
$box3->pack_start($year);

$vbox->pack_start($box1);
$vbox->pack_start($box2);
$vbox->pack_start($box3);

$window->add($vbox);
$window->show_all();
Gtk::main();
?>