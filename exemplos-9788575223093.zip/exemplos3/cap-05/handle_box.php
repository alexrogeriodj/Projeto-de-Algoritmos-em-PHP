<?
$window = new GtkWindow;
$window->set_default_size(300,150);

$vbox = new GtkVBox;

$handlebox = new GtkHandleBox;
$vbox->pack_start($handlebox, false, false);

$hbox = new GtkHBox;
$handlebox->add($hbox);

$button = GtkButton::new_from_stock(Gtk::STOCK_OPEN);
$hbox->pack_start($button, false, false);

$button = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
$hbox->pack_start($button, false, false);

$button = GtkButton::new_from_stock(Gtk::STOCK_QUIT);
$hbox->pack_start($button, false, false);

$window->add($vbox);

$window->show_all();
gtk::main();
?>