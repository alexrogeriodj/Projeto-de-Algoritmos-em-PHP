<?php
class ExemploToggleButton
{
    private $window;
    private $toggle1;
    private $toggle2;
    private $toggle3;
    private $toggle4;
    private $toggle5;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('toggle');
        $this->window->set_default_size(200,200);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_border_width(20);
        $vbox = new GtkVBox;
        $this->window->add($vbox);
        
        $label         = new GtkLabel('H�bitos');
        
        $this->toggle1 = new GtkToggleButton('Fumar');
        $this->toggle2 = new GtkToggleButton('Beber');
        $this->toggle3 = new GtkToggleButton('Sedentarismo');
        $this->toggle4 = new GtkToggleButton('Obesidade');
        $this->toggle5 = new GtkToggleButton('Subnutrido');
        
        $this->toggle1->set_data(0, 30); // 30 pontos
        $this->toggle2->set_data(0, 20); // 20 pontos
        $this->toggle3->set_data(0, 20); // 20 pontos
        $this->toggle4->set_data(0, 30); // 30 pontos
        $this->toggle5->set_data(0, 20); // 20 pontos
        
        $button  = GtkButton::new_from_stock(Gtk::STOCK_OK);
        $button->connect_simple('clicked', array($this, 'onClick'));
        
        $vbox->pack_start($label,   false, false);
        $vbox->pack_start($this->toggle1, false, false);
        $vbox->pack_start($this->toggle2, false, false);
        $vbox->pack_start($this->toggle3, false, false);
        $vbox->pack_start($this->toggle4, false, false);
        $vbox->pack_start($this->toggle5, false, false);
        $vbox->pack_start($button,  false, false);
        
        $this->window->show_all();
    }

    public function onClick()
    {
        $soma = 0;
        $soma += $this->toggle1->get_active() ? $this->toggle1->get_data(0) : 0;
        $soma += $this->toggle2->get_active() ? $this->toggle2->get_data(0) : 0;
        $soma += $this->toggle3->get_active() ? $this->toggle3->get_data(0) : 0;
        $soma += $this->toggle4->get_active() ? $this->toggle4->get_data(0) : 0;
        $soma += $this->toggle5->get_active() ? $this->toggle5->get_data(0) : 0;
        
        if ($soma == 0)
            $mensagem = 'Voc� est� bem, continue assim..';
        else if (($soma > 0) and ($soma <= 30))
            $mensagem = 'Tente eliminar o seu v�cio...';
        else if (($soma > 30) and ($soma <= 60))
            $mensagem = 'Voc� t� mal cara, melhor se cuidar...';
        else
            $mensagem = 'Voc� est� com um p� na cova...';
            
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, $mensagem);
        $dialog->run();
        $dialog->destroy();
    }
}

new ExemploToggleButton;
Gtk::main();
?>