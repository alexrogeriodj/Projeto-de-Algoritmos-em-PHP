<?php
$window = new GtkWindow;
$window->set_default_size(280,100);
$window->set_border_width(20);
$window->set_position(GTK::WIN_POS_CENTER);

$toolbar = new GtkToolbar;

$open = new GtkToolButton;
$open->set_label('open');
$open->set_stock_id('gtk-open');

$save = new GtkToolButton;
$save->set_label('save');
$save->set_stock_id('gtk-save');

$toggle = new GtkToggleToolButton;
$toggle->set_label('Toggle');
$toggle->set_stock_id('gtk-apply');

$menubutton = new GtkMenuToolButton(GtkImage::new_from_stock('gtk-index', Gtk::ICON_SIZE_BUTTON), 'Menu');

$menu = new GtkMenu;
$item1= new GtkImageMenuItem(GTK::STOCK_DIALOG_INFO);
$menu->append($item1);
$menu->show_all();

$menubutton->set_menu($menu);

$toolbar->insert($open,  0);
$toolbar->insert($save,   1);
$toolbar->insert($toggle, 2);
$toolbar->insert($menubutton,  3);

$window->add($toolbar);

$window->show_all();
Gtk::Main();
?>
