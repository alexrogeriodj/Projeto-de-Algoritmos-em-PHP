<?
$window = new GtkWindow;
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_border_width(4);

$vbox = new GtkVBox;

$label = new GtkLabel('Nome');

$entry = new GtkEntry;

$vbox->pack_start($label, false, false);
$vbox->pack_start($entry, false, false);

$expander = new GtkExpander('<b><i>Ajuda</i></b>');
$expander->set_use_markup(true);

$help = new GtkLabel;
$help->set_alignment(0.2, 0.5);
$help->set_markup('Para preencher o formul�rio
n�o deixe o campo Nome Vazio');

$expander->add($help);
$expander->set_expanded(true);

$vbox->pack_start($expander, false, false);

$window->add($vbox);
$window->show_all();
Gtk::main();
?>