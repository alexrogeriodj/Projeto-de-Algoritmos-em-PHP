<?php
$dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_ERROR,
                                     Gtk::BUTTONS_OK, NULL);

$dialog->set_markup('<b><i>Opera��o Ilegal</i></b>');

$dialog->run();
$dialog->destroy();
?>