<?php
class ExemploEntry
{
    private $window;
    private $entry;
    private $button;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->move(200,200);
        $this->window->set_default_size(140,100);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_title('Entrada de Texto');
        $this->window->set_border_width(20);
        
        $vbox = new GtkVBox;
        
        $this->entry  = new GtkEntry('Digite o nome...');
        
        $this->button = new GtkButton('_Imprime...');
        $this->button->connect_simple('clicked', array($this, 'onClick'));
        
        $vbox->pack_start($this->entry);
        $vbox->pack_start($this->button);
        
        $this->window->add($vbox);
        $this->window->show_all();
    }

    function onClick()
    {
        $nome = $this->entry->get_text();
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK,
                                             "Voc� digitou: $nome");
        $dialog->run();
        $dialog->destroy();
        $this->entry->set_text('');
        $this->window->set_focus($this->entry);
    }
}

new ExemploEntry;
Gtk::main();
?>