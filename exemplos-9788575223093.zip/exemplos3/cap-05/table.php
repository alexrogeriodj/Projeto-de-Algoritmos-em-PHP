<?
$window = new GtkWindow;
$window->set_size_request(200,140);
$window->set_title('Tables');

$table = new GtkTable(7,7);
$table->set_row_spacings(2);
$table->set_col_spacings(2);

$table->attach(new GtkButton('a'), 0, 1, 0, 1, Gtk::EXPAND + Gtk::FILL, Gtk::EXPAND + Gtk::FILL, 4, 4);
$table->attach(new GtkButton('b'), 1, 2, 0, 1, Gtk::EXPAND + Gtk::FILL, Gtk::EXPAND + Gtk::FILL, 4, 4);
$table->attach(new GtkButton('c'), 2, 3, 0, 1, Gtk::EXPAND + Gtk::FILL, Gtk::EXPAND + Gtk::FILL, 4, 4);

$table->attach(new GtkButton('e'), 0, 3, 1, 2, Gtk::EXPAND + Gtk::FILL, Gtk::EXPAND + Gtk::FILL, 4, 4);
$table->attach(new GtkButton('f'), 3, 4, 0, 2, Gtk::EXPAND + Gtk::FILL, Gtk::EXPAND + Gtk::FILL, 4, 4);

$window->add($table);

$window->show_all();
Gtk::Main();
?>