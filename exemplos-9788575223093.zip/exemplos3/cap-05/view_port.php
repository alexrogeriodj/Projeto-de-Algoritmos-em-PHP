<?php
$window = new GtkWindow;
$window->set_default_size(200,200);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Viewport');
$window->set_border_width(10);

$scroll = new GtkScrolledWindow;
$window->add($scroll);

$viewport = new GtkViewport;
$scroll->add($viewport);

$vbox = new GtkVBox;
$viewport->add($vbox);

for ($n=1; $n<=14; $n++)
{
    $hbox = new GtkHBox;
    
    $a = new GtkLabel(' C�digo ');
    $b = new GtkEntry('digite...');
    
    $hbox->pack_start($a);
    $hbox->pack_start($b);
    $vbox->pack_start($hbox);
}

$window->show_all();
Gtk::main();
?>