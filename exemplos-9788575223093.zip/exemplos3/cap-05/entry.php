<?php
$window = new GtkWindow;
$window->set_default_size(140,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Entrada de Texto');
$window->set_border_width(20);

$entry = new GtkEntry('Texto Inicial');

$window->add($entry);

$window->show_all();
Gtk::main();
?>