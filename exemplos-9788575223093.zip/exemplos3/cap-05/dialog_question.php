<?php
$dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_QUESTION,
                               Gtk::BUTTONS_YES_NO, 'Deseja continuar ?');

$response = $dialog->run();

if ($response == Gtk::RESPONSE_YES)
    echo "Voce escolheu sim\n";
if ($response == Gtk::RESPONSE_DELETE_EVENT)
    echo "Voce fechou a janela\n";
    
$dialog->destroy();
?>