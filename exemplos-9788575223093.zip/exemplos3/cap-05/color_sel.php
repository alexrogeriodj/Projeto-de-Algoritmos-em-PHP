<?php
$dialog = new GtkColorSelectionDialog('Selecione a Cor');

$dialog->colorsel->set_current_color(GdkColor::parse("#FF0000"));

$response = $dialog->run();

if ($response == Gtk::RESPONSE_OK)
{
    $color  = $dialog->colorsel->get_current_color();
    $rgb = GtkColorSelection::palette_to_string(array($color));

    $info = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                       Gtk::BUTTONS_OK, '');
    $info->set_markup("<span foreground='$rgb'><b>COR ESCOLHIDA</b></span>");
    
    $info->run();
    $info->destroy();
}
$dialog->destroy();
Gtk::main();
?>