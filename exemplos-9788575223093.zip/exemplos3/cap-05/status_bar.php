<?php
class ExemploStatusBar
{
    public function __construct()
    {
        $window = new GtkWindow;
        $window->set_default_size(300,200);
        $window->set_position(GTK::WIN_POS_CENTER);
        $window->set_title('Status Bar');
        $window->set_border_width(10);
        
        $vbox = new GtkVBox;
        $this->status = new GtkStatusBar;
        
        $vbox->pack_start($a = new GtkButton('Formatar'), false, false);
        $vbox->pack_start($b = new GtkButton('Desfragmentar'), false, false);
        $vbox->pack_start(new GtkHbox, true, true);
        $vbox->pack_start($this->status, false, false);
        
        $a->connect('enter', array($this, 'onEnter'));
        $b->connect('enter', array($this, 'onEnter'));
        $a->connect('leave', array($this, 'onLeave'));
        $b->connect('leave', array($this, 'onLeave'));
        
        $this->status->push(1, 'Texto inicial...');
        
        $window->add($vbox);
        $window->show_all();
    }

    public function onEnter($widget)
    {
        $this->status->push(1, 'Clique aqui para ' . $widget->get_label());
    }

    public function onLeave($widget)
    {
        $this->status->pop(1);
    }
}

new ExemploStatusBar;
Gtk::main();
?>