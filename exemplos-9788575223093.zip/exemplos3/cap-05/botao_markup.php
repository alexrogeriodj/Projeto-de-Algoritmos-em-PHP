<?
$window = new GtkWindow;
$window->set_border_width(10);
$window->set_default_size(120,100);
$window->set_position(GTK::WIN_POS_CENTER);
$vbox = new GtkVBox;

$button = new GtkButton;
$label = new GtkLabel();
$label->set_markup('link: <span foreground="blue"><u>www.php-gtk.com.br</u></span>');

$button->set_relief(Gtk::RELIEF_NONE);
$button->connect_simple('clicked', 'onLoadURL', 'http://www.php-gtk.com.br');
$button->add($label);
$vbox->pack_start($button, false, false);

$button = new GtkButton;
$label = new GtkLabel();
$label->set_markup('link: <span foreground="blue"><u>www.pablo.blog.br</u></span>');
$button->set_relief(Gtk::RELIEF_NONE);
$button->connect_simple('clicked', 'onLoadURL', 'http://www.pablo.blog.br');
$button->add($label);
$vbox->pack_start($button, false, false);

$window->add($vbox);
$window->show_all();
Gtk::main();

function onLoadURL($url)
{
	if (strtoupper(substr(PHP_OS, 0,3)) == 'WIN')
		exec("explorer $url >NULL &");
	else
		exec("firefox $url >/dev/null &");
}
?>
