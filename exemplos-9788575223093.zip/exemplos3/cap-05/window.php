<?php
function onClose()
{
    echo "Volte logo !\n";
    Gtk::main_quit();
}

$window = new GtkWindow;
$window->set_default_size(200,200);
$window->set_title('Primeira Janela');
$window->set_icon(GdkPixbuf::new_from_file('icons/ico_smile.png'));
$window->set_position(GTK::WIN_POS_CENTER);

$window->connect_simple('destroy', 'onClose');

$window->show_all();
Gtk::main();
?>