<?php
class ExemploCheckButton
{
    private $window;
    private $check1;
    private $check2;
    private $check3;
    private $check4;
    private $check5;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('check');
        $this->window->set_default_size(200,200);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_border_width(20);
        
        $vbox = new GtkVBox;
        $this->window->add($vbox);
        
        $label        = new GtkLabel('Fa�a seu pedido:');
        $this->check1 = new GtkCheckButton('Calabresa');
        $this->check2 = new GtkCheckButton('Frango');
        $this->check3 = new GtkCheckButton('Mussarela');
        $this->check4 = new GtkCheckButton('Atum');
        $this->check5 = new GtkCheckButton('Napolitana');
        
        $button  = GtkButton::new_from_stock(Gtk::STOCK_OK);
        $button->connect_simple('clicked', array($this, 'onClick'));
        
        $vbox->pack_start($label,   false, false);
        $vbox->pack_start($this->check1, false, false);
        $vbox->pack_start($this->check2, false, false);
        $vbox->pack_start($this->check3, false, false);
        $vbox->pack_start($this->check4, false, false);
        $vbox->pack_start($this->check5, false, false);
        $vbox->pack_start($button,  false, false);
        $this->window->show_all();
    }
    
    public function onClick()
    {
        $texto  = '';
        $texto .= $this->check1->get_active() ? "* <b> Calabresa </b> \n"   : '';
        $texto .= $this->check2->get_active() ? "* <b> Frango </b> \n"      : '';
        $texto .= $this->check3->get_active() ? "* <b> Mussarela </b> \n"   : '';
        $texto .= $this->check4->get_active() ? "* <b> Atum </b> \n"        : '';
        $texto .= $this->check5->get_active() ? "* <b> Napolitana </b> \n"  : '';
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, NULL);
        $dialog->set_markup("Voc� escolheu: \n$texto");
        $dialog->run();
        $dialog->destroy();
    }
}

new ExemploCheckButton;
Gtk::main();
?>
