<?php
$window = new GtkWindow;

$entry = new GtkEntry();

$store = new GtkListStore(GObject::TYPE_STRING);

$store->append(array('Ainsley'));
$store->append(array('Aland'));
$store->append(array('Albern'));
$store->append(array('Alcott'));
$store->append(array('Alden'));
$store->append(array('Aldercy'));
$store->append(array('Alderney'));
$store->append(array('Aldora'));
$store->append(array('Aldred'));
$store->append(array('Aldrich'));

$completion = new GtkEntryCompletion;
$completion->set_model($store);
$completion->set_text_column(0);
$entry->set_completion($completion);

$window->add($entry);
$window->show_all();
Gtk::Main();
?>