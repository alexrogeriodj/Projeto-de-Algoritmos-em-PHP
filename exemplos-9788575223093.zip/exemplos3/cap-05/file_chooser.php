<?php
$dialog = new GtkFileChooserDialog('Selecione o arquivo', NULL,
              Gtk::FILE_CHOOSER_ACTION_OPEN,
              array(Gtk::STOCK_OK,     Gtk::RESPONSE_OK,
                    Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));

$filter = new GtkFileFilter;
$filter->set_name('PHP Files');
$filter->add_pattern('*.php');
$dialog->add_filter($filter);

$response = $dialog->run();

if ($response == Gtk::RESPONSE_OK)
{
    $info = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                 Gtk::BUTTONS_OK,
                                 $dialog->get_filename());
    $info->run();
    $info->destroy();
}
$dialog->destroy();

Gtk::main();
?>