<?php
$window = new GtkWindow;
$window->set_default_size(400,200);

$vbox = new GtkVBox;

$window->add($vbox);

$tipos = array(Gtk::BUTTONBOX_SPREAD, Gtk::BUTTONBOX_EDGE,
               Gtk::BUTTONBOX_START,  Gtk::BUTTONBOX_END);

foreach ($tipos as $tipo)
{
    $box = new GtkHButtonBox;
    $box->set_layout($tipo);
    $box->set_spacing(10);
    
    $box->add(GtkButton::new_from_stock(Gtk::STOCK_YES));
    $box->add(GtkButton::new_from_stock(Gtk::STOCK_NO));
    $box->add(GtkButton::new_from_stock(Gtk::STOCK_CANCEL));
    
    $vbox->pack_start($box);
    $vbox->pack_start(new GtkHSeparator);
}

$window->show_all();
Gtk::main();
?>
