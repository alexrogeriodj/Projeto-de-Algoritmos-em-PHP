<?php
$window = new GtkWindow;
$window->set_default_size(200,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Frame');
$window->set_border_width(10);

$frame = new GtkFrame('Frame');

$window->add($frame);

$frame->add(new GtkLabel('Conte�do do Frame'));

$window->show_all();
Gtk::main();
?>