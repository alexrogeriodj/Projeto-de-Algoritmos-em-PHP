<?php
$window = new GtkWindow;
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('VSeparator');
$window->set_border_width(10);

$hbox = new GtkHBox;

$button1 = new GtkButton('botao1');
$button2 = new GtkButton('botao2');
$button3 = new GtkButton('botao3');

$hbox->pack_start($button1);
$hbox->pack_start($button2);
$hbox->pack_start(new GtkVSeparator);
$hbox->pack_start($button3);

$window->add($hbox);

$window->show_all();
Gtk::main();
?>