<?php
class ExemploCalendar
{
    private $window;
    private $calendar;
    private $dataSelecionada;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_default_size(140,100);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_title('Calendar');
        $this->window->set_border_width(20);
        
        $vbox = new GtkVBox;
        
        $this->calendar = new GtkCalendar;
        $this->calendar->connect_simple('day-selected', array($this, 'onSelect'));
        $this->dataSelecionada = new GtkEntry;
        
        $vbox->pack_start($this->calendar);
        $vbox->pack_start($this->dataSelecionada);
        
        $this->window->add($vbox);
        $this->window->show_all();
    }
    
    public function onSelect()
    {
        $date = $this->calendar->get_date();
        
        $meses[1]  = 'Janeiro';
        $meses[2]  = 'Fevereiro';
        $meses[3]  = 'Mar�o';
        $meses[4]  = 'Abril';
        $meses[5]  = 'Maio';
        $meses[6]  = 'Junho';
        $meses[7]  = 'Julho';
        $meses[8]  = 'Agosto';
        $meses[9]  = 'Setembro';
        $meses[10] = 'Outubro';
        $meses[11] = 'Novembro';
        $meses[12] = 'Dezembro';
        
        $year  = $date[0];
        $month = $date[1] + 1; // numera��o come�a em zero
        $day   = $date[2];
        $nome_mes = $meses[$month];
        
        $this->dataSelecionada->set_text("$day de $nome_mes de $year");
	} 
}

new ExemploCalendar;
Gtk::Main();
?>