<?
class ExemploPopUp
{
    private $window;
    private $botao;
    private $menu;
    
    function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_size_request(240,140);
        $this->window->set_position(GTK::WIN_POS_CENTER);  
        
        $fixed = new GtkFixed;
        $this->window->add($fixed);
        
        $this->botao = new GtkButton('clique aqui');
        
        $fixed->put($this->botao, 80, 50);
        
        $this->botao->connect_simple('clicked', array($this, 'onClick'));
        
        $this->window->show_all();
    }

    function onClick()
    {
        $this->menu = new GtkMenu;
        
        $item1= new GtkImageMenuItem(GTK::STOCK_DIALOG_INFO);
        $item2= new GtkImageMenuItem('Informa��es do PHP');
        
        $imagem = GtkImage::new_from_file('icons/ico_php.png');
        $item2->set_image($imagem);
        
        $item1->connect_simple('activate', array($this, 'onItem1Click'));
        $item2->connect_simple('activate', array($this, 'onItem2Click'));
        
        $this->menu->append($item1);
        $this->menu->append($item2);
        
        $this->menu->show_all();
        $this->menu->popup();
    }
    
    function onItem1Click()
    {
        $texto  = 'Sistema Operacional: ' . PHP_OS . "\n";
        $texto .= 'Pasta Pessoal: '       . $_ENV['HOME'] . "\n";
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, $texto);
        $dialog->run();
        $dialog->destroy();
    }
    
    function onItem2Click()
    {
        $texto  = 'Vers�o do PHP :    ' . phpversion() . "\n";
        $texto .= 'Vers�o do PHP-GTK: ' . phpversion('php-gtk') . "\n";
        $texto .= 'Vers�o do GTK:     ' . gtk::get_version();
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, $texto);
        $dialog->run();
        $dialog->destroy();
    }
}

new ExemploPopUp;
Gtk::main();
?>