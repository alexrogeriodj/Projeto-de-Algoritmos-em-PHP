<?
$window = new GtkWindow;
$window->set_default_size(200,200);

$vbox = new GtkVBox;

$imagem1 = GtkImage::new_from_stock(Gtk::STOCK_ADD, Gtk::ICON_SIZE_DIALOG);
$vbox->pack_start($imagem1);

$imagem2 = GtkImage::new_from_stock(Gtk::STOCK_DELETE, Gtk::ICON_SIZE_BUTTON);
$vbox->pack_start($imagem2);

$imagem3 = new GtkImage;
$imagem3->set_from_stock('gtk-dialog-question', Gtk::ICON_SIZE_DND);
$vbox->pack_start($imagem3);

$imagem4 = new GtkImage;
$imagem4->set_from_stock('gtk-floppy', Gtk::ICON_SIZE_MENU);
$vbox->pack_start($imagem4);

$window->add($vbox);

$window->show_all();
gtk::main();
?>