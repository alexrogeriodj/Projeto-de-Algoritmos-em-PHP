<?
$window = new GtkWindow;
$window->set_default_size(120,100);

$vbox = new GtkVBox;

$button = GtkButton::new_from_stock(Gtk::STOCK_OK);
$vbox->pack_start($button);

$button = GtkButton::new_from_stock(Gtk::STOCK_CANCEL);
$vbox->pack_start($button);

$button = GtkButton::new_from_stock(Gtk::STOCK_FLOPPY);
$vbox->pack_start($button);

$window->add($vbox);
$window->show_all();
gtk::main();
?>