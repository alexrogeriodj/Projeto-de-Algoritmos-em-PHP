<?php
function onClick($entry, $window)
{
    $nome = $entry->get_text();
    echo "O nome digitado foi : $nome \n";
    $entry->set_text('');
    $window->set_focus($entry);
}

$window = new GtkWindow;
$window->move(200,200);
$window->set_default_size(140,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Entrada de Texto');
$window->set_border_width(20);

$vbox = new GtkVBox;

$entry  = new GtkEntry('Digite o nome...');

$button = new GtkButton('Imprime...');

$button->connect_simple('clicked', 'onClick', $entry, $window);

$vbox->pack_start($entry);
$vbox->pack_start($button);
$window->add($vbox);

$window->show_all();
Gtk::main();
?>