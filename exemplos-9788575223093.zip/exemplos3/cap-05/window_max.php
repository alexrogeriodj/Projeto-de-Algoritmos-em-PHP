<?php
$window = new GtkWindow;

$window->maximize();

$window->set_title('Maximizar');
$window->show_all();
Gtk::Main();
?>