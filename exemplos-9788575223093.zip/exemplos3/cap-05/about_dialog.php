<?php
function onAbout()
{
    $dialogo = new GtkAboutDialog;
    
    $dialogo->set_name('Tabajara');
    $dialogo->set_version('4.0');
    
    $dialogo->set_comments("Super Tradutor\nDispon�vel em Portugu�s");
    $dialogo->set_copyright('Copyright (C) 2000-2007 Airton Senna');
    $dialogo->set_license("GPL\nEste aplicativo � um software livre\nVisite www.fsf.org.");
    $dialogo->set_logo(GdkPixbuf::new_from_file('icons/ico_mouse.png'));
    $dialogo->set_website('http://www.site-do-tabajara.com');
    $dialogo->set_website_label('site do tabajara');
    $dialogo->set_translator_credits("Vers�o em Portugu�s - Manuel\nVers�o Ingl�s- John");
    $dialogo->set_artists(array('Picasso', 'Da Vinci')); 
    $dialogo->set_authors(array('Linus Torvalds', 'Richard Stallmann')); 
    $dialogo->set_documenters(array('Paulo Coelho', 'Dan Brown')); 

    $dialogo->run();
}

$window = new GtkWindow;
$window->set_default_size(200,200);
$window->set_border_width(80);
$window->set_position(GTK::WIN_POS_CENTER);

$button  = GtkButton::new_from_stock(Gtk::STOCK_ABOUT);

$button->connect_simple('clicked', 'onAbout');

$window->add($button);
$window->show_all();
Gtk::Main();
?>