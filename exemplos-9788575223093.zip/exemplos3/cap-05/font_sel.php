<?php
$dialog = new GtkFontSelectionDialog('Selecione a Fonte');

$dialog->set_font_name('Sans Bold 12');

$response = $dialog->run();

if ($response == Gtk::RESPONSE_OK)
{
    $info = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                 Gtk::BUTTONS_OK, $dialog->get_font_name());
    $info->run();
    $info->destroy();
}
$dialog->destroy();
Gtk::main();
?>