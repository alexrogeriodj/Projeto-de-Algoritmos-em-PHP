<?php
$dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                     Gtk::BUTTONS_OK,
                                     'Warning: Saldo insuficiente !!');

$ok_button = $dialog->add_button(Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL);

$response = $dialog->run();

if ($response == Gtk::RESPONSE_OK)
    echo "Voce escolheu OK\n";
if ($response == Gtk::RESPONSE_CANCEL)
    echo "Voce escolheu CANCEL\n";

$dialog->destroy();
?>