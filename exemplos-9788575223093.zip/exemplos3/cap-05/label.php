<?php
$window = new GtkWindow;
$window->set_default_size(200,200);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Label');

$label = new GtkLabel('Al� Mundo');

$window->add($label);

$window->show_all();
Gtk::main();
?>