<?
$window = new GtkWindow;
$window->set_default_size(200,200);

$imagem = GtkImage::new_from_file('icons/gnome.png');

$window->add($imagem);

$window->show_all();
gtk::main();
?>
