<?
class ExemploProgressBar
{
    private $window;
    private $progress;
    private $valor;
    private $maximo;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_default_size(140,100);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        $this->window->set_title('Progress');
        $this->window->set_border_width(20);
        
        $this->progress = new GtkProgressBar();
        $this->progress->set_fraction(0);
        $this->progress->set_text('Processando...');
        
        $this->window->add($this->progress);
        
        $this->window->show_all();
    }
    
    public function processaAlgo()
    {
        $this->maximo = 1000000;
        
        Gtk::timeout_add(100, array($this, 'refreshProgressBar'));
        
        for ($this->valor=0; $this->valor <= $this->maximo; $this->valor ++)
        {
            while (gtk::events_pending())
            {
                gtk::main_iteration();
            }
        }
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK,
                                             "Fim do processamento");
        $dialog->run();
        $dialog->destroy();
    }

    function refreshProgressBar()
    {
        $indice = round($this->valor/$this->maximo, 2);
        
        $percentual = (int) ($indice * 100);
        
        if ($percentual <= 100)
        {
            $this->progress->set_fraction($indice);
            $this->progress->set_text($percentual . ' %');
            if ($percentual !== 100)
                Gtk::timeout_add(100, array($this, 'refreshProgressBar')); // a cada decimo de segundo
        }
    }
}

$objeto = new ExemploProgressBar;
$objeto->processaAlgo();
Gtk::Main();
?>
