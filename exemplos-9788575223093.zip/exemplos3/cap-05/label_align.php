<?
$window = new GtkWindow;
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_default_size(200,-1);

$vbox = new GtkVBox;

$label = new GtkLabel('alinhado esquerda');
$label->set_alignment(0,0); // xAlign, yAlign
$vbox->pack_start($label, false, false);

$vbox->pack_start(new GtkHSeparator, false, false);

$label = new GtkLabel('alinhado central');
$label->set_alignment(0.5,0); // xAlign, yAlign
$vbox->pack_start($label, false, false);

$vbox->pack_start(new GtkHSeparator, false, false);

$label = new GtkLabel('alinhado direita');
$label->set_alignment(1,0); // xAlign, yAlign
$vbox->pack_start($label, false, false);

$vbox->pack_start(new GtkHSeparator, false, false);

$window->add($vbox);

$window->show_all();
gtk::main();
?>