<?php
$window = new GtkWindow;
$window->set_default_size(300,200);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('HPaned');
$window->set_border_width(10);

$paned = new GtkHPaned;
$paned->set_position(100);

$window->add($paned);

$paned->add1(new GtkTextView);
$paned->add2(new GtkLabel('Label'));

$window->show_all();
Gtk::main();
?>