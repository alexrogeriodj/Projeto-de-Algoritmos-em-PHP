<?php
$window = new GtkWindow;
$window->set_size_request(400,300);
$window->set_title('Exemplo de TextView');

$scroll = new GtkScrolledWindow;

$textview   = new GtkTextView;
$textbuffer = new GtkTextBuffer;

$textview->set_buffer($textbuffer);

$bold       = new GtkTextTag;
$italic     = new GtkTextTag;
$underline  = new GtkTextTag;

$bold->set_property('weight', pango::WEIGHT_BOLD);
$italic->set_property('style', pango::STYLE_ITALIC);
$underline->set_property('underline', pango::UNDERLINE_SINGLE);

$tagtable=$textbuffer->get_tag_table();
$tagtable->add($bold);
$tagtable->add($italic);
$tagtable->add($underline);

$inicio_bold = $textbuffer->create_mark('inicio_bold', $textbuffer->get_start_iter(), true);
$textbuffer->insert_at_cursor("Negrito\n");
$fim_bold = $textbuffer->create_mark('fim_bold', $textbuffer->get_end_iter(), true);

$start = $textbuffer->get_iter_at_mark($inicio_bold);
$end   = $textbuffer->get_iter_at_mark($fim_bold);
$textbuffer->apply_tag($bold, $start, $end);

$inicio_italico= $textbuffer->create_mark('inicio_italico', $textbuffer->get_end_iter(), true);
$textbuffer->insert_at_cursor("It�lico\n");
$fim_italico = $textbuffer->create_mark('fim_italico', $textbuffer->get_end_iter(), true);

$start = $textbuffer->get_iter_at_mark($inicio_italico);
$end   = $textbuffer->get_iter_at_mark($fim_italico);
$textbuffer->apply_tag($italic, $start, $end);

$inicio_sublinhado= $textbuffer->create_mark('inicio_sublinhado', $textbuffer->get_end_iter(), true);
$textbuffer->insert_at_cursor("Sublinhado\n\n");
$fim_sublinhado = $textbuffer->create_mark('fim_sublinhado', $textbuffer->get_end_iter(), true);

$start = $textbuffer->get_iter_at_mark($inicio_sublinhado);
$end   = $textbuffer->get_iter_at_mark($fim_sublinhado);
$textbuffer->apply_tag($underline, $start, $end);

$vermelho = new GtkTextTag;
$tagtable->add($vermelho);
$vermelho->set_property('foreground', '#FF0000');

$inicio_vermelho= $textbuffer->create_mark('inicio_vermelho', $textbuffer->get_end_iter(), true);
$textbuffer->insert_at_cursor("Vermelho Negrito\n\n");
$fim_vermelho = $textbuffer->create_mark('fim_vermelho', $textbuffer->get_end_iter(), true);

$start = $textbuffer->get_iter_at_mark($inicio_vermelho);
$end   = $textbuffer->get_iter_at_mark($fim_vermelho);
$textbuffer->apply_tag($vermelho, $start, $end);
$textbuffer->apply_tag($bold, $start, $end);

$times= new GtkTextTag;
$tagtable->add($times);
$times->set_property('font', 'Times Bold 20');

$inicio_times= $textbuffer->create_mark('inicio_times', $textbuffer->get_end_iter(), true);
$textbuffer->insert_at_cursor("Times 20 Bold\n");
$fim_times = $textbuffer->create_mark('fim_times', $textbuffer->get_end_iter(), true);

$start = $textbuffer->get_iter_at_mark($inicio_times);
$end   = $textbuffer->get_iter_at_mark($fim_times);
$textbuffer->apply_tag($times, $start, $end);

$pixbuf = GdkPixbuf::new_from_file('icons/gnome.png');

$textbuffer->insert_pixbuf($textbuffer->get_end_iter(), $pixbuf);

$scroll->add($textview);

$window->add($scroll);

$window->show_all();   
Gtk::main();
?>
