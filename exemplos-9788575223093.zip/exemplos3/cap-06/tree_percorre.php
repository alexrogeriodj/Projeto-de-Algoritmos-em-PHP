<?php
$model = new GtkTreeStore(GObject::TYPE_STRING, GObject::TYPE_LONG);

$root   = $model->append(NULL,    array('Planeta Terra', 6000));
$child  = $model->append($root,   array('Am�rica', 360));
$child2 = $model->append($root,   array('Europa', 702));
$child3 = $model->append($child,  array('Argentina', 38));
$child4 = $model->append($child,  array('Brasil', 190));
$child5 = $model->append($child,  array('Uruguai', 4));
$child6 = $model->append($child4, array('Rio Grande do Sul', 12));

imprime($model);

$row = $model['0:0:1'];

echo 'Local:     ' . $row[0] . "\n";
echo 'Popula��o: ' . $row[1] . "\n";

$model['0:0:2'] = array('Paraguai', 80);

unset($model['0:0:1:0']);

$row = $model['0:0:2'];

$row[1] += 100; // resultado = 180

list($local, $populacao) = $model['0:0:0']; // Argentina

echo "Local:     $local\n";
echo "Popula��o: $populacao\n";

echo 'Local:     ' . $model['0:0:2'][0] . "\n"; // Paraguai
echo 'Popula��o: ' . $model['0:0:2'][1] . "\n"; // 180

$model['0:0:2'][1] *= 3; // resultado = 540
echo 'Popula��o: ' . $model['0:0:2'][1] . "\n";

imprime($model);

$row    = $model['0:0:1'];  // obt�m linha do "Brasil"
$model  = $row->model;      // obt�m o modelo
$next   = $row->next;       // obt�m o pr�ximo nodo (Paraguai)
$parent = $row->parent;     // obt�m o pai (Am�rica)
$iter   = $row->iter;       // obt�m o iterador (GtkTreeIter) para a linha
$path   = $row->path;       // obt�m a localiza��o da linha (em forma de array)

echo 'Pr�ximo: ' . $next[0]   . "\n";
echo 'Pai:     ' . $parent[0] . "\n";
echo "Caminho: ";
print_r($path);

/*
 * fun��o imprime
 * Percorre um modelo de �rvore
 * e imprime suas linhas recursivamente
 */
function imprime($iter, $level = 0)
{
    if ($level==0) echo "==============\n";
    
    foreach ($iter as $row)
    {
        echo str_repeat("  ", $level);
        echo $row[0] . '-' . $row[1] . "\n";
        
        imprime($row->children(), $level+1);
    }
    if ($level==0) echo "==============\n";
}
?>