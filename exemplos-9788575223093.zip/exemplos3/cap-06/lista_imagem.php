<?php
class ExemploListaImagem
{
    private $window;
    private $list;
    private $model;

    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Lista com imagens');
        $this->window->connect_simple('destroy', array('gtk', 'main_quit'));
        $this->window->set_default_size(380,240);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $scroll = new GtkScrolledWindow;
        $scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
        
        $this->list = new GtkTreeView;
        $scroll->add($this->list);
        
        $this->list->connect('button-release-event', array($this, 'onClick'));
        
        $this->model = new GtkListStore(GObject::TYPE_OBJECT, GObject::TYPE_STRING,
                                        GObject::TYPE_STRING, GObject::TYPE_STRING);
        $this->list->set_model($this->model);
        
        $column1 = new GtkTreeViewColumn('Bandeira', new GtkCellRendererPixbuf, 'pixbuf', 0);
        $column2 = new GtkTreeViewColumn('Ano',      new GtkCellRendererText,   'text',   1);
        $column3 = new GtkTreeViewColumn('Local',    new GtkCellRendererText,   'text',   2);
        
        $this->list->append_column($column1);
        $this->list->append_column($column2);
        $this->list->append_column($column3);
        
        $dados[] = array('flags/uruguay.png',   1930,   'Uruguay',         'Uruguay' );
        $dados[] = array('flags/italy.png',     1934,   'Italia',          'Italia' );
        $dados[] = array('flags/france.png',    1938,   'France',          'Italia' );
        $dados[] = array('flags/brazil.png',    1950,   'Brasil',          'Uruguay' );
        $dados[] = array('flags/switzer.png',   1954,   'Su��a',           'Alemanha' );
        $dados[] = array('flags/sweden.png',    1958,   'Su�cia',          'Brasil' );
        $dados[] = array('flags/chile.png',     1962,   'Chile',           'Brasil' );
        $dados[] = array('flags/unitedk.png',   1966,   'Inglaterra',      'Inglaterra' );
        $dados[] = array('flags/mexico.png',    1970,   'Mexico',          'Brasil' );
        $dados[] = array('flags/germany.png',   1974,   'Alemanha',        'Alemanha' );
        $dados[] = array('flags/argentina.png', 1978,   'Argentina',       'Argentina' );
        $dados[] = array('flags/spain.png',     1982,   'Espanha',         'Italia' );
        $dados[] = array('flags/mexico.png',    1986,   'Mexico',          'Argentina' );
        $dados[] = array('flags/italy.png',     1990,   'Italia',          'Alemanha' );
        $dados[] = array('flags/uniteds.png',   1994,   'Estados Unidos',  'Brasil' );
        $dados[] = array('flags/france.png',    1998,   'Fran�a',          'Fran�a' );
        $dados[] = array('flags/korea.png',     2002,   'Cor�ia e Jap�o',  'Brasil' );
        $dados[] = array('flags/germany.png',   2006,   'Alemanha',        'It�lia' );
        
        foreach ($dados as $linha)
        {
            $flag   = $linha[0];
            $ano    = $linha[1];
            $local  = $linha[2];
            $campeao= $linha[3];
            
            $pixbuf = GdkPixbuf::new_from_file($flag);
            
            $iter = $this->model->append(array($pixbuf, $ano, $local, $campeao));
        }
        
        $this->window->add($scroll);
        $this->window->show_all();
    }

    public function onClick($widget, $event)
    {
        if ($event->button == 3)
        {
            $this->Menu = new GtkMenu;
            
            $item1= new GtkImageMenuItem('gtk-dialog-info');
            $item2= new GtkImageMenuItem('gtk-delete');
            
            $item1->connect('activate', array($this, 'onShowInfo'));
            $item2->connect('activate', array($this, 'onDeleteIter'));
            
            $this->Menu->append($item1);
            $this->Menu->append($item2);
            
            $this->Menu->show_all();
            $this->Menu->popup();
        }
    }

    public function onShowInfo()
    {
        $selection = $this->list->get_selection();
        
        list($model, $iter) = $selection->get_selected();
        
        if ($iter)
        {
            $campeao = $this->model->get_value($iter, 3);
            
            $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                                 Gtk::BUTTONS_OK, "Campe�o: $campeao");
            $dialog->run();
            $dialog->destroy();
        }
    }
    
    public function onDeleteIter()
    {
        $selection = $this->list->get_selection();
        
        list($model, $iter) = $selection->get_selected();
        
        $this->model->remove($iter);
    }
}

new ExemploListaImagem;
Gtk::Main();
?>