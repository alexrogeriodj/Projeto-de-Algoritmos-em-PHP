<?php
class ExemploListaSimples
{
    private $window;
    private $list;
    private $model;

    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Listas');
        $this->window->connect_simple('destroy', array('gtk', 'main_quit'));
        $this->window->set_default_size(400,200);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $scroll = new GtkScrolledWindow;
        $scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
        
        $this->list = new GtkTreeView;
        $scroll->add($this->list);
        
        $this->list->connect('row-activated', array($this, 'onDoubleClick'));
        
        $this->model = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING);
        $this->list->set_model($this->model);
        
        $this->model->set_sort_column_id(1, Gtk::SORT_DESCENDING);
        
        $column1 = new GtkTreeViewColumn();
        $column2 = new GtkTreeViewColumn();
        
        $column1->set_sort_column_id(0);
        $column2->set_sort_column_id(1);
        
        $column1->set_title('Nome');
        $column2->set_title('Pontua��o');
        
        $cell_renderer1 = new GtkCellRendererText();
        $cell_renderer2 = new GtkCellRendererText();
        
        $cell_renderer1->set_property('cell-background', '#d0d0d0');
        
        $column1->pack_start($cell_renderer1, true);
        $column2->pack_start($cell_renderer2, true);
        
        $cell_renderer1->set_property('width', 200);
        $cell_renderer2->set_property('width', -1);
        
        $column1->set_attributes($cell_renderer1, 'text', 0);
        $column2->set_attributes($cell_renderer2, 'text', 1);
        
        $this->list->append_column($column1);
        $this->list->append_column($column2);
        
        $dados[] = array('Gustavo Kuerten', '3258 pontos');
        $dados[] = array('Andre Agassi',    '2986 pontos');
        $dados[] = array('Pete Sampras',    '2448 pontos');
        $dados[] = array('Carlos Moya',     '2136 pontos');
        $dados[] = array('Marat Safin',     '2098 pontos');
        $dados[] = array('Hewitt, Lleyton', '2011 pontos');
        
        foreach ($dados as $jogador)
        {
            $iter = $this->model->append();
            
            $this->model->set($iter, 0, $jogador[0]);
            $this->model->set($iter, 1, $jogador[1]);
        }
        
        $this->window->add($scroll);
        $this->window->show_all();
    }
    
    public function onDoubleClick()
    {
        $selection = $this->list->get_selection();
        
        list($model, $iter) = $selection->get_selected();
        
        if ($iter)
        {
            $jogador   = $this->model->get_value($iter, 0);
            $pontuacao = $this->model->get_value($iter, 1);
            
            $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                                 Gtk::BUTTONS_OK,
                                                 "Jogador: $jogador\nPontos: $pontuacao");
            $dialog->run();
            $dialog->destroy();
        }
    }
}

new ExemploListaSimples;
Gtk::Main();
?>