<?php
$model = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_DOUBLE);

$model->append(array('Chocolate', 2.4));
$model->append(array('Leite', 	    1.2));
$model->append(array('Queijo', 	 8.9));
$model->append(array('Salame', 	  16));
$model->append(array('Iogurge',    2.5));

imprime($model);

$row = $model[0];

echo '1a Lin, 1a Col: ' . $row[0] . "\n";

echo 'Linhas: ' . count($model) . "\n";

echo 'Colunas: ' . count($model[0]) . "\n";

$model[0] = array('Chocolate Branco', 2.6);

unset($model[1]);

$row = $model[1];

$row[1] += 100;

$model[3][1] *= 4;

imprime($model);

list($produto, $valor) = $model[0];

echo "Produto: $produto\n";
echo "Valor:   $valor\n";

echo 'Produto: ' . $model[1][0] . "\n";


/*
 * fun��o imprime
 * Percorre um modelo de listas
 * e imprime suas linhas
 */
function imprime($model)
{
    echo "===================\n";
    foreach ($model as $row)
    {
        echo $row[0] . ' - ' . $row[1] . "\n";
    }
    echo "===================\n";
}
?>