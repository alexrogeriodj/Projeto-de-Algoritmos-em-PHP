<?php
class ExemploTreeSimples
{
    private $window;
    private $tree;
    private $model;

    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('�rvores');
        $this->window->connect_simple('destroy', array('gtk', 'main_quit'));
        $this->window->set_default_size(320,280);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $scroll = new GtkScrolledWindow;
        $scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
        
        $this->tree = new GtkTreeView;
        $scroll->add($this->tree);
        
        $this->tree->connect('row-activated', array($this, 'onDoubleClick'));
        
        $this->model = new GtkTreeStore(GObject::TYPE_OBJECT, GObject::TYPE_STRING, GObject::TYPE_STRING);
        $this->tree->set_model($this->model);
        
        $column1 = new GtkTreeViewColumn();
        $column1->set_title('Pasta');
        
        $cell_renderer1 = new GtkCellRendererPixbuf();
        $cell_renderer2 = new GtkCellRendererText();
        
        $column1->pack_start($cell_renderer1, false);
        $column1->pack_start($cell_renderer2, false);
        
        $column1->set_attributes($cell_renderer1, 'pixbuf', 0);
        $column1->set_attributes($cell_renderer2, 'text',   1);
        
        $this->tree->append_column($column1);
        
        $folder  = GdkPixbuf::new_from_file('icons/folder.png');
        $ico_mp3 = GdkPixbuf::new_from_file('icons/ico_mp3.png');
        $ico_doc = GdkPixbuf::new_from_file('icons/ico_doc.png');
        $ico_png = GdkPixbuf::new_from_file('icons/ico_png.png');
        $ico_zip = GdkPixbuf::new_from_file('icons/ico_zip.png');
        
        $iter1 = $this->model->append();
        $this->model->set($iter1, 0, $folder);
        $this->model->set($iter1, 1, 'Home');
        
        $iter1a = $this->model->append($iter1);
        $this->model->set($iter1a, 0, $ico_mp3);
        $this->model->set($iter1a, 1, 'M�sicas');
        $this->model->set($iter1a, 2, '/home/songs');
        
        $iter1b = $this->model->append($iter1);
        $this->model->set($iter1b, 0, $ico_png);
        $this->model->set($iter1b, 1, 'Imagens');
        $this->model->set($iter1b, 2, '/home/images');
        
        $iter2 = $this->model->append();
        $this->model->set($iter2, 0, $folder);
        $this->model->set($iter2, 1, 'Trabalho');
        
        $iter2a = $this->model->append($iter2);
        $this->model->set($iter2a, 0, $ico_doc);
        $this->model->set($iter2a, 1, 'Documentos');
        $this->model->set($iter2a, 2, '/work/docs');
        
        $iter2b = $this->model->append($iter2);
        $this->model->set($iter2b, 0, $ico_zip);
        $this->model->set($iter2b, 1, 'Backups');
        $this->model->set($iter2b, 2, '/work/backups');
        
        $this->tree->expand_all();
        $this->window->add($scroll);
        $this->window->show_all();
    }
    
    function onDoubleClick()
    {
        $selection = $this->tree->get_selection();
        
        list($model, $iter) = $selection->get_selected();
        
        if ($iter)
        {
            $caminho = $this->model->get_value($iter, 2);
            
            $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                           Gtk::BUTTONS_OK, $caminho);
            
            $dialog->run();
            $dialog->destroy();
        }
    }
}

new ExemploTreeSimples;
Gtk::Main();
?>