<?php
class ExemploListaEdita
{
    private $window;
    private $list;
    private $model;

    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Listas');
        $this->window->connect_simple('destroy', array('gtk', 'main_quit'));
        $this->window->set_default_size(520,240);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $scroll = new GtkScrolledWindow;
        $scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
        
        $this->list = new GtkTreeView;
        $scroll->add($this->list);
        
        $this->model = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING, GObject::TYPE_STRING);
        $this->list->set_model($this->model);
        
        $column1 = new GtkTreeViewColumn('Artista');
        $column2 = new GtkTreeViewColumn('Site');
        $column3 = new GtkTreeViewColumn('G�nero');
        
        $cell_renderer1 = new GtkCellRendererText();
        $cell_renderer2 = new GtkCellRendererText();
        $cell_renderer3 = new GtkCellRendererCombo();
        
        $combo_model = new GtkListStore(GObject::TYPE_STRING);
        $combo_model->append(array('Rock'));
        $combo_model->append(array('Soul'));
        $combo_model->append(array('Pop'));
        $combo_model->append(array('Pop Rock'));
        $combo_model->append(array('Punk Rock'));
        $combo_model->append(array('Hard Rock'));
        $combo_model->append(array('Heartland Rock'));
        $combo_model->append(array('Progressive Rock'));
        
        $cell_renderer1->set_property('editable', True);
        $cell_renderer2->set_property('editable', True);
        $cell_renderer3->set_property('editable', True);

        $cell_renderer1->set_property('font',  'Times Bold 10');
        $cell_renderer1->set_property('foreground',  'red');
        
        $cell_renderer3->set_property('model', $combo_model);
        $cell_renderer3->set_property('text-column', 0);
        
        $cell_renderer1->connect("edited", array($this, 'onEdit'), 0);
        $cell_renderer2->connect("edited", array($this, 'onEdit'), 1);
        $cell_renderer3->connect("edited", array($this, 'onEdit'), 2);
        
        $column1->pack_start($cell_renderer1, true);
        $column2->pack_start($cell_renderer2, true);
        $column3->pack_start($cell_renderer3, true);
        
        $cell_renderer1->set_property('width', 100);
        
        $column1->set_attributes($cell_renderer1, 'text', 0);
        $column2->set_attributes($cell_renderer2, 'text', 1);
        $column3->set_attributes($cell_renderer3, 'text', 2);
        
        $this->list->append_column($column1);
        $this->list->append_column($column2);
        $this->list->append_column($column3);
        
        $dados[] = array('The Eagles',  'http://www.eaglesband.com',        'Rock');
        $dados[] = array('Bee Gees',    'http://www.beegeesonline.com',     'Pop Rock');
        $dados[] = array('Bonnie Tyler','http://www.bonnietyler.com',       'Pop');
        $dados[] = array('Creedence',   'http://www.creedence-online.net',  'Heartland Rock');
        $dados[] = array('Cranberries', 'http://www.cranberries.ie',        'Rock');
        $dados[] = array('Nazareth',    'http://www.nazarethdirect.co.uk',  'Hard Rock');
        $dados[] = array('Pink Floyd',  'http://www.pinkfloyd.com',         'Progressive Rock');
        $dados[] = array('Queen',       'http://www.queenonline.com',       'Hard Rock');
        $dados[] = array('Ramones',     'http://www.ramones.com',           'Punk Rock');
        $dados[] = array('Roxette',     'http://www.roxette.se',            'Pop Rock');
        $dados[] = array('Beatles',     'http://www.beatles.com',           'Rock');
        $dados[] = array('Commitments', 'http://www.thecommitments.net',    'Soul');
        
        foreach ($dados as $artista)
        {
            $iter = $this->model->append($artista);
        }
        
        $adiciona = GtkButton::new_from_stock(Gtk::STOCK_ADD);
        
        $adiciona->connect_simple('clicked', array($this, 'onAdd'));
        
        $vbox = new GtkVBox;
        $vbox->pack_start($scroll);
        $vbox->pack_start($adiciona, false, false);
        $this->window->add($vbox);
        
        $this->window->show_all();
    }
    
    function onAdd()
    {
        $iter = $this->model->append();
        
        $path = $this->model->get_path($iter);
        
        $this->list->scroll_to_cell($path);
    }
    
    function onEdit($cell_renderer, $linha, $conteudo, $coluna)
    {
        $treeselection = $this->list->get_selection();
        list($model, $iter) = $treeselection->get_selected();
        
        $model->set($iter, $coluna, $conteudo);
    }
}

new ExemploListaEdita;
Gtk::Main();
?>