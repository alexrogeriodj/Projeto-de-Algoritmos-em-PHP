<?php
// Criando a janela
$janela = new GtkWindow();
$janela->show();
// Criando o rótulo de texto
$texto = new GtkLabel('Minha primeira Janela');
$texto->show();
// Colocando o label dentro da janela
$janela->add($texto);
// Exibe a janela
$janela->show();
// Inicialização da aplicação
Gtk::main();
?>

