<?php
class OlaMundo
{
	 private $window;
	 private $button;
	 /*
	    * Método construtor
	   * Cria a interface e exibe a janela
	   */
	 function __construct()
	 {
		 // cria uma janela
		 $this->window = new GtkWindow();
		     // cria um botão
		     $this->button = new GtkButton('Hello World!');
		     // conecta o sinal clicked à função olamundo
		     $this->button->connect('clicked', array($this, 'olamundo'));
		     // adiciona o botão à janela
		     $this->window->add($this->button);
		 // exibe janela e todo seu conteúdo
		 $this->window->show_all();
	 }
	 function olamundo()
	 {
		 print "Olá Mundo\n";
		 Gtk::main_quit();
	 }
}
$app = new OlaMundo;
Gtk::main();
?>

