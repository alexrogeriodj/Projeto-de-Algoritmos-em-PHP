<?php
/*
 * função olamundo()
 * imprime no console "Olá Mundo" e
 * interrompe a execução do programa.
 */
function olamundo()
{
	 print "Olá Mundo\n";
	 Gtk::main_quit();
}

// cria uma janela
$window = new GtkWindow();
// cria um botão
$button = new GtkButton('Hello World!');
// conecta o sinal clicked à função olamundo
$button->connect('clicked', 'olamundo');
// adiciona o botão à janela
$window->add($button);
// exibe janela e todo seu conteúdo
$window->show_all();
Gtk::main();
?>

