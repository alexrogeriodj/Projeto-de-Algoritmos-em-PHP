<?
class Publica extends GladeXML
{
    function __construct($arquivo_glade)
    {
        parent::__construct($arquivo_glade);
        parent::signal_autoconnect_instance($this);
        
        $this->titulo = parent::get_widget('titulo');
        $this->autor  = parent::get_widget('autor');
        $this->email  = parent::get_widget('e-mail');
        $this->data   = parent::get_widget('data');
        $this->fonte  = parent::get_widget('fonte');
        $this->url    = parent::get_widget('url');
        $this->noticia= parent::get_widget('noticia');
    }

    function onPublica()
    {
        $titulo = $this->titulo->get_text();
        $autor  = $this->autor->get_text();
        $email  = $this->email->get_text();
        $data   = $this->data->get_text();
        $fonte  = $this->fonte->get_text();
        $url    = $this->url->get_text();
        
        $buffer = $this->noticia->get_buffer();
        $start  = $buffer->get_start_iter();
        $end    = $buffer->get_end_iter();
        $noticia = $buffer->get_text($start, $end);
        
        $handler = fopen('noticias.html', 'a+'); 
        fwrite($handler,"<br>");
        fwrite($handler,"<table width=500 bgcolor=#fcffa7 bordercolor=#f9ffb8 border=1>\n");
        
        fwrite($handler,"<tr>\n");
        fwrite($handler,"<td> <b>T�tulo:</b> $titulo </td>\n");
        fwrite($handler,"<td> <b>Autor:</b>  <a href=mailto:$email>$autor</a></td>\n");
        fwrite($handler,"</tr>\n");
        
        fwrite($handler,"<tr>\n");
        fwrite($handler,"<td> <b>Fonte:</b> <a href='$url'>$fonte</a></td>\n");
        fwrite($handler,"<td> <b>Data:</b>  $data  </td>\n");
        fwrite($handler,"</tr>\n");
        
        fwrite($handler,"<tr>\n");
        fwrite($handler,"<td colspan=2> <i>$noticia</i> </td>\n");
        fwrite($handler,"</tr>\n");
        
        fwrite($handler,"</table>\n");
        
        fclose($handler);
        
        $OS = strtoupper(substr(PHP_OS, 0,3));
        if ($OS == 'WIN')
            exec('explorer noticias.html');
        else
            exec('firefox noticias.html');
    }
}

new Publica('publica.glade');
gtk::main();
?>