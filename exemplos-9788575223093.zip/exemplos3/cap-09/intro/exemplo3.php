<?php
$glade = new GladeXML('exemplo3.glade');

$glade->signal_autoconnect();

$codigo = $glade->get_widget('codigo');

$nome = $glade->get_widget('nome');

function onAdd()
{
	global $codigo, $nome;

	$texto = $codigo->get_text() . ' - ' . $nome->get_text() . "\ninserido com sucesso";
    
    $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                         Gtk::BUTTONS_OK, $texto);

    $dialog->run();
    $dialog->destroy();
}

Gtk::Main();
?>