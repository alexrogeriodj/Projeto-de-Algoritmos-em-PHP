<?
$glade = new GladeXml('exemplo3.glade');

$glade->signal_autoconnect_instance(new ObjetoGlade($glade));

class ObjetoGlade
{
    private $glade;
    private $codigo;
    private $nome;
    
    function __construct($glade)
    {
        $this->glade  = $glade;
        $this->codigo = $glade->get_widget('codigo');
        $this->nome   = $glade->get_widget('nome');
    }
    
    function onAdd($button)
    {
        $texto = $this->codigo->get_text() . ' - ' .
                 $this->nome->get_text() . "\ninserido com sucesso";
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, $texto);
        $dialog->run();
        $dialog->destroy();
    }
}

Gtk::Main();
?>