<?php
class ObjetoGlade extends GladeXML
{
    function __construct($file)
    {
        parent::__construct($file);
        parent::signal_autoconnect_instance($this);
    }

    function __get($propriedade)
    {
        return parent::get_widget($propriedade);
    }

    function onAdd()
    {
        $texto = $this->codigo->get_text() . ' - ' .
                 $this->nome->get_text() . "\ninserido com sucesso";
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK, $texto);
        $dialog->run();
        $dialog->destroy();
    }
}

$glade = new ObjetoGlade('exemplo3.glade');
Gtk::Main();
?>