<?php
$glade = new GladeXML('exemplo2.glade');

$nome = $glade->get_widget('nome');

$imprimir = $glade->get_widget('imprimir');

$resultado = $glade->get_widget('resultado');

$imprimir->connect_simple('clicked', 'onImprimir');

function onImprimir()
{
	global $nome, $resultado;

	$texto = $nome->get_text();

	$resultado->set_text("Ol� {$texto}");
}

Gtk::Main();
?> 