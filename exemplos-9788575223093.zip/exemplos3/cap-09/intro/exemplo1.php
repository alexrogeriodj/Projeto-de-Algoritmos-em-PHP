<?php
function onClicked()
{
    $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                         Gtk::BUTTONS_OK,  'Voc� Clicou !!');

    $dialog->run();
    $dialog->destroy();
}

$glade = new GladeXML('exemplo1.glade');

$window = $glade->get_widget("window1");
$botao  = $glade->get_widget("button1");

$botao->connect_simple('clicked', 'onClicked');

$window->show_all();
Gtk::main();
?>