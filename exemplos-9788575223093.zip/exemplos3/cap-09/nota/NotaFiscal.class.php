<?
/**
 * Classe NotaFiscal
 * Encapsula toda a gera��o
 * do arquivo da Nota Fiscal
 */
class NotaFiscal
{
    private $pdf;       // objeto PDF
    private $numero;    // N�mero da Nota
    private $cliente;   // Objeto Cliente
    private $items;     // Vetor de Produtos
    private $data;      // Data da Nota
    private $subTotal;  // Sub-Total
    private $Imposto;   // Valor do Imposto
    private $Frete;     // Total do Frete
    private $Total;     // Total da Nota

    /*
     * M�todo construtor
     * Instancia o objeto FPDF
     */
    public function __construct()
    {
        // Define o diret�rio das fontes
        define('FPDF_FONTPATH', getcwd() . '/fpdf/font/');
        
        // Carrega a biblioteca FPDF
        include_once 'fpdf/fpdf.php';
        
        // Cria um novo documento PDF
        $this->pdf = new FPDF('P', 'pt', array(596,540));
        $this->pdf->SetMargins(2,2,2); // define margins
    }

    /*
     * M�todo setNumero
     * Define o n�mero da Nota Fiscal
     */
    public function setNumero($numero)
    {
        $this->numero = $numero;
    }

    /*
     * M�todo setData
     * Define a Data da Nota Fiscal
     */
    public function setData($data)
    {
        $this->data = $data;
    }

    /*
     * M�todo setCliente
     * Armazena um objeto com os dados do cliente
     */
    public function setCliente($object)
    {
        $this->cliente->nome     = $object->nome;
        $this->cliente->endereco = $object->endereco;
        $this->cliente->fone     = $object->fone;
    }

    /* M�todo setRodape
     * Recebe sub-total, imposto, frete e total
     */
    public function setRodape($subTotal, $Imposto, $Frete, $Total)
    {
        $this->subTotal = $subTotal;
        $this->Imposto  = $Imposto;
        $this->Frete    = $Frete;
        $this->Total    = $Total;
    }

    /* M�todo addItem
     * Adiciona um item (produto) ao vetor de itens da nota
     */
    public function addItem($codigo, $descricao, $quantidade, $preco)
    {
        $this->items[] = array($codigo, $descricao, $quantidade, $preco);
    }

    /* M�todo geraNota
     * Gera o documento PDF e salva em disco
     * com o nome de arquivo passado como par�metro
     */
    public function geraNota($arquivo)
    {
        // Adiciona uma p�gina
        $this->pdf->AddPage();
        $this->pdf->Ln();

        $image  = 'adianti.jpg';
        $size   = getimagesize($image);
        $width  = $size[0];
        $height = $size[1];
        
        // acrescenta a imagem de logo nestas coordenadas
        $this->pdf->Image($image, 14, 20, $width, $height);
        
        // desenha um ret�ngulo para o n�mero da nota
        $this->pdf->SetLineWidth(2);
        $this->pdf->SetFillColor(247,247,247);
        $this->pdf->Rect(434,34,147,67, 'DF');
        
        // exibe o n�mero e data da nota
        $this->pdf->SetTextColor(0,0,0);
        $this->pdf->SetFont('Arial','B',14);
        $this->pdf->Text(490,58, $this->numero);
        $this->pdf->Text(490,78, $this->data);
        
        // exibe o nome da empresa
        $this->pdf->SetFont('Arial','B',28);
        $this->pdf->Text(190,58, 'Adianti Solutions');
        
        // exibe o texto abaixo
        $this->pdf->SetFont('Arial','B',12);
        $this->pdf->Text(440,57, 'N�mero');
        $this->pdf->Text(440,77, 'Data');
        
        // exibe o site e frase.
        $this->pdf->SetTextColor(0, 0, 0);
        $this->pdf->SetFont('Arial','BI',12);
        $this->pdf->Text(190, 70, 'Solu��es Flex�veis');
        $this->pdf->Text(190, 84, 'Qualidade e Conhecimento');
        $this->pdf->Text(190, 98, 'www.adianti.com.br');
        
        // desenha ret�ngulo para os dados do cliente
        $this->pdf->SetFillColor(247,247,247);
        $this->pdf->Rect(7,146,580,47, 'DF');
        $this->pdf->SetFont('Arial','B',12);
        $this->pdf->SetTextColor(0,0,0);
        
        // exibe os dados do cliente
        $this->pdf->Text(10,164, "Cliente:  {$this->cliente->nome}");
        $this->pdf->Text(10,180, "Endere�o:   {$this->cliente->endereco}, Fone: {$this->cliente->fone}");
        
        // desenha ret�ngulo para os itens da nota
        $this->pdf->SetFillColor(255,255,255);
        $this->pdf->Rect(7,204,580,200, 'DF');
        $this->pdf->SetFillColor(222,222,222);
        $this->pdf->Rect(7,204,580,20, 'DF');
        
        // exibe o cabe�alho dos produtos
        $this->pdf->Text(14,  218, 'C�digo');
        $this->pdf->Text(100, 218, 'Descri��o');
        $this->pdf->Text(400, 218, 'Qtde');
        $this->pdf->Text(500, 218, 'Valor');
        
        $this->pdf->SetFont('Courier','B',12);
        $row=244;
        if ($this->items)
        {
            // exibe cada um dos produtos
            foreach ($this->items as $item)
            {
                $this->pdf->Text(14, $row, $item[0]);
                $this->pdf->Text(100,$row, $item[1]);
                $this->pdf->Text(400,$row, $item[2]);
                $this->pdf->Text(500,$row, 'R$ ' . number_format($item[3], 2));
                $row += 16;
            }
        }
        
        // desenha um ret�ngulo para o rodap�
        $this->pdf->SetFillColor(247,247,247);
        $this->pdf->Rect(7,416,580,80, 'DF');
        $this->pdf->SetFont('Courier','B',14);
        
        // exibe os sub-totais, impostos, frete e total
        $this->pdf->Text(440, 434, 'SubTotal: ' . $this->subTotal);
        $this->pdf->SetTextColor(222, 0, 0);
        $this->pdf->Text(440, 448, 'Imposto:  ' . $this->Imposto);
        $this->pdf->SetTextColor(0, 128, 0);
        $this->pdf->Text(440, 462, 'Frete:    ' . $this->Frete);
        $this->pdf->SetTextColor(0, 0, 0);
        $this->pdf->Text(440, 476, 'Total:    ' . $this->Total);
        
        // salva o PDF com o nome especificado
        $this->pdf->Output($arquivo);
        
        // abre o PDF de acordo com o sistema operacional
        $OS = strtoupper(substr(PHP_OS, 0,3));
        if ($OS == 'WIN')
            exec("$arquivo >NULL &");
        else
            exec("evince $arquivo >/dev/null &");
    }
}
?>