<?
final class JanelaNotaFiscal extends GladeXML
{
    private $notafiscal;            // objeto NotaFiscal
    private $taxa_imposto   = 0.05; // Imposto (5%) sobre o total
    private $taxa_frete     = 0.4;  // Taxa de Frete (R$ 0.4) por unidade
    private $quantidade     = 0;    // quantidade de itens
    
    public function __construct()
    {
        parent::__construct('interface.glade');
        
        // Define o padr�o para c�lculos
        setlocale(LC_ALL, 'POSIX');
        
        $this->saveButton->connect_simple('clicked', array($this, 'onSave'));
        $this->clearButton->connect_simple('clicked', array($this, 'onClear'));
        $this->addButton->connect_simple('clicked', array($this, 'onAdd'));
        
        $this->DatadaNota->set_text(date("d/m/Y"));
        
        $this->model = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING,
                                        GObject::TYPE_STRING, GObject::TYPE_STRING);
                                  
        $this->itemsList->set_model($this->model);
        
        $column1 = new GtkTreeViewColumn('C�digo',     new GtkCellRendererText,   'text',   0);
        $column2 = new GtkTreeViewColumn('Descri��o',  new GtkCellRendererText,   'text',   1);
        $column3 = new GtkTreeViewColumn('Quantidade', new GtkCellRendererText,   'text',   2);
        $column4 = new GtkTreeViewColumn('Pre�o',      new GtkCellRendererText,   'text',   3);
        
        $this->itemsList->append_column($column1);
        $this->itemsList->append_column($column2);
        $this->itemsList->append_column($column3);
        $this->itemsList->append_column($column4);
    }
    
    public function __get($propriedade)
    {
        return parent::get_widget($propriedade);
    }

    public function onAdd()
    {
        $produto   = array(); // inicia o vetor de produtos
        
        $produto[] = $this->produtoCodigo->get_text();
        $produto[] = $this->produtoDescricao->get_text();
        $produto[] = $this->produtoQuantidade->get_text();
        $produto[] = $this->produtoValor->get_text();
        
        $this->model->append($produto);
        
        $this->quantidade += $this->produtoQuantidade->get_text();
        
        $valor_item = $this->produtoValor->get_text() * $this->produtoQuantidade->get_text();
        
        $this->subTotal->set_text($this->subTotal->get_text() + $valor_item);
                                  
        $this->Frete->set_text($this->quantidade * $this->taxa_frete);
        
        $this->Imposto->set_text($this->subTotal->get_text() * $this->taxa_imposto);
        
        $this->Total->set_text($this->subTotal->get_text() +
                               $this->Frete->get_text() + 
                               $this->Imposto->get_text());
        
        $this->produtoCodigo->set_text('');
        $this->produtoDescricao->set_text('');
        $this->produtoQuantidade->set_text('');
        $this->produtoValor->set_text('');
        
        $this->window->set_focus($this->produtoCodigo);
    }
    
    public function onClear()
    {
        $this->model->clear();
        $this->quantidade = 0;
        
        $this->subTotal->set_text(0);
        $this->Frete->set_text(0);
        $this->Imposto->set_text(0);
        $this->Total->set_text(0);
    }

    public function onSave()
    {
        include_once('NotaFiscal.class.php');
        
        $this->notafiscal = new NotaFiscal;
        
        $this->notafiscal->setNumero($this->NumerodaNota->get_text());
        $this->notafiscal->setData($this->DatadaNota->get_text());
        
        $cliente->nome    = $this->clienteNome->get_text();
        $cliente->endereco= $this->clienteEndereco->get_text();
        $cliente->fone    = $this->clienteFone->get_text();
        
        $this->notafiscal->setCliente($cliente);
        
        $iter = $this->model->get_iter_first();
        while ($iter)
        {
            $codigo     = $this->model->get_value($iter, 0);
            $descricao  = $this->model->get_value($iter, 1);
            $quantidade = $this->model->get_value($iter, 2);
            $preco      = $this->model->get_value($iter, 3);
            
            $this->notafiscal->addItem($codigo, $descricao, $quantidade, $preco);
            $iter = $this->model->iter_next($iter);
        }
        
        $this->notafiscal->setRodape($this->subTotal->get_text(),
                                     $this->Imposto->get_text(),
                                     $this->Frete->get_text(),
                                     $this->Total->get_text());
        
        $dialogo = new GtkFileChooserDialog('Salvar...', NULL,
                          Gtk::FILE_CHOOSER_ACTION_SAVE,
                          array(Gtk::STOCK_OK,     Gtk::RESPONSE_OK,
                                Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));
        $resposta = $dialogo->run();
        
        if ($resposta == Gtk::RESPONSE_OK)
        {
            $this->notafiscal->geraNota($dialogo->get_filename());
            
            $this->onClear();
            
            $this->NumerodaNota->set_text($this->NumerodaNota->get_text() + 1);
        }
        $dialogo->destroy();
    }
}

$application = new JanelaNotaFiscal;
Gtk::Main();
?>