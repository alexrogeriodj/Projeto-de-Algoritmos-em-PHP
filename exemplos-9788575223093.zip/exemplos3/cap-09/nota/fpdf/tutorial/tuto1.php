<?php
define('FPDF_FONTPATH','../font/');
require('../fpdf.php');

$pdf=new FPDF('P', 'pt', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->SetFillColor(255,255,255);
$x0 = $pdf->GetX();
$y = $pdf->GetY();
$pdf->MultiCell(100,20,'11Hello World alkdsjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188), 1,'C', 1);
$pdf->SetX($x0 + 140);
$pdf->SetLeftMargin($x0 + 140);
$pdf->SetY($y);
$pdf->MultiCell(100,20,'22Hello World alkdsjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188));

$x = $pdf->GetX();
$pdf->SetY($y);
$pdf->SetLeftMargin($x + 140);
$pdf->MultiCell(100,20,'33Hello World alkdsjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188));


$y = $pdf->GetY();
$pdf->SetX($x0);
$x = $pdf->GetX();
$pdf->MultiCell(100,20,'44Hello World alkdsjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188));
$pdf->SetLeftMargin($x + 140);
$pdf->SetY($y);
$pdf->MultiCell(100,20,'55Hello World alkdsjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188));
$pdf->Output('teste.pdf');
?>
