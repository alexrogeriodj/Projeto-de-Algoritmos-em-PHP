<?php
define('FPDF_FONTPATH','../font/');
require('../fpdf.php');

$pdf=new FPDF('P', 'pt', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(100,20,'sjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188), 1, 2, 'L', 0);
$pdf->Cell(100,20,'sjf;skldjflsajkdhf alskjdfh alskjdfhsdlf!' . chr(174) . chr(188), 1, 2, 'L', 0);
$pdf->Output();
?>
