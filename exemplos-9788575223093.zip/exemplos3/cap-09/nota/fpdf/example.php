<?php
require_once('pdfbarcode128.inc');
$pdf = new fpdf();
$code = new pdfbarcode128('FR5975', 6 );
$pdf->Open();
$pdf->AddPage();
$code->set_pdf_document($pdf);
$width = $code->get_width();
$code->draw_barcode(20, 40, 45, true );
$pdf->Output('teste.pdf');
unset($code);
unset($pdf);
?>
