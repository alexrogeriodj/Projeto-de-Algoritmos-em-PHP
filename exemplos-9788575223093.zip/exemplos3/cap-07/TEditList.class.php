<?php
/**
 * Classe TEditList
 * Uma lista edit�vel com bot�es
 * de inser��o, edi��o, exclus�o...
 */
class TEditList extends GtkWindow
{
    protected $list;        // objeto TDataList
    private   $buttons;     // bot�es da janela
    private   $buttonBox;   // caixa de bot�es
    protected $callback;    // a��o do bot�o salvar

    /*
     * M�todo construtor
     * Cria a janela, a lista
     * e define a a��o dos bot�es
     */
    function __construct()
    {
        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkWindow"
        parent::__construct();
        
        // inclui a classe TDataList
        include_once 'TDataList.class.php';
        
        // instancia objeto para lista
        $this->list = new TDataList;
        // adiciona uma coluna
        $this->list->addColumn('item', 'text');
        // cria modelo de dados
        $this->list->createModel();
        
        // cria janela de rolagem para a lista
        $scroll = new GtkScrolledWindow;
        $scroll->add($this->list);
        
        // cria uma caixa horizontal
        $hbox = new GtkHBox;
        // adiciona a janela de rolagem na caixa horizontal
        $hbox->pack_start($scroll, true, true);
        
        // cria a caixa de bot�es (vertical)
        $this->buttonBox = new GtkVButtonBox;
        // define o posicionamento do conte�do da caixa
        $this->buttonBox->set_layout(Gtk::BUTTONBOX_START);
        
        $this->buttons = array();
        // cria os bot�es de edi��o da lista
        $this->buttons['add']    = GtkButton::new_from_stock(Gtk::STOCK_ADD);
        $this->buttons['edit']   = GtkButton::new_from_stock(Gtk::STOCK_EDIT);
        $this->buttons['delete'] = GtkButton::new_from_stock(Gtk::STOCK_DELETE);
        $this->buttons['clear']  = GtkButton::new_from_stock(Gtk::STOCK_CLEAR);
        $this->buttons['save']   = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
        
        // adiciona os bot�es na caixa
        foreach ($this->buttons as $button)
        {
            $this->buttonBox->add($button);
        }
        // define a a��o dos bot�es
        $this->buttons['add']->connect_simple('clicked',    array($this, 'onAddItem'));
        $this->buttons['edit']->connect_simple('clicked',   array($this, 'onEditItem'));
        $this->buttons['delete']->connect_simple('clicked', array($this, 'onDeleteItem'));
        $this->buttons['clear']->connect_simple('clicked',  array($this, 'onClearItems'));
        $this->buttons['save']->connect_simple('clicked',   array($this, 'onSaveItems'));
        
        // adiciona a caixa de bot�es na caixa horizontal
        $hbox->pack_start($this->buttonBox, false, false);
        
        // adiciona a caixa horizontal na janela
        parent::add($hbox);
        parent::show_all();
    }

    /*
     * M�todo onAddItem
     * Adiciona um novo item na lista
     * para tal, usa a classe TInputBox, para perguntar ao usu�rio
     */
    function onAddItem()
    {
        // inclui a classe TInputBox
        include_once 'TInputBox.class.php';
        
        // abre uma caixa de di�logo pedindo o item
        $dialog = new TInputBox('Preencha os dados', 'Novo Item');
        $resposta = $dialog->run();
        
        // verifica a resposta da a��o
        if ($resposta == Gtk::RESPONSE_OK)
        {
            // adiciona o novo item digitado no di�logo
            $this->list->addItem(array($dialog->get_text()));
        }
        // fecha di�logo
        $dialog->destroy();
    }

    /*
     * M�todo onEditItem
     * 
     */
    function onEditItem()
    {
        // inclui a classe TInputBox
        include_once 'TInputBox.class.php';
        // obt�m o item selecionado da lista
        $selectedItem = $this->list->getSelected();
        
        if ($selectedItem) // verifica se h� item selecionado
        {
            // abre uma caixa de di�logo pedindo o item
            $dialog = new TInputBox('Preencha os dados', 'Novo Item', $selectedItem[0]);
            $resposta = $dialog->run();
            
            // verifica a resposta da a��o
            if ($resposta == Gtk::RESPONSE_OK)
            {
                // atribui o conte�do digitado ao elemento selecioando na lista
                $this->list->setSelected(array($dialog->get_text()));
            }
            // fecha di�logo
            $dialog->destroy();
        }
    }
    
    /*
     * M�todo onDeleteItem
     * Remove o elemento selecionado na lista
     */
    function onDeleteItem()
    {
        $this->list->delSelected();
    }

    /*
     * M�todo onClearItems
     * Remove todos elementos da lista
     */
    function onClearItems()
    {
        $this->list->Clear();
    }

    /*
     * M�todo onSaveItems
     * Retorna todos itens da lista para uma fun��o
     * definida pelo usu�rio (callback)
     */
    function onSaveItems()
    {
        // obt�m todos itens da lista
        $items = $this->list->getItems();
        // verifica se h� itens selecionados
        if ($items)
        {
            // obt�m somente a primeira coluna
            foreach ($items as $item)
            {
                $result[] = $item[0];
            }
        }
        // executa a fun��o programada pelo
        // usu�rio, passando o resultado
        call_user_func($this->callback, $result);
    }
    
    /*
     * M�todo setCallBack
     * Define a a��o do bot�o salvar
     * ou seja, a fun��o a ser executada
     */
    public function setCallBack($callback)
    {
        $this->callback = $callback;
    }
}
?>