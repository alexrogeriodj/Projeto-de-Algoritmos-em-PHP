<?php
include_once 'TMenu.class.php';
class ExemploMenu
{
    function __construct()
    {
        $janela = new GtkWindow;
        
        $menu['_Cadastros'][] = array('images/menu_abrir.png',  'Clientes',     array($this, 'onCliente'));
        $menu['_Cadastros'][] = array('images/menu_salvar.png', 'Mercadorias',  array($this, 'onMercadoria'));
        $menu['_Cadastros'][] = array('',                       'Sair',         array('Gtk', 'main_quit'));
        
        $menu['_Relat�rios'][] = array('images/menu_abrir.png',  'Listagens',   NULL);
        $menu['_Relat�rios'][] = array('images/menu_salvar.png', 'Gr�ficos',    NULL);
        
        $MenuBar = new TMenu($menu);
        $janela->add($MenuBar);
        $janela->show_all();
    }
    
    function onCliente()
    {
        echo "selecionou Cliente\n";
    }
    
    function onMercadoria()
    {
        echo "selecionou Mercadoria\n";
    }
}

new ExemploMenu;
Gtk::Main();
?>
