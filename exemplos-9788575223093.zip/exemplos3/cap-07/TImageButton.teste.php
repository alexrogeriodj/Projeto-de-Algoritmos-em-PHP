<?php
include_once 'TImageButton.class.php';

class ExemploBotao
{
    function __construct()
    {
        $janela = new GtkWindow;
        $hbox = new GtkHbox;
        
        $botao1 = new TImageButton('Home',   'images/home.png',     array($this, 'onHome'));
        $botao2 = new TImageButton('Config', 'images/config.png',   array($this, 'onConfig'));
        $botao3 = new TImageButton('Imprime','images/print.png',    array($this, 'onImprime'));
        
        $hbox->pack_start($botao1);
        $hbox->pack_start($botao2);
        $hbox->pack_start($botao3);
        $janela->add($hbox);
        $janela->show_all();
    }
    function onHome()
    {
        echo "Clicou no Home\n";
    }
    function onConfig()
    {
        echo "Clicou no Config\n";
    }
    function onImprime()
    {
        echo "Clicou no Imprime\n";
    }
}

new ExemploBotao;

Gtk::main();
?>