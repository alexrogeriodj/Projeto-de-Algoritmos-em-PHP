<?php
include_once 'TCalculator.class.php';

$calculadora = new TCalculator;

$calculadora->setCallBack('onExibeResultado');

function onExibeResultado($resultado)
{
	echo $resultado;
}

Gtk::Main();
?>