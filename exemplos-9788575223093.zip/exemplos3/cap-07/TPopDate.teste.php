<?php
include_once 'TPopDate.class.php';

$window = new GtkWindow;

$date = new TPopDate;

$window->add($date);
$window->show_all();
Gtk::Main();
?>