<?php
/* 
 * classe TInputBox
 * Solicita digita��o de um valor ao usu�rio
 */
class TInputBox extends GtkDialog
{
    private $input; // cont�m o GtkEntry para digita��o do valor
    
    /*
     * m�todo construtor, cria o di�logo
     * $title   = t�tulo da janela
     * $frase   = o que � pedido ao usu�rio
     * $default = resposta padr�o
     */
    public function __construct($title, $frase, $default = '')
    {
        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkDialog"
        parent::__construct($title, null, 0, array( Gtk::STOCK_OK, Gtk::RESPONSE_OK,
                                                    Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));
        
        // adiciona o label com a frase ao usu�rio
        $this->vbox->pack_start(new GtkLabel($frase));
        
        // cria campo para digita��o
        $this->input = new GtkEntry;
        $this->input->set_text($default);
        
        // adiciona campo para digita��o
        $this->vbox->pack_start($this->input);
        
        // exibe janela
        $this->show_all();
    }
    
    /*
     * m�todo get_text()
     * criado especialmente para retornar
     * o valor digitado pelo usu�rio
     */
    public function get_text()
    {
        return $this->input->get_text();
    }
}
?>