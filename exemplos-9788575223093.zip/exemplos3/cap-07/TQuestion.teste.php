<?php
include_once 'TQuestion.class.php';

$dialog = new TQuestion('Deseja apagar o arquivo ?');

$resposta= $dialog->run();

if ($resposta == Gtk::RESPONSE_YES)
{
    echo "escolheu sim\n";
}
$dialog->destroy();
?>