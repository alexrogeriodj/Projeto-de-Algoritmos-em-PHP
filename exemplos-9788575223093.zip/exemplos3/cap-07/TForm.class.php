<?php
/*
 * Classe TForm
 * Encapsula as funcionalidades de
 * um formul�rio de entrada de dados
 */
class TForm extends GtkVBox
{
    private $fields; // vetor contendo os campos do form
    
    /*
     * M�todo construtor
     */
    public function __construct()
    {
        parent::__construct();
        parent::set_border_width(4);
        
        $this->fields = array();
    }

    /*
     * Adiciona um campo ao formul�rio
     * $name   = Nome do campo
     * $text   = Descri��o do campo
     * $object = Objeto a ser adicionado
     * $width  = Largura do objeto
     */
    public function addField($name, $text, GtkWidget $object, $width = 240)
    {
        // verifica se o campo j� foi adicionado
        if (isset($this->fields[$name]))
        {
            return false;
        }
        
        // adiciona no vetor de campos
        $this->fields[$name] = $object;
        // redimensiona o objeto
        $object->set_size_request($width, -1);
        
        // cria uma linha (caixa horizontal)
        $hbox  = new GtkHBox;
        
        // cria um r�tulo para o campo
        $label = new GtkLabel;
        $label->set_alignment(1,0.5);
        $label->set_markup("$text : ");
        $label->set_size_request(200,-1);
        
        // adiciona o r�tulo e o objeto na caixa horizontal
        $hbox->pack_start($label,  false, false);
        $hbox->pack_start($object, false, false);
        
        // adiciona a caixa horizintal no form
        parent::pack_start($hbox, false, false);
    }
    
    /*
     * Retorna um campo do formul�rio
     * $name = Nome do campo
     */
    public function getField($name)
    {
        return $this->fields[$name];
    }
    
    /*
     * Adiciona um separador ao form
     * $label = Nome do separador
     */
    public function addSeparator($label)
    {
        // cria uma caixa horizontal
        $hbox = new GtkHBox;
        // adiciona o r�tulo
        $hbox->pack_start(new GtkLabel("  $label"), false, false);
        // adiciona o separador
        $hbox->pack_start(new GtkHSeparator, true, true);
        
        // coloca a caixa horizontal no form
        parent::pack_start($hbox, false, false);
    }
    
    /*
     * Atribui dados ao formul�rio
     * $object = Objeto com os dados
     */
    public function setData(StdClass $object)
    {
        // l� as propriedades do objeto
        $properties = get_object_vars($object);
        
        // percorre as propriedades do objeto
        foreach ($properties as $property => $value)
        {
            // verifica se h� campo no form com este nome
            if ($this->fields[$property])
            {
                // testa o tipo de campo que h� no form
                switch (get_class($this->fields[$property]))
                {
                    case 'GtkEntry':
                        $this->fields[$property]->set_text($value);
                        break;
                    case 'GtkSpinButton':
                        $this->fields[$property]->set_text($value);
                        break;
                  case 'GtkComboBox':
                        $this->fields[$property]->set_active($value);
                }
            }
        }
    }

    /*
     * Retorna os dados do formul�rio
     * em forma de um objeto
     */
    public function getData()
    {
        // percorre os campos do formul�rio
        foreach ($this->fields as $name => $field)
        {
            // testa o tipo de campo que h� no form
            switch (get_class($field))
            {
                case 'GtkEntry':
                    $object->$name = $field->get_text();
                    break;
                case 'GtkSpinButton':
                    $object->$name = $field->get_text();
                    break;
                case 'GtkComboBox':
                    $object->$name = $field->get_active();
                    break;
            }
        }
        return $object;
    }

    /*
     * Exibe o formul�rio
     */
    public function Show()
    {
        $this->show_all();
    }

    /*
     * Limpa os campos do formul�rio
     */
    public function Clear()
    {
        // percorre os campos do form
        foreach ($this->fields as $field)
        {
            // testa o tipo de campo que h� no form
            switch (get_class($field))
            {
                case 'GtkEntry':
                    $field->set_text('');
                    break;
                case 'GtkSpinButton':
                    $field->set_text('');
                    break;
                case 'GtkComboBox':
                    $field->set_active(-1);
                    break;
            }
        }
    }
}
?>
