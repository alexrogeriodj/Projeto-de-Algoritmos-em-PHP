<?php
/* classe TCalculator
 * Simula uma calculadora com fun��es b�sicas
 */
class TCalculator extends GtkWindow
{
    private $entry;     // display da calculadora
    private $callback;  // a��o do bot�o ">>"
    
    /*
     * M�todo construtor
     * Cria a janela e define as a��es dos bot�es
     */
    function __construct()
    {
        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkWindow"
        parent::__construct();
        
        // cria campo de digita��o para valores
        $this->entry = new GtkEntry;
        
        // cria bot�o para retornar o c�lculo ">>"
        $resolve = new GtkButton(chr(187));
        // define a a��o do bot�o
        $resolve->connect_simple('clicked', array($this, 'onResolve'));
        
        // cria uma caixa horizontal para o display
        $hbox = new GtkHbox;
        $hbox->pack_start($this->entry);
        $hbox->pack_start($resolve);
        
        // cria uma caixa horizontal
        $vbox = new GtkVBox;
        $vbox->pack_start($hbox);
        
        // cria uma matriz contendo os bot�es que a calculadora ter�
        $linhas[1] = array('7', '8', '9', '/');
        $linhas[2] = array('4', '5', '6', '*');
        $linhas[3] = array('1', '2', '3', '-');
        $linhas[4] = array('0', ',', '=', '+');
        
        // percorre a matriz
        foreach ($linhas as $linha => $caracteres)
        {
            // cria uma linha de bot�es (caixa horizontal)
            $hbox = new GtkHBox;
            $hbox->set_homogeneous(true);
            $vbox->pack_start($hbox);
            
            // percorre os bot�es de uma mesma linha
            foreach ($caracteres as $caracter)
            {
                // cria o bot�o
                $botao[$caracter] = new GtkButton($caracter);
                // define a a��o do bot�o = onDigita($caracter)
                $botao[$caracter]->connect_simple('clicked', array($this, 'onDigita'), $caracter);
                // empacota o bot�o na linha (hbox)
                $hbox->pack_start($botao[$caracter]);
            }
        }
        // adiciona a caixa vertical na janela
        parent::add($vbox);
        parent::show_all();
    }
    
    /*
     * M�todo onDigita
     * Para cada bot�o clicado, exibe o caracter correspondente no visor
     * Se o bot�o for "=", realiza o c�lculo e exibe o resultado
     */
    function onDigita($caracter)
    {
        // verifica se � para calcular o resultado
        if ($caracter === '=')
        {
            // substitui v�rgula por ponto para evitar erros de c�lculo
            $display = str_replace(',', '.', $this->entry->get_text());
            // calcula o resultado
            eval("\$result = $display;");
            // joga no display o resultado
            $this->entry->set_text(str_replace('.', ',', $result));
        }
        else // somente exibe o caracter
        {
            // obt�m o conte�do do display
            $texto = $this->entry->get_text();
            // adiciona o caracter no display
            $this->entry->set_text($texto.$caracter);
        }
    }
    
    /*
     * M�todo setCallBack
     * Define a fun��o que ser� executada quando o usu�rio
     * clicar no bot�o ">>", encerrando o c�lculo
     */
    function setCallBack($callback)
    {
        $this->callback = $callback;
    }

    /*
     * M�todo onResolve
     * Executa a fun��o definida pelo usu�rio
     * quando clicar no bot�o ">>", retornando o valor do display
     */
    function onResolve()
    {
        call_user_func($this->callback, $this->entry->get_text());
    }
}
?>