<?
/*
 * Classe TFileTree
 * Prov� as funcionalidades de uma �rvore
 * de navega��o de arquivos
 */
class TFileTree extends GtkTreeView
{
    private $model;     // modelo de dados da �rvore
    private $callback;  // a��o ao selecionar arquivo
    /*
     * m�todo construtor
     * Cria a �rvore
     */
    function __construct()
    {
        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkTreeView"
        parent::__construct();
        
        // verifica o separador de diret�rios de acordo com o S.O.
        define('OS', strtoupper(substr(PHP_OS, 0, 3)));
        if (OS == 'WIN')
        {
            define("bar", '\\');
        }
        else
        {
            define("bar", '/');
        }
        
        // cria o modelo de dados
        $this->model = new GtkTreeStore(GObject::TYPE_STRING, GObject::TYPE_STRING, GObject::TYPE_STRING);
        
        // define a a��o de quando for clicado sobre a �rvore
        $this->connect('button-release-event', array($this, 'onAbrirPasta'));
        parent::set_model($this->model);
        
        // cria duas colunas
        $column1 = new GtkTreeViewColumn('Explorer');
        $column2 = new GtkTreeViewColumn();
        
        // cria os renderizadores para as colunas
        $cell_renderer1 = new GtkCellRendererPixbuf();
        $cell_renderer2 = new GtkCellRendererText();
        
        // adiciona os renderizadores nas colunas
        $column1->pack_start($cell_renderer1, false);
        $column1->pack_start($cell_renderer2, false);
        
        // define o conte�do de cada renderizador em rela��o ao modelo
        $column1->set_attributes($cell_renderer1, 'stock-id', 0);
        $column1->set_attributes($cell_renderer2, 'text', 1);
        parent::append_column($column1);
    }

    /*
     * m�todo onAbrirPasta
     * Executado sempre que um nodo � clicado
     */
    public function onAbrirPasta()
    {
        // obt�m a sele��o da �rvore
        $treeselection = parent::get_selection();
        list($model, $iter) = $treeselection->get_selected();
        // se h� sele��o...
        if ($iter)
        {
            // obt�m o caminho do nodo
            $caminho = $model->get_value($iter, 2);
            
            // verifica se � um diret�rio
            if (is_dir($caminho))
            {
                // limpa o modelo
                $this->model->clear();
                // abre conte�do da pasta
                $this->abreDiretorio($caminho);
            }
            else // se � um arquivo...
            {
                // executa a fun��o programada pelo
                // usu�rio, passando o caminho do arquivo
                call_user_func($this->callback, $caminho);
            }
        }
    }

    /*
     * m�todo abreDiretorio
     * L� o conte�do de um diret�rio e exibe na �rvore de arquivos
     */
    function abreDiretorio($caminho)
    {
        // abre diret�rio
        $dir = @opendir($caminho);
        if ($caminho == bar)
        {
            $caminho = '';
        }
        // percorre o conte�do do diret�rio
        while (($arquivo = readdir($dir)) !== false)
        {
            // verifica se come�a com ponto ou termina com til
            if ((substr(trim($arquivo),0,1) != '.') and (substr($arquivo,-1) != '~'))
            {
                // verifica se � um diretorio ou arquivo
                if (is_dir($caminho . bar . $arquivo))
                {
                    $pastas[] = $arquivo;
                }
                else
                {
                    $arquivos[] = $arquivo;
                }
            }
        }
        
        // adiciona nova linha no modelo
        // esta linha ir� conter o bot�o subir n�vel
        $iter = $this->model->append();
        $this->model->set($iter, 0, 'gtk-go-up');
        $this->model->set($iter, 1, 'up');
        $this->model->set($iter, 2, $caminho . bar . '..');
        
        // verifica se encontrou pastas 
        if (isset($pastas))
        {
            // ordena as pastas
            sort($pastas);
            
            // percorre as pastas
            foreach ($pastas as $arquivo)
            {
                $localizacao = $caminho . bar . $arquivo;
                
                // adiciona a linha na �vore contendo a pasta
                $iter = $this->model->append();
                $this->model->set($iter, 0, 'gtk-directory');
                $this->model->set($iter, 1, $arquivo);
                $this->model->set($iter, 2, $localizacao);
            }
        }
        
        // verifica se encontrou pastas 
        if (isset($arquivos))
        {
            // ordena os arquivos
            sort($arquivos);
            
            // percorre as pastas
            foreach ($arquivos as $arquivo)
            {
                $localizacao = $caminho . bar . $arquivo;
                
                // adiciona a linha na �vore contendo o arquivo
                $iter = $this->model->append();
                $this->model->set($iter, 0, 'gtk-file');
                $this->model->set($iter, 1, $arquivo);
                $this->model->set($iter, 2, $localizacao);
            }
        }
    }
    
    /*
     * M�todo setCallBack
     * Define a a��o ao selecionar arquivo
     * ou seja, a fun��o a ser executada
     */
    function setCallBack($callback)
    {
        $this->callback = $callback;
    }
}
?>
