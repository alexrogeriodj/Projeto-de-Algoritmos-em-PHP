<?php
/* 
 * classe TMenu
 * classe para simplificar a exibi��o de menus
 */
class TMenu extends GtkMenuBar
{
    /*
     * m�todo construtor, cria o menu
     * $array = matriz contendo o menu
     */
    function __construct($array)
    {
        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkMenuBar"
        parent::__construct();
        
        // percorre o array de menus
        foreach ($array as $menu => $submenu)
        {
            // cria um item de menu e adiciona
            // na barra de menu
            $Menu = new GtkMenuItem($menu);
            parent::append($Menu);
            
            // cria um submenu
            $SubMenu = new GtkMenu;
            $Menu->set_submenu($SubMenu);
            // percorre cada op��o do submenu
            foreach ($submenu as $opcao)
            {
                $imagem   = $opcao[0];
                $label    = $opcao[1];
                $callback = $opcao[2];
                
                // cria o item de menu
                $item = new GtkImageMenuItem($label);
                if ($imagem)
                {
                    $item->set_image(GtkImage::new_from_file($imagem));
                }
                // define a a��o do item
                if ($callback)
                {
                    $item->connect_simple('activate', $callback);
                }
                $SubMenu->append($item);
            }
        }
    }
}
?>