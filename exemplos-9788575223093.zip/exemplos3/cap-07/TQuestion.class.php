<?php
/* 
 * classe TQuestion
 * classe realizar perguntas ao usu�rio
 */
class TQuestion extends GtkMessageDialog
{
    /*
     * m�todo construtor, cria o di�logo
     * $frase = pergunta a ser feita
     */
    public function __construct($frase)
    {
        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkMessageDialog"
        parent::__construct(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_QUESTION,
                                  Gtk::BUTTONS_YES_NO, $frase);
    }
}
?>