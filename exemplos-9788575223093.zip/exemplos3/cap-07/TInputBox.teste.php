<?php
include_once 'TInputBox.class.php';

$dialogo = new TInputBox('t�tulo da janela', 'Digite o Nome', '<digite aqui>');

$resposta = $dialogo->run();

if ($resposta == Gtk::RESPONSE_OK)
{
    echo $dialogo->get_text();
}
?>