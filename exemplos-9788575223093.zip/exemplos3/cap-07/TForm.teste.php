<?php
include_once 'TForm.class.php';
class ExemploForm
{
    private $form; // cont�m o objeto formul�rio
    
    function __construct()
    {
        $janela = new GtkWindow;
        $janela->set_size_request(470,200);
        
        $codigo     = new GtkEntry;
        $nome       = new GtkEntry;
        $endereco   = new GtkEntry;
        $telefone   = new GtkEntry;
        
        $salvar     = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
        $salvar->connect_simple('clicked', array($this, 'onSave'));
        
        $this->form = new TForm;
        $this->form->addField('codigo',   'C�digo',   $codigo,    140);
        $this->form->addField('nome',     'Nome',     $nome,      240);
        $this->form->addField('endereco', 'Endere�o', $endereco,  240);
        $this->form->addField('telefone', 'Telefone', $telefone,  240);
        $this->form->addSeparator('A��o');
        $this->form->addField('salvar',   'Salvar',   $salvar,    100);
        $this->form->show();
        
        $dados_iniciais->codigo   = '1';
        $dados_iniciais->telefone = '(51) XXXX-XXXX';
        $this->form->setData($dados_iniciais);
        
        $janela->add($this->form);
        $janela->show_all();
    }
    
    function onSave()
    {
        $objeto = $this->form->getData();
        
        echo "C�digo:   " . $objeto->codigo   . "\n";
        echo "Nome:     " . $objeto->nome     . "\n";
        echo "Endere�o: " . $objeto->endereco . "\n";
        echo "Telefone: " . $objeto->telefone. "\n";
        
        $this->form->Clear();
    }
}

new ExemploForm;
Gtk::main();
?>