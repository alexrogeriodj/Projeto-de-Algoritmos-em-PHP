<?php
include_once 'TEditList.class.php';

$janela_edicao = new TEditList;
$janela_edicao->set_size_request(200,240);

$janela_edicao->setCallBack('onSave');

function onSave($values)
{
    print_r($values);
}

Gtk::Main();
?>