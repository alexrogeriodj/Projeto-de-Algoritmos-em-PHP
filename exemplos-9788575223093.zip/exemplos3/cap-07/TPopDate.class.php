<?php
/* 
 * classe TPopDate
 * Prov� um campo de digita��o auxiliado
 * por um seletor de datas que abre
 * uma janela com um calend�rio
 */
class TPopDate extends GtkHBox
{
    private $entry;     // campo de digita��o
    private $calendar;  // objeto calend�rio
    
    /*
     * m�todo construtor
     * cria a caixa horizontal, 
     * o campo de digita��o e o bot�o do calend�rio
     */
    function __construct()
    {
        // instancia caixa horizontal
        parent::__construct();
        
        // cria caixa de digita��o
        $this->entry    = new GtkEntry;
        
        // bloqueia edi��o do campo
        $this->entry->set_editable(false);
        
        // adiciona campo na caixa horizontal
        parent::add($this->entry);
        
        // cria bot�o com imagem de calend�rio
        $button = new GtkButton;
        $button->set_relief(GTK::RELIEF_NONE);
        $imagem = GtkImage::new_from_file('icons/popdate.png');
        
        // atribui a imagem ao bot�o
        $button->set_image($imagem);
        
        // define a��o do bot�o (onCalendar)
        $button->connect_simple('clicked', array($this, 'onCalendar'));
        parent::add($button);
    }
    
    /*
     * m�todo onCalendar
     * abre o calend�rio, permitindo a sele��o de data
     */
    function onCalendar()
    {
        // abre janela nova
        $this->popWindow = new GtkWindow;
        // cria calend�rio
        $this->calendar = new GtkCalendar;
        // define a a��o ao selecionar uma data no calend�rio (onSelectDate)
        $this->calendar->connect_simple('day-selected-double-click', array($this, 'onSelectDate'));
        
        // exibe janela
        $this->popWindow->add($this->calendar);
        $this->popWindow->show_all();
    }
    
    /*
     * m�todo onSelectDate
     * executado quando o usu�rio selecionar uma data
     */
    function onSelectDate()
    {
        // obt�m a data selecionada
        $date = $this->calendar->get_date();
        // obt�m o dia
        $day = str_pad($date[2], 2, '0', STR_PAD_LEFT);
        // obt�m o m�s
        $month = str_pad($date[1] +1, 2, '0', STR_PAD_LEFT);
        // obt�m o ano
        $year = $date[0];
        
        // joga tudo na caixa de texto (display)
        $this->entry->set_text("$day/$month/$year");
        
        // fecha janela do calend�rio
        $this->popWindow->hide();
    }
  
    /*
     * m�todo get_text
     * retorna o conte�do da caixa de entrada de dados
     */
    function get_text()
    {
        // retorna o conte�do
        return $this->entry->get_text();
    }
}
?>