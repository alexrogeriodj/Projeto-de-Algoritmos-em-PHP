<?php
/* 
 * classe TMessage
 * classe para emitir mensagens ao usu�rio
 */
class TMessage extends GtkMessageDialog
{
    /*
     * m�todo construtor, cria o di�logo
     * $tipo  = 'info'  para mensagem de informa��o
     *          'error' para mensagem de erro
     * $frase = mensagem a ser exibida
     */
    public function __construct($tipo, $frase)
    {
        // verifica o tipo de mensagem
        $constante = $tipo == 'info' ? Gtk::MESSAGE_INFO : Gtk::MESSAGE_ERROR;

        // chama o m�todo construtor da classe pai
        // mesmo que "new GtkMessageDialog"
        parent::__construct(null, Gtk::DIALOG_MODAL, $constante,
                                  Gtk::BUTTONS_OK, $frase);
        // exibe o di�logo
        parent::run();
        parent::destroy();
    }
}
?>
