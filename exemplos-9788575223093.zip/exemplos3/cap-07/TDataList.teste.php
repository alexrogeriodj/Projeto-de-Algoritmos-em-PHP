<?php
include_once 'TDataList.class.php';
class ExemploLista
{
    private $list; // cont�m o objeto lista
    
    function __construct()
    {
        $janela = new GtkWindow;
        $janela->set_size_request(470,200);
        
        $this->list = new TDataList;
        
        $this->list->connect_simple('row-activated', array($this, 'onSelect'));
        
        $this->list->addColumn('Pa�s',      'pixbuf');
        $this->list->addColumn('C�digo',    'text');
        $this->list->addColumn('Nome',      'text');
        $this->list->addColumn('Telefone',  'text');
        
        $this->list->createModel();
        
        $dados[] = array('flags/spain.png',    '1', 'Maria',  '(51) 1234-5678');
        $dados[] = array('flags/italy.png',    '2', 'Joana',  '(51) 1234-5678');
        $dados[] = array('flags/uruguay.png',  '3', 'Pedro',  '(51) 1234-5678');
        $dados[] = array('flags/france.png',   '4', 'Carlos', '(51) 1234-5678');
        
        foreach ($dados as $linha)
        {
            $this->list->addItem($linha);
        }
        
        $scroll = new GtkScrolledWindow;
        $scroll->add($this->list);
        
        $janela->add($scroll);
        $janela->show_all();
    }
    
    function onSelect()
    {
        $selected = $this->list->getSelected();
        
        echo "C�digo   : " . $selected[1] . "\n";
        echo "Nome     : " . $selected[2] . "\n";
        echo "Telefone : " . $selected[3] . "\n";
    }
}

new ExemploLista;
Gtk::main();
?>