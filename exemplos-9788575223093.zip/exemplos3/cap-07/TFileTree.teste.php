<?php
include_once 'TFileTree.class.php';

$janela = new GtkWindow;
$janela->set_title('GtkTreeView');
$janela->set_size_request(300,400);

$scroll = new GtkScrolledWindow;
$scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
$janela->add($scroll);

$filetree = new TFileTree;
if (OS == 'WIN')
{
    $filetree->AbreDiretorio('\\');
}
else
{
    $filetree->AbreDiretorio('/');
}

$filetree->setCallback('onSelect');

$scroll->add($filetree);

$janela->show_all();

function onSelect($arquivo)
{
    echo $arquivo . "\n";
}
Gtk::Main();
?>