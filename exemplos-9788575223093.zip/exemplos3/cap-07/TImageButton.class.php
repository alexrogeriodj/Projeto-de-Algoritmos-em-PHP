<?php
/*
 * Classe TImageButton
 * Encapsula a exibi��o de bot�es com imagem
 */
class TImageButton extends GtkButton
{
    /*
     * m�todo construtor, cria o bot�o
     * $label = r�tulo do bot�o
     * $image = imagem do bot�o
     * $action= a��o do bot�o
     */
    public function __construct($label, $image, $action)
    {
        // verifica se a imagem existe
        if (file_exists($image))
        {
            // chama o m�todo construtor da classe pai
            // mesmo que "new GtkButton"
            parent::__construct();
            
            // atribui o r�tulo
            parent::set_label($label);
            
            // atribui a imagem
            parent::set_image(GtkImage::new_from_file($image));
            
            // define a a��o do bot�o
            parent::connect_simple('clicked', $action);
        }
    }
}
?>