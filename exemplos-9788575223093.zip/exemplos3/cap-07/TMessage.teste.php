<?php
include_once 'TMessage.class.php';

new TMessage('info', 'Warning: Saldo insuficiente !!');

new TMessage('error', 'Kernel Panic !!');
?>