<?php
include_once 'TEditor.class.php';

new TEditor;

Gtk::Main();
?>