<?php
function onKeyTest($widget, $key)
{
    global $label;
    $label->set_markup('C�digo da tecla pressionada: <b>' . $key->keyval . '</b>');
}

$window = new GtkWindow;
$window->set_default_size(300,100);
$window->set_title('Testador de Teclas');
$window->set_position(GTK::WIN_POS_CENTER);

$label = new GtkLabel('Pressione qualquer tecla');
$window->add($label);

$window->connect('key-press-event', 'onKeyTest');

$window->show_all();
Gtk::main();
?>