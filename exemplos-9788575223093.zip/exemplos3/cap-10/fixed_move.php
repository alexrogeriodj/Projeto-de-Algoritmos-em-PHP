<?php
class ExemploFixed
{
    private $imagem;
    private $fixed;
    private $row = 40;
    private $col = 40;
    
    public function __construct()
    {
        $window = new GtkWindow;
        $window->set_title('fixed');
        $window->set_default_size(300,300);
        $window->set_position(GTK::WIN_POS_CENTER);
        
        $window->connect('key-press-event', array($this, 'onKeyPress'));
        
        $this->fixed = new GtkFixed;
        $window->add($this->fixed);
        
        $this->imagem = GtkImage::new_from_animation(new GdkPixbufAnimation('gifs/catch.gif'));
        $this->fixed->put($this->imagem, $this->col, $this->row);
        
        $shark = GtkImage::new_from_animation(new GdkPixbufAnimation('gifs/shark.gif'));
        $this->fixed->put($shark, 180, 180);
        
        $window->show_all();
    }
    
    public function onKeyPress($widget, $key)
    {
        switch ($key->keyval)
        {
            case Gdk::KEY_Left:
                if ($this->col > 0)
                {
                    $this->col -= 4;
                }
                break;
            case Gdk::KEY_Up:
                if ($this->row > 0)
                {
                    $this->row -= 4;
                }
                break;
            case Gdk::KEY_Right:
                if ($this->col < 220)
                {
                    $this->col += 4;
                }
                break;
            case Gdk::KEY_Down:
                if ($this->row < 220)
                {
                    $this->row += 4;
                }
                break;
        }
        
        $this->fixed->move($this->imagem, $this->col, $this->row);
    }
}

new ExemploFixed;
Gtk::Main();
?>