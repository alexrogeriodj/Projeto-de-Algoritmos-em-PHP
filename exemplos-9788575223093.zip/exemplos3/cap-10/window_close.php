<?php
class ExemploWindowClose
{
    private $window;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->move(200,200);
        $this->window->set_default_size(200,200);
        $this->window->set_title('Pergunta ao fechar');
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $this->window->add(new GtkLabel('tente fechar a janela...'));
        
        $this->window->connect_simple('delete-event', array($this, 'onClose'));
        $this->window->connect_simple('destroy', array('Gtk', 'main_quit'));
        
        $this->window->show_all();
    }

    function onClose()
    {
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_QUESTION,
                                             Gtk::BUTTONS_YES_NO,
                                             'Deseja fechar a janela ?');
        $response = $dialog->run();
        
        $dialog->destroy();
        
        if ($response == Gtk::RESPONSE_YES)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}

new ExemploWindowClose;
Gtk::main();
?>
