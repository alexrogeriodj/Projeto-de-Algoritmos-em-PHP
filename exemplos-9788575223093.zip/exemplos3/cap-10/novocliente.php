<?php
/**
 * classe NovoCliente
 * Formul�rio de cadastro de Clientes GTK
 */
class NovoCliente extends GtkWindow
{
    /**
     * m�todo construtor
     * instancia a janela e constr�i os campos
     */
    public function __construct()
    {
        parent::__construct();
        parent::set_title('Incluir');
        parent::connect_simple('destroy', array('Gtk', 'main_quit'));
        parent::set_default_size(400, -1);
        parent::set_border_width(10);
        parent::set_position(GTK::WIN_POS_CENTER);
        
        $codigo     = new GtkEntry;
        $nome       = new GtkEntry;
        $endereco   = new GtkEntry;
        $telefone   = new GtkEntry;
        
        $salvar     = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
        $salvar->connect_simple('clicked', array($this, 'onSave'));
        
        $this->form = new TForm;
        $this->form->addField('codigo',   'C�digo',   $codigo,    140);
        $this->form->addField('nome',     'Nome',     $nome,      240);
        $this->form->addField('endereco', 'Endere�o', $endereco,  240);
        $this->form->addField('telefone', 'Telefone', $telefone,  240);
        $this->form->addSeparator('A��o');
        $this->form->addField('salvar',   'Salvar',   $salvar,    100);
        $this->form->show();
        
        parent::add($this->form);
        parent::show_all();
    }
    
    /**
     * m�todo onSave()
     * Executado quando usu�rio clica no bot�o salvar
     */
    public function onSave()
    {
        // obt�m os valores dos campos
        $dados = $this->form->getData();
        try
        {
            // instancia cliente SOAP
            $client = new SoapClient(NULL, array('encoding'   =>'ISO-8859-1',
                                                 'exceptions' => TRUE,
                                                 'location'   => "http://127.0.0.1/server.php",
                                                 'uri'        => "http://test-uri/"));
            
            // realiza chamada remota de m�todo
            $retorno = $client->salvar($dados);
            
            // exibe di�logo de mensagem
            $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                           Gtk::BUTTONS_OK, 'Registro inserido com sucesso!');
            $dialog->run();
            $dialog->destroy();
        }
        catch (SoapFault $excecao) // ocorr�ncia de erro
        {
            // exibe di�logo de erro
            $error = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_ERROR,
                                            Gtk::BUTTONS_OK, $excecao->getMessage());
            $error->run();
            $error->destroy();
        }
    }
}

include_once 'TForm.class.php';

// instancia janela NovoCliente
new NovoCliente;
Gtk::Main();
?>
