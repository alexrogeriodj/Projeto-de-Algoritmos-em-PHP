<?php
function onDataGet($widget, $context, $selection)
{
    $selection->set_text('Parabens, o drag n\' drop funcionou');
}

function onDataReceived($widget, $context, $x, $y, $selection)
{
    $text = $selection->get_text();
    
    $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                     Gtk::BUTTONS_OK, $text);
    $dialog->run();
    $dialog->destroy();

}

$window = new GtkWindow;
$window->set_default_size(240,40);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Drag n Drop');
$window->set_border_width(20);

$targets = array(array('text/plain', 0, -1));

$button1 = new GtkButton(' Arraste me ');
$button1->connect('drag_data_get', 'onDataGet');
$button1->drag_source_set(Gdk::BUTTON1_MASK | Gdk::BUTTON3_MASK | Gdk::SHIFT_MASK, $targets, Gdk::ACTION_COPY);
$button1->drag_source_set_icon_stock(Gtk::STOCK_ADD);

$button2 = new GtkButton(' Para c� ');
$button2->connect('drag_data_received', 'onDataReceived');
$button2->drag_dest_set(Gtk::DEST_DEFAULT_ALL, $targets, Gdk::ACTION_COPY);

$hbox = new GtkHBox;
$hbox->pack_start($button1);
$hbox->pack_start($button2);
$window->add($hbox);

$window->show_all();
Gtk::main();
?>