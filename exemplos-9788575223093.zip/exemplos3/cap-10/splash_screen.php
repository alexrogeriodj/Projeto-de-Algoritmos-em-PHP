<?php
class JanelaSplash
{
    private $window;

    public function __construct()
    {
        $this->window = new GtkWindow(Gtk::WINDOW_POPUP);
        $this->window->set_default_size(400,300);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $pixbuf = GdkPixbuf::new_from_file('icons/splash.png');
        $imagem = new GtkImage;
        $imagem->set_from_pixbuf($pixbuf);
        
        $this->window->add($imagem);
        $this->window->show_all();
        
        Gtk::timeout_add(2000, array($this, 'onStart'));
    }
    
    public function onStart()
    {
        $this->window->destroy();
        
        new Application;
    }
}

class Application
{
    private $window;
    
    function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_default_size(600,400);
        $this->window->set_border_width(80);
        $this->window->set_title('Aplica��o...');
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $this->window->show_all();
    }
}

new JanelaSplash;
Gtk::main();
?>
