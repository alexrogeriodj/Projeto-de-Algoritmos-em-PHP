<?php
$window = new GtkWindow;
$window->set_default_size(200,140);
$window->set_title('Acelera��o');
$window->set_position(GTK::WIN_POS_CENTER);

$accgrp = new GtkAccelGroup();
$window->add_accel_group($accgrp);

$salva = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
$sair  = GtkButton::new_from_stock(Gtk::STOCK_QUIT);

$salva->add_accelerator('activate', $accgrp, Gdk::KEY_S, Gdk::CONTROL_MASK, Gtk::ACCEL_VISIBLE);

$sair->add_accelerator('activate', $accgrp, Gdk::KEY_F10, 0, Gtk::ACCEL_VISIBLE);

$vbox = new GtkVBox();
$vbox->pack_start(new GtkLabel('CTRL+S => Salva'));
$vbox->pack_start($salva, false, false);
$vbox->pack_start(new GtkLabel('F10    => Sair'));
$vbox->pack_start($sair, false, false);

$window->add($vbox);
$window->show_all();
Gtk::main();
?>