<?
$window = new GtkWindow;
$window->set_default_size(200,100);
$window->set_border_width(20);
$window->set_position(GTK::WIN_POS_CENTER);

$vbox   = new GtkVBox;

$botao1 = GtkButton::new_from_stock(Gtk::STOCK_NETWORK);
$botao2 = GtkButton::new_from_stock(Gtk::STOCK_PREFERENCES);

$window->add($vbox);

$vbox->pack_start($botao1);
$vbox->pack_start($botao2);

$window->show_all();

$tooltip = new GtkTooltips();

$tooltip->set_tip($botao1, "Clique neste bot�o\npara configuarar a rede");
$tooltip->set_tip($botao2, "Clique neste bot�o\npara prefer�ncias");

Gtk::main();
?>