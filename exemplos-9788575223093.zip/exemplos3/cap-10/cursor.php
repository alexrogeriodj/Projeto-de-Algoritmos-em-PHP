<?php
function onTrocaCursor($cursor, $window, $botao)
{
    $cursor ++;
    $botao->set_label("Cursor usado : $cursor");
    $window->window->set_cursor(new GdkCursor($cursor));
}

$window = new GtkWindow;
$window->set_default_size(240,200);
$window->set_border_width(40);
$window->set_title('C�digos de cursor');
$window->set_position(GTK::WIN_POS_CENTER);

$botao = new GtkButton('troca cursor');

$botao->connect_simple('clicked', 'onTrocaCursor', &$cursor, $window, $botao);
$window->add($botao);

$window->show_all();
Gtk::main();
?>