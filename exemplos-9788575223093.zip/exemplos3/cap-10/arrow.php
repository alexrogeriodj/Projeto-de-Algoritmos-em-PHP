<?php
$window = new GtkWindow;
$window->set_default_size(200,-1);
$window->set_title('Arrows');
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_border_width(10);

$hbox = new GtkHBox;

$botao1 = new GtkButton;
$botao2 = new GtkButton;
$botao3 = new GtkButton;
$botao4 = new GtkButton;

$arrow1 = new GtkArrow(Gtk::ARROW_UP,   Gtk::SHADOW_NONE);
$arrow2 = new GtkArrow(Gtk::ARROW_DOWN, Gtk::SHADOW_NONE);
$arrow3 = new GtkArrow(Gtk::ARROW_LEFT, Gtk::SHADOW_NONE);
$arrow4 = new GtkArrow(Gtk::ARROW_RIGHT,Gtk::SHADOW_NONE);

$botao1->add($arrow1);
$botao2->add($arrow2);
$botao3->add($arrow3);
$botao4->add($arrow4);

$hbox->pack_start($botao1);
$hbox->pack_start($botao2);
$hbox->pack_start($botao3);
$hbox->pack_start($botao4);

$window->add($hbox);
$window->show_all();
Gtk::Main();
?>