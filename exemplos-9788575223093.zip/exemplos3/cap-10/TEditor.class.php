<?php
class TEditor extends GtkWindow
{
    private $editor;
    
    public function __construct()
    {
        parent::__construct();
        parent::set_position(Gtk::WIN_POS_CENTER);
        parent::connect_simple('delete_event', array($this, 'onDeleteEvent'));
        parent::set_size_request(700, 480);
        parent::set_title('Simple PHP Editor');
        
        $this->editor = new TSourceView;
        $this->editor->insertAtCursor("<?php \n\n?>");
        
        $scroll = new GtkScrolledWindow;
        $scroll->add($this->editor);
        
        $vbox = new GtkVBox;
        $ToolBar = new GtkHBox;
        $vbox->pack_start($ToolBar, FALSE, FALSE);
        $vbox->pack_start($scroll, TRUE, TRUE);
        
        $bt1 = GtkButton::new_from_stock(Gtk::STOCK_NEW);
        $bt2 = GtkButton::new_from_stock(Gtk::STOCK_OPEN);
        $bt3 = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
        $bt1->connect_simple('clicked', array($this, 'onNewFile'));
        $bt2->connect_simple('clicked', array($this, 'onOpenFile'));
        $bt3->connect_simple('clicked', array($this, 'onSaveFile'));
        $ToolBar->pack_start($bt1, FALSE, FALSE);
        $ToolBar->pack_start($bt2, FALSE, FALSE);
        $ToolBar->pack_start($bt3, FALSE, FALSE);

        parent::add($vbox);
        $this->clear();
    }

    /**
     * Limpa a �rea de edi��o e come�a novo arquivo
     */
    public function clear()
    {
        $this->editor->clearBuffer();
        $this->editor->insertAtCursor("<?php \n\n?>");
    }
    
    /**
     * Inicia novo arquivo
     */
    public function onNewFile()
    {
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_QUESTION,
                                  Gtk::BUTTONS_YES_NO, 'Deseja criar novo arquivo ?');
        $response = $dialog->run();
        $dialog->destroy();
        
        if ($response == Gtk::RESPONSE_YES)
        {
            $this->clear();
        }
    }
    
    /**
     * Dialogo para abrir arquivo
     */
    public function onOpenFile()
    {
        $dialog = new GtkFileChooserDialog('Selecione o arquivo', NULL,
              Gtk::FILE_CHOOSER_ACTION_OPEN,
              array(Gtk::STOCK_OPEN,   Gtk::RESPONSE_OK,
                    Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));
        
        $dialog->set_position(GTK::WIN_POS_CENTER);
        $dialog->set_default_response(GTK::RESPONSE_OK);
        
        $response = $dialog->run();
        $filename = $dialog->get_filename();
        
        // destr�i di�logo anterior
        $dialog->destroy();
        
        // Verifica resposta do usu�rio
        if ($response == Gtk::RESPONSE_OK)
        {
            $this->editor->loadFile($filename);
        }
    }
    
    /**
     * Carrega um arquivo
     */
    public function loadFile($filename)
    {
        $this->editor->clearBuffer();
        $this->editor->loadFile($filename);
    }
    
    /**
     * Salva o arquivo
     */
    public function onSaveFile()
    {
        $dialog = new GtkFileChooserDialog('Selecione o arquivo', NULL,
              Gtk::FILE_CHOOSER_ACTION_SAVE,
              array(Gtk::STOCK_SAVE,   Gtk::RESPONSE_OK,
                    Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));
        
        $dialog->set_position(GTK::WIN_POS_CENTER);
        $dialog->set_default_response(GTK::RESPONSE_OK);
        
        $response = $dialog->run();
    
        // Verifica resposta do usu�rio
        if ($response == Gtk::RESPONSE_OK)
        {
            $newfile = $dialog->get_filename();
            $content = $this->editor->getText();
            file_put_contents($newfile, $content);
        }
        $dialog->destroy(); //destr�i di�logo
        return FALSE;
    }
    
    /**
     * Executado ao fechar a janela
     */
    function onDeleteEvent()
    {
        parent::hide();
        return TRUE;
    }
}
?>