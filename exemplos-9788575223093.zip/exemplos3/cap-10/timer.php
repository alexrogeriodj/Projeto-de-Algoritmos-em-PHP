<?
function AtualizaClock()
{
    global $label;
    $label->set_markup('<b>'. date("h:i:s") . '</b>');
    
    Gtk::timeout_add(1000, 'AtualizaClock'); // a cada decimo de segundo
}

$janela = new GtkWindow;
$janela->set_position(GTK::WIN_POS_CENTER);
$janela->set_default_size(200,100);

$label = new GtkLabel;

$janela->add($label);

$janela->show_all();

Gtk::timeout_add(1, 'AtualizaClock');
Gtk::Main();
?>