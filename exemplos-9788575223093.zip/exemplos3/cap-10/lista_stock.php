<?php
class ExemploListaStock
{
    private $window;
    private $list;
    private $model;

    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Imagens de Estoque');
        $this->window->connect_simple('destroy', array('gtk', 'main_quit'));
        $this->window->set_default_size(240,240);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $scroll = new GtkScrolledWindow;
        $scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
        
        $this->list = new GtkTreeView;
        $scroll->add($this->list);
        
        $this->model = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING);
        $this->list->set_model($this->model);
        
        $column1 = new GtkTreeViewColumn('id');
        $column2 = new GtkTreeViewColumn('imagem');
        
        $cell_renderer1 = new GtkCellRendererText();
        $cell_renderer2 = new GtkCellRendererPixbuf();
        
        $column1->pack_start($cell_renderer1, true);
        $column2->pack_start($cell_renderer2, true);
        
        $cell_renderer1->set_property('width', 140);
        $cell_renderer2->set_property('width', -1);
        
        $column1->set_attributes($cell_renderer1, 'text',   0);
        $column2->set_attributes($cell_renderer2, 'stock-id', 1);
        
        $this->list->append_column($column1);
        $this->list->append_column($column2);
        
        $ids = Gtk::stock_list_ids();
        
        foreach ($ids as $id)
        {
            $iter = $this->model->append(array($id, $id));
        }
        
        $this->window->add($scroll);
        
        $this->window->show_all();
    }
}

new ExemploListaStock;
Gtk::Main();
?>