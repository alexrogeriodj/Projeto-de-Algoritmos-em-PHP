<?php
class ExemploComboBoxModel
{
    private $comboBox;
    
    public function __construct()
    {
        $window = new GtkWindow;
        $window->set_default_size(200,100);
        $window->set_border_width(20);
        $window->set_position(GTK::WIN_POS_CENTER);
        
        $vbox = new GtkVBox;
        $window->add($vbox);
        
        $model = new GtkListStore(GObject::TYPE_OBJECT, GObject::TYPE_STRING);
        
        $this->comboBox = new GtkComboBox;
        $this->comboBox->set_model($model);
        
        $cell_renderer1 = new GtkCellRendererPixbuf();
        $cell_renderer2 = new GtkCellRendererText();
        
        $this->comboBox->pack_start($cell_renderer1, false);
        $this->comboBox->pack_start($cell_renderer2, true);
        
        $this->comboBox->set_attributes($cell_renderer1, 'pixbuf', 0);
        $this->comboBox->set_attributes($cell_renderer2, 'text', 1);
        
        $items   = array();
        
        $items[] = array('icons/ico_pdf.png', 'Arquivo PDF');
        $items[] = array('icons/ico_php.png', 'Arquivo PHP');
        
        foreach ($items as $item)
        {
            $imagem = $item[0];
            $texto  = $item[1];
            
            $pixbuf = GdkPixbuf::new_from_file($imagem);
            
            $iter = $model->append(array($pixbuf, $texto));
        }
        
        $this->comboBox->set_active(0);
        $vbox->pack_start($this->comboBox, false, false);
        
        $button  = GtkButton::new_from_stock(Gtk::STOCK_DIALOG_QUESTION);
        $button->connect_simple('clicked', array($this, 'onClick'));
        $vbox->pack_start($button, false, false);
        
        $window->show_all();
    }
    
    public function onClick()
    {
        $iter  = $this->comboBox->get_active_iter();
        $model = $this->comboBox->get_model();
        
        $valor = $model->get_value($iter, 1);
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                             Gtk::BUTTONS_OK,
                                             "Voc� escolheu:\n$valor");
        $dialog->run();
        $dialog->destroy();
    }
}

new ExemploComboBoxModel;
Gtk::main();
?>