<?php 
/** 
 * Classe UmaJanela : Simula uma janela da aplicação 
 */ 
class UmaJanela extends GtkWindow 
{ 
    function __construct() 
    { 
        parent::__construct(); 
        parent::set_size_request(300,200); 
        parent::set_border_width(50); 
        parent::set_title('Uma Janela'); 
        parent::connect_simple('delete_event', array($this, 'onClick')); 
        
        $botao = new GtkButton('fechar uma janela'); 
        $botao->connect_simple('clicked', array($this, 'onClick')); 
        parent::add($botao); 
        parent::show_all(); 
    } 
    
    function onClick() 
    { 
        $this->hide(); 
        return true; 
    } 
} 
?>
