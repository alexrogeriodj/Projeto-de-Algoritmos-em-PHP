<?php
class TSourceView extends GtkSourceView
{
    private $originalEncoding;
    
    function __construct()
    {
        parent::__construct();
        
        $this->buffer = new GtkSourceBuffer;
        $this->set_buffer($this->buffer);
        
        $manager = new GtkSourceLanguagesManager;
        $lang = $manager->get_language_from_mime_type('application/x-php');
        
        $this->buffer->set_language($lang);
        $this->buffer->set_highlight(true);
        
        $this->tabWidth = 4;
        $this->set_auto_indent(TRUE);
        $this->set_insert_spaces_instead_of_tabs(TRUE);
        $this->set_tabs_width(4);
        $this->set_show_margin(FALSE);
        $this->set_show_line_numbers(true);
        $this->set_show_line_markers(true);
        $this->buffer->set_check_brackets(TRUE);
        $this->set_highlight_current_line(TRUE);
        $this->set_smart_home_end(TRUE);
        
        $font = (substr(strtoupper(PHP_OS),0,3)=='WIN') ? 'Courier 10' : 'Monospace 10';
        $pango = new PangoFontDescription($font);
        $this->modify_font($pango);
        
    }
    
    /**
     * Insere um texto no buffer
     */
    function insertAtCursor($text)
    {
        $this->buffer->insert_at_cursor($text);
    }
    
    /**
     * Carrega um arquivo
     */
    public function loadFile($file)
    {
        $content = file_get_contents($file);

        if (utf8_encode(utf8_decode($content)) == $content )
        {
            $content = utf8_decode($content);
            $this->originalEncoding = 'UTF';
        }
        $this->buffer->insert_at_cursor($content);
        return TRUE;
    }
    
    /**
     * Obt�m o conte�do
     */
    function getText($forceISO = FALSE)
    {
        $first = $this->buffer->get_start_iter();
        $end   = $this->buffer->get_end_iter();
        
        $content = @$this->buffer->get_text ($first, $end);
        if ($this->originalEncoding == 'UTF')
        {
            $content = utf8_encode($content);
        }
        return $content;
    }
    
    /**
     * Limpa o buffer
     */
    function clearBuffer()
    {
        $first = $this->buffer->get_start_iter();
        $end   = $this->buffer->get_end_iter();
        return $this->buffer->delete ($first, $end);
    }
}
?>