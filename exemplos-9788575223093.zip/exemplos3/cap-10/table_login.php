<?
class TableLogin
{
    private $window;
    function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_position(Gtk::WIN_POS_CENTER);
        $tabela = new GtkTable(3,2,true);
        
        $vbox = new GtkVBox;
        
        $rotulo1 = new GtkLabel('Usuario');
        $this->usuario = new GtkEntry;
        
        $tabela->attach($rotulo1, 0,1,0,1);
        $tabela->attach($this->usuario, 1,2,0,1);
        
        $rotulo2 = new GtkLabel('Senha');
        $this->senha   = new GtkEntry;
        $this->senha->set_visibility(false); 
        $tabela->attach($rotulo2, 0,1,1,2);
        $tabela->attach($this->senha, 1,2,1,2);
        
        $this->botao_login  = GtkButton::new_from_stock(Gtk::STOCK_OK);
        $this->botao_cancel = GtkButton::new_from_stock(Gtk::STOCK_CANCEL);
        
        $tabela->attach($this->botao_login, 0,1,2,3);
        $tabela->attach($this->botao_cancel, 1,2,2,3);
        
        $this->botao_login->connect_simple('clicked', array($this, 'onLogin'));
        $this->botao_cancel->connect_simple('clicked', array('Gtk', 'main_quit'));
        
        $this->window->add($tabela);
        
        $this->window->show_all();
	}
    
    function onLogin()
    {
        $user = $this->usuario->get_text();
        $pass = $this->senha->get_text();
        
        if (($user == 'maria') and ($pass == 'abacaxi'))
        {
            $this->window->hide();
            
            new Application;
        }
    }
}

class Application
{
    private $window;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_default_size(600,400);
        $this->window->set_border_width(80);
        $this->window->set_title('Aplica��o');
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $button = new GtkLabel('Inicializando Aplica��o...');
        $this->window->add($button);
        
        $this->window->show_all();
    }
}

$login = new TableLogin;
Gtk::main();
?>
