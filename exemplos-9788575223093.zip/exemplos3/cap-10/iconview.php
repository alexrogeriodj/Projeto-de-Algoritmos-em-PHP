<?php 
// cria a janela 
$janela = new GtkWindow(); 
$janela->set_title('GtkIconView'); 
$janela->set_default_size(500, 300); 
$janela->connect_simple('destroy', array('Gtk', 'main_quit')); 

// cria a iconview e o modelo 
$iconview = new GtkIconView(); 
$model = new GtkListStore(GdkPixbuf::gtype, GObject::TYPE_STRING); 
$iconview->set_model($model); 

// cria janela de rolagem 
$scroll = new GtkScrolledWindow(); 
$scroll->set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC); 
$scroll->add($iconview); 

// adiciona a janela de rolagem na janela principal 
$janela->add($scroll); 

// conecta o botão de selecionar item 
$iconview->connect('item-activated', 'onSelect', $model); 

// renderiza um ícone de estoque 
$a = new GtkButton; 
$icone = $a->render_icon(Gtk::STOCK_OPEN, Gtk::ICON_SIZE_BUTTON); 

// lê o diretório /usr/include 
foreach (new DirectoryIterator('/usr/include') as $arquivo) 
{ 
    // adiciona elemento no modelo 
    $model->append(array($icone, $arquivo)); 
} 

// define quais colunas do modelo serão exibidas 
$iconview->set_pixbuf_column(0); 
$iconview->set_text_column(1); 

// largura de cada coluna 
$iconview->set_item_width(100); 

// exibe a janela 
$janela->show_all(); 
Gtk::main(); 

/** 
 * Executada quando usuário dispara duplo-clique sobre elemento 
 * @param $iconview Objeto GtkIconView 
 * @param $path Caminho para o objeto selecionado 
 * @param $model objeto GtkListStore 
 */ 
function onSelect($iconview, $path, $model) 
{ 
    $i = $model->get_iter($path); 
    var_dump($model->get_value($i, 1)); 
} 
?>
