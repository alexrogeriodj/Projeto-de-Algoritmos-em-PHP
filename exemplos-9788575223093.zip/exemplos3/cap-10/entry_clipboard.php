<?php
function onCopy($entry)
{
    $entry->select_region(0,-1);
    $entry->copy_clipboard();
}

function onPaste($entry)
{
    $entry->set_text('');
    $entry->paste_clipboard();
}

$window = new GtkWindow;
$window->set_default_size(140,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('�rea de transfer�ncia');
$window->set_border_width(20);

$vbox = new GtkVBox;

$entry1= new GtkEntry;
$entry2= new GtkEntry;

$button1 = GtkButton::new_from_stock(Gtk::STOCK_COPY);
$button2 = GtkButton::new_from_stock(Gtk::STOCK_PASTE);

$button1->connect_simple('clicked', 'onCopy',  $entry1);
$button2->connect_simple('clicked', 'onPaste', $entry2);

$hbox1 = new GtkHBox;
$hbox2 = new GtkHBox;

$hbox1->pack_start($button1);
$hbox1->pack_start($entry1);

$hbox2->pack_start($button2);
$hbox2->pack_start($entry2);

$vbox->pack_start($hbox1);
$vbox->pack_start($hbox2);

$window->add($vbox);
$window->show_all();
Gtk::main();
?>