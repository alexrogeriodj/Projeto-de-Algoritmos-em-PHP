<?php
/**
 * classe ClienteService
 * Classe para manipular o cadastro de Clientes
 */
class ClienteService
{
    /**
     * m�todo salvar()
     * recebe um objeto com dados de cliente e armazena no banco de dados
     */
    function salvar($objeto)
    {
        try
        {
            $conn = new PDO('sqlite:dados.db');
            $conn->exec("INSERT INTO pessoas (codigo, nome, endereco," .
                        "                     idade, telefone, cidade)" .
                        "  VALUES ('{$objeto->codigo}',   '{$objeto->nome}',"  .
                        "          '{$objeto->endereco}', '{$objeto->idade}'," .
                        "          '{$objeto->telefone}', '{$objeto->cidade}')");
            unset($conn);
        }
        catch (Exception $e)
        {
            // retorna o erro na forma de um objeto SoapFault
            return new SoapFault("Server", $e->getMessage());
        }
    }
}
// instancia servidor SOAP
$server = new SoapServer(NULL, array('encoding' => 'ISO-8859-1', 'uri' => 'http://test-uri/'));
// define a classe que ir� responder �s chamadas remotas
$server->setClass('ClienteService');
// prepara-se para receber as chamadas remotas
$server->handle();
?>
