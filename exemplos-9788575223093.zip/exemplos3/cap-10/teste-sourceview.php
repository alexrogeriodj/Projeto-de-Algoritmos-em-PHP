<?php
$janela = new GtkWindow;
$scroll = new GtkScrolledWindow;
$sourceview = new GtkSourceView;

$janela->set_size_request(700, 400);
$janela->set_position(Gtk::WIN_POS_CENTER);
$janela->add($scroll);
$scroll->add($sourceview);

$buffer = new GtkSourceBuffer;
$sourceview->set_buffer($buffer);

$manager = new GtkSourceLanguagesManager;
$lang = $manager->get_language_from_mime_type('application/x-php');

$buffer->set_language($lang);
$buffer->set_highlight(true);
$buffer->set_check_brackets(TRUE);

$sourceview->set_auto_indent(TRUE);
$sourceview->set_insert_spaces_instead_of_tabs(TRUE);
$sourceview->set_tabs_width(4);
$sourceview->set_show_line_numbers(true);
$sourceview->set_highlight_current_line(TRUE);

$font = (substr(strtoupper(PHP_OS),0,3)=='WIN') ? 'Courier 10' : 'Monospace 10';
$pango = new PangoFontDescription($font);
$sourceview->modify_font($pango);

$buffer->insert_at_cursor("<?php\n\n?>");

$janela->show_all();
Gtk::main();
?>