<?php 
/** 
 * Classe OutraJanela : Simula uma janela da aplicação 
 */ 
class OutraJanela extends GtkWindow 
{ 
    function __construct() 
    { 
        parent::__construct(); 
        parent::set_size_request(300,200); 
        parent::set_border_width(50); 
        parent::set_title('Outra Janela'); 
        parent::connect_simple('delete_event', array($this, 'onClick')); 
        
        $botao = new GtkButton('fechar outra janela'); 
        $botao->connect_simple('clicked', array($this, 'onClick')); 
        parent::add($botao); 
        parent::show_all(); 
    } 
    
    function onClick() 
    { 
        $this->hide(); 
        return true; 
    } 
} 
?>
