<?php
$window = new GtkWindow;
$window->move(200,200);
$window->set_default_size(200,200);
$window->set_title('Cores');
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_border_width(80);

$vermelho = new GdkColor(65535,0,0);
$window->modify_bg(Gtk::STATE_NORMAL, $vermelho);

$amarelo = GdkColor::parse('#FFFF00');
$branco  = GdkColor::parse('#FFFFFF');
$cinza   = GdkColor::parse('#C0C0C0');

$botao1 = new GtkButton('amarelo');

$botao1->modify_bg(Gtk::STATE_NORMAL,   $cinza);
$botao1->modify_bg(Gtk::STATE_PRELIGHT, $branco);
$botao1->modify_bg(Gtk::STATE_ACTIVE,   $amarelo);

$window->add($botao1);
$window->show_all();
Gtk::main();
?>