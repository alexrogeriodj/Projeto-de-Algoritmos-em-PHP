<?php
class ExemploDrawingArea
{
    private $width  = 495; // largura da �rea de desenho
    private $height = 341; // altura da �rea de desenho
    private $gdkwindow;
    
    function __construct()
    {
        $window = new GtkWindow;
        $window->set_title('Drawing');
        $window->set_default_size($this->width+10, $this->height+40);
        $window->set_position(GTK::WIN_POS_CENTER);
        $window->realize();
        
        $vbox = new GtkVBox;
        
        $this->drawing = new GtkDrawingArea;
        $this->drawing->add_events(GDK::POINTER_MOTION_MASK);
        $this->drawing->set_size_request($this->width, $this->height);
        
        $this->statusbar = new GtkStatusbar;
        
        $vbox->pack_start($this->drawing);
        $vbox->pack_start($this->statusbar);
        
        $window->add($vbox);
        
        $this->drawing->realize();
        $this->gdkwindow = $this->drawing->window;
        
        $window->show_all();
        
        $this->drawing->connect_simple('event', array($this, 'onEvent'));
        
        $this->drawing->connect_simple('expose-event', array($this, 'onDraw'));
    }

    function onClear()
    {
        $colormap = GdkColorMap::get_system();
        
        $branco = new GdkGC($this->gdkwindow);
        $preto  = new GdkGC($this->gdkwindow);
        
        $branco->set_foreground($colormap->alloc_color('white'));
        $preto->set_foreground($colormap->alloc_color('black'));
        
        $this->gdkwindow->draw_rectangle($branco, true, 4, 4, $this->width -1, $this->height -1);
        $this->gdkwindow->draw_rectangle($preto, false, 4, 4, $this->width -1, $this->height -1);
    }

    function onEvent()
    {
        $pointer = $this->gdkwindow->get_pointer();
        
        $x = $pointer[0];
        $y = $pointer[1];
        
        $this->statusbar->push(1, "X: $x, Y: $y");
    }
    
    function onDraw()
    {
        $this->onClear();
        
        $colormap = GdkColorMap::get_system();
        
        $vermelho = new GdkGC($this->gdkwindow);
        $verde    = new GdkGC($this->gdkwindow);
        $amarelo  = new GdkGC($this->gdkwindow);
        $preto    = new GdkGC($this->gdkwindow);
        
        $vermelho->set_foreground($colormap->alloc_color('#FF0000'));
        $verde->set_foreground($colormap->alloc_color('#00FF00'));
        $amarelo->set_foreground($colormap->alloc_color('#FFFF00'));
        $preto->set_foreground($colormap->alloc_color('#000000'));
        
        $preto->set_line_attributes(2, Gdk::LINE_SOLID, Gdk::CAP_NOT_LAST, Gdk::JOIN_MITER);
        
        $this->gdkwindow->draw_rectangle($vermelho, true, 50, 50, 320, 100);
        
        $this->gdkwindow->draw_arc($verde, true, 170, 200, 300, 80, 0, 23040);
        
        $this->gdkwindow->draw_line($preto, 70, 300, 400, 80);
        
        $image = GdkPixbuf::new_from_file('icons/ico_gimp.png');
        
        $this->gdkwindow->draw_pixbuf($vermelho, $image, 0, 0, 80, 140, -1, -1);
        
        $layout = $this->drawing->create_pango_layout("Esse PHP5, turbinado\ncom GTK2 � bom mesmo !");
        
        $desc = new PangoFontDescription('Arial Bold 14');
        
        $layout->set_font_description($desc);
        
        $this->gdkwindow->draw_layout($amarelo, 70, 70, $layout);
    }
}

new ExemploDrawingArea;
Gtk::main();
?>