<?php
$window = new GtkWindow;
$window->set_default_size(180,100);
$window->set_position(GTK::WIN_POS_CENTER);
$window->set_title('Sensitive');

$label = new GtkLabel('Texto qualquer...');
$entry = new GtkEntry('Caixa de texto');
$button= new GtkButton('Exemplo de bot�o');

$label->set_sensitive(false);
$entry->set_sensitive(false);
$button->set_sensitive(false);

$vbox = new GtkVBox;

$vbox->pack_start($label);
$vbox->pack_start($entry);
$vbox->pack_start($button);

$window->add($vbox);

$window->show_all();
Gtk::main();
?>