<?php 
include_once 'UmaJanela.class.php'; 
include_once 'OutraJanela.class.php'; 

/** 
 * classe Aplicação 
 * Interface principal da aplicação 
 */ 
class Aplicacao extends GtkWindow 
{ 
    private $janela_filha1; 
    private $janela_filha2; 

    function __construct() 
    { 
        parent::__construct(); 
        parent::set_size_request(400,300); 
        parent::set_border_width(100); 
        parent::connect_simple('destroy', array('Gtk', 'main_quit')); 
        
        $vbox = new GtkVBox; 
        
        $botao = new GtkButton('abrir uma janela'); 
        $botao->connect_simple('clicked', array($this, 'onClick1')); 
        
        $botao2 = new GtkButton('abrir outra janela'); 
        $botao2->connect_simple('clicked', array($this, 'onClick2')); 
        
        $vbox->add($botao); 
        $vbox->add($botao2); 
        parent::add($vbox); 
        parent::show_all(); 
    } 

    function onClick1() 
    { 
        if (empty($this->janela_filha1)) 
        { 
            $this->janela_filha1 = new UmaJanela; 
        } 
        $this->janela_filha1->show_all(); 
    } 

    function onClick2() 
    { 
        if (empty($this->janela_filha2)) 
        { 
            $this->janela_filha2 = new OutraJanela; 
        } 
        $this->janela_filha2->show_all(); 
    } 
} 

new Aplicacao; 
Gtk::Main(); 
?>
