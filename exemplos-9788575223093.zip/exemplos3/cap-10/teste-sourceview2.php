<?php
include_once 'TSourceView.class.php';
include_once 'TEditor.class.php';

$janela = new TEditor;
$janela->show_all();

Gtk::Main();
?>