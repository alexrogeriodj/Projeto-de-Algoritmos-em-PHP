<?php
/*
 * Classe Pessoa
 * Encapsula o acesso � dados
 */
class Pessoa
{
    static $conn; // propriedade est�tica, link para conex�o
    
    /**
     * M�todo conecta :: Conecta ao Banco de Dados
     */
    function conecta()
    {
        // armazena link para conex�o
        self::$conn = new PDO('sqlite:dados.db');
    }
    
    /**
     * M�todo desconecta :: Desconecta do Banco de Dados
     */
    function desconecta()
    {
        self::$conn = null;
    }
    
    /**
     * M�todo criaBanco :: Cria tabela no banco de dados
     */
    function criaBanco()
    {
        // executa comando para criar tabela de pessoas
        self::$conn->query('CREATE TABLE pessoas (codigo, '.
                          '  nome, endereco, idade, telefone, cidade)');
    }

    /**
     * M�todo getPessoa :: Retorna objeto pessoa, passando o c�digo
     */
    function getPessoa($id)
    {
        // executa consulta ao banco, pelo c�digo da pessoa
        $result = self::$conn->query("SELECT codigo, nome, endereco, ".
                                     "       idade, telefone, cidade ".
                                     "  FROM pessoas where codigo = '$id' limit 1");
        // retorna os dados em forma de objeto
        $objeto = $result->fetchObject();
        return $objeto;
    }

    /**
     * M�todo savePessoa :: Grava o objeto pessoa no Banco de dados
     */
    function savePessoa(StdClass $objeto)
    {
        // verifica se a pessoa j� est� cadastrada
        if (self::getPessoa($objeto->codigo))
        {
            // se pessoa j� cadastrada, efetua uma altera��o
            self::$conn->exec("UPDATE pessoas SET ".
                              " nome    ='{$objeto->nome}'," . 
                              " endereco='{$objeto->endereco}'," . 
                              " idade   ='{$objeto->idade}'," . 
                              " telefone='{$objeto->telefone}'," . 
                              " cidade  ='{$objeto->cidade}' " . 
                              " WHERE codigo = '{$objeto->codigo}'");
        }
        else
        {
            // se pessoa n�o cadastrada, efetua uma inser��o
            self::$conn->exec("INSERT INTO pessoas (codigo, nome, endereco," . 
                              "                     idade, telefone, cidade)" . 
                              "  VALUES ('{$objeto->codigo}',   '{$objeto->nome}',"  . 
                              "          '{$objeto->endereco}', '{$objeto->idade}'," .
                              "          '{$objeto->telefone}', '{$objeto->cidade}')");
        }
    }
    
    /**
     * M�todo deletePessoa :: Deleta o objeto pessoa no BD
     */
    function deletePessoa(StdClass $objeto)
    {
        // executa um DELETE, baseado no c�digo da pessoa
        $result = self::$conn->exec("DELETE from pessoas ".
                                    "  WHERE codigo = '$objeto->codigo'");
    }

    /**
     * M�todo getNext :: Retorna a pr�xima pessoa, passando o c�digo
     */
    function getNext($id)
    {
        // obt�m o pr�ximo registro, baseado no c�digo da pessoa
        $result = self::$conn->query("SELECT codigo, nome, endereco, idade," .
                                     "       telefone, cidade ".
                                     "  FROM pessoas where codigo > '$id'" .
                                     "  ORDER BY codigo LIMIT 1");
        // retorna os dados em forma de objeto
        $objeto = $result->fetchObject();
        return $objeto;
    }

    /**
     * M�todo getPrevious :: Retorna a pessoa anterior, passando o c�digo
     */
    function getPrevious($id)
    {
        // obt�m o registro anterior, baseado no c�digo da pessoa
        $result = self::$conn->query("SELECT codigo, nome, endereco, idade, ".
                                     "       telefone, cidade ".
                                     "  FROM pessoas where codigo < '$id'" . 
                                     "  ORDER BY codigo desc LIMIT 1");
        // retorna os dados em forma de objeto
        $objeto = $result->fetchObject();
        return $objeto;
    }

    /**
     * M�todo getFirst :: Retorna a primeira pessoa cadastrada
     */
    function getFirst()
    {
        // obt�m o menor c�digo da tabela de pessoas
        $result   = self::$conn->query("SELECT min(codigo) as codigo from pessoas");
        
        // retorna os dados em forma de objeto
        $objeto = $result->fetchObject();
        $primeiro = $objeto->codigo;
        
        // retorna o objeto correspondente ao c�digo obtido
        return Pessoa::getPessoa($primeiro);
    }

    /**
     * M�todo getLast :: Retorna a �ltima pessoa cadastrada
     */
    function getLast()
    {
        // obt�m o maior c�digo da tabela de pessoas
        $result   = self::$conn->query("SELECT max(codigo) as codigo from pessoas");
        
        // retorna os dados em forma de objeto
        $objeto = $result->fetchObject();
        $ultimo   = $objeto->codigo;
        
        // retorna o objeto correspondente ao c�digo obtido
        return Pessoa::getPessoa($ultimo);
    }

    /**
     * M�todo getPessoas :: Retorna todas pessoas cadastradas
     */
    function getPessoas()
    {
        // executa consulta retornando todas as pessoas do banco
        $result= self::$conn->query("SELECT codigo, nome, endereco, ".
                                    "       idade, telefone, cidade ".
                                    "  FROM pessoas" . 
                                    "  ORDER BY codigo");
        // percorre o resultado
        while ($objeto = $result->fetchObject())
        {
            // acumula os objetos retornandos em um array
            $objetos[] = $objeto;
        }
        return $objetos;
    }
}
?>