<?php
class Application
{
    private $window;
    private $form;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Cadastro');
        $this->window->connect_simple('destroy', array('gtk', 'main_quit'));
        $this->window->set_default_size(540,320);
        $this->window->set_border_width(10);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $vbox = new GtkVBox;
        
        $linha    = new GtkHBox();
        $button1  = GtkButton::new_from_stock(Gtk::STOCK_NEW);
        $button2  = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
        $button3  = GtkButton::new_from_stock(Gtk::STOCK_DELETE);
        $button4  = GtkButton::new_from_stock(Gtk::STOCK_INDEX);
        $button5  = GtkButton::new_from_stock(Gtk::STOCK_PRINT);
        $button6  = GtkButton::new_from_stock(Gtk::STOCK_CLOSE);
        $vbox->pack_start($linha, false, false);
        
        $button1->connect_simple('clicked', array($this, 'onNovo'));
        $button2->connect_simple('clicked', array($this, 'onSalvar'));
        $button3->connect_simple('clicked', array($this, 'onDelete'));
        $button4->connect_simple('clicked', array($this, 'onLista'));
        $button5->connect_simple('clicked', array($this, 'onImprime'));
        $button6->connect_simple('clicked', array('Gtk', 'main_quit'));
        
        $linha    = new GtkHBox;
        $linha->pack_start($button1, false, false);
        $linha->pack_start($button2, false, false);
        $linha->pack_start($button3, false, false);
        $linha->pack_start($button4, false, false);
        $linha->pack_start($button5, false, false);
        $linha->pack_start($button6, false, false);
        $vbox->pack_start($linha, false, false);
        
        $cidades  = GtkComboBox::new_text();
        $cidades->insert_text(0, 'Porto Alegre');
        $cidades->insert_text(1, 'S�o Paulo');
        $cidades->insert_text(2, 'Rio de Janeiro');
        $cidades->insert_text(3, 'Belo Horizonte');
        
        $this->form = new TForm;
        $this->form->addField('codigo',  'C�digo',         new GtkEntry,     80);
        $this->form->addField('nome',    'Nome da Pessoa', new GtkEntry,     240);
        $this->form->addField('idade',   'Idade',          GtkSpinButton::new_with_range(1,140,1), 48);
        
        $this->form->addSeparator('Contato');
        $this->form->addField('endereco','Endereco',       new GtkEntry,     240);
        $this->form->addField('telefone','Telefone',       new GtkEntry,     140);
        $this->form->addField('cidade',  'Cidade',         $cidades,         240);
        
        $this->form->Show();
        $vbox->pack_start($this->form, true, true);
        
        $linha    = new GtkHBox;
        $button1  = GtkButton::new_from_stock(Gtk::STOCK_GOTO_FIRST);
        $button2  = GtkButton::new_from_stock(Gtk::STOCK_GO_BACK);
        $button3  = GtkButton::new_from_stock(Gtk::STOCK_GO_FORWARD);
        $button4  = GtkButton::new_from_stock(Gtk::STOCK_GOTO_LAST);
        
        $button1->connect_simple('clicked', array($this, 'onPrimeiro'));
        $button2->connect_simple('clicked', array($this, 'onAnterior'));
        $button3->connect_simple('clicked', array($this, 'onProximo'));
        $button4->connect_simple('clicked', array($this, 'onUltimo'));
        
        $linha->pack_start(new GtkHBox, true);
        $linha->pack_start($button1, false, false);
        $linha->pack_start($button2, false, false);
        $linha->pack_start($button3, false, false);
        $linha->pack_start($button4, false, false);
        $linha->pack_start(new GtkHBox, true);
        $vbox->pack_start($linha, false, false);
        
        Pessoa::conecta();
        
        Pessoa::criaBanco();
        
        $this->onPrimeiro();
        $this->window->add($vbox);
    }

    public function onNovo()
    {
        $this->form->Clear();
        $this->window->set_focus($this->form->getField('codigo'));
    }

    public function onSalvar()
    {
        $objeto = $this->form->getData();
        Pessoa::savePessoa($objeto);
    }

    public function onDelete()
    {
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_QUESTION,
                                       Gtk::BUTTONS_YES_NO,
                                       'Deseja apagar o registro ?');
        
        $response = $dialog->run();
        if ($response == Gtk::RESPONSE_YES)
        {
            $objeto = $this->form->getData();
            Pessoa::deletePessoa($objeto);
        }
        $dialog->destroy();
    }

    public function onLista()
    {
        $window = new GtkWindow;
        $window->set_size_request(400,300);
        $window->set_position(GTK::WIN_POS_CENTER);
        $scroll = new GtkScrolledWindow;
        $window->add($scroll);
        
        $list = new TDataList;
        $list->connect_simple('row-activated', array($this, 'onSelect'), $list, $window);
        
        $list->addColumn('C�digo', 'text');
        $list->addColumn('Nome', 'text');
        
        $list->createModel();
        
        $objetos = Pessoa::getPessoas();
        
        foreach ($objetos as $objeto)
        {
            $list->addItem(array($objeto->codigo, $objeto->nome));
        }
        
        $scroll->add($list);
        $window->show_all();
    }
    
    public function onSelect($list, $window)
    {
        $selected = $list->getSelected();
        $codigo = $selected[0];
        
        $objeto = Pessoa::getPessoa($codigo);
        if ($objeto)
        {
            $this->form->setData($objeto);
        }
        $window->hide();
    }
    
    public function onPrimeiro()
    {
        $objeto = Pessoa::getFirst();
        if ($objeto)
        {
            $this->form->setData($objeto);
        }
    }

    public function onUltimo()
    {
        $objeto = Pessoa::getLast();
        if ($objeto)
        {
            $this->form->setData($objeto);
        }
    }

    public function onProximo()
    {
        $dados = $this->form->getData();
        $objeto = Pessoa::getNext($dados->codigo);
        if ($objeto)
        {
            $this->form->setData($objeto);
        }
    }
    
    public function onAnterior()
    {
        $dados = $this->form->getData();
        $objeto = Pessoa::getPrevious($dados->codigo);
        if ($objeto)
        {
            $this->form->setData($objeto);
        }
    }

    public function onImprime()
    {
        $buffer  = "Cadastro de Clientes\n";
        $buffer .= str_repeat('=', 64)     . "\n";
        $buffer .= str_pad('C�digo',   7)  . 
                   str_pad('Nome',     24) . 
                   str_pad('Endere�o', 24) . 
                   str_pad('Telefone', 10) . "\n";
        $buffer .= str_repeat('=', 64) . "\n";
        
        $objetos = Pessoa::getPessoas();
        foreach ($objetos as $objeto)
        {
            $buffer .= str_pad($objeto->codigo,   7)  . 
                       str_pad($objeto->nome,     24) . 
                       str_pad($objeto->endereco, 24) . 
                       str_pad($objeto->telefone, 10) ."\n";
        }
        
        $editor = new TEditor;
        $editor->carregaTexto($buffer);
    }

    public function __destruct()
    {
        Pessoa::desconecta();
    }
    
    public function Show()
    {
        $this->window->show_all();
    }
}

include_once 'Pessoa.class.php';
include_once 'TForm.class.php';
include_once 'TEditor.class.php';
include_once 'TDataList.class.php';

$app = new Application;
$app->Show();
Gtk::Main();
?>
