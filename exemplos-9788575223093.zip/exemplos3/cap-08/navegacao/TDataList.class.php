<?
/*
 * Classe TDataList
 * Classe criada para
 * exibir listagens de dados
 */
class TDataList extends GtkTreeView
{
    var $titles;        // cont�m os t�tulos das colunas
    var $columns;       // quantidade de colunas
    var $types;         // cont�m os tipos de dados suportados
    var $columnTypes;   // cont�m os tipos de dados das coluns
    
    /*
     * M�todo construtor
     * Constr�i a gtkTreeView
     * inicializa alguns vetores
     */
    function __construct()
    {
        $this->types = array();
        $this->titles = array();
        $this->renderers = array();
        $this->columnTypes = array();
        $this->columns = 0;
        
        $this->types['pixbuf'] = GObject::TYPE_OBJECT;
        $this->types['text']   = GObject::TYPE_STRING;
        
        parent::__construct();
        
        // cria o modelo de dados
        $this->model = new GtkListStore;
        
        // define o tamanho da listagem
        parent::set_size_request(200,-1);
    }

    /*
     * M�todo addColumn
     * Adiciona uma coluna ao modelo de dados
     * $title  = t�tulo da coluna
     * $render = tipo de renderizador
     */
    function addColumn($title, $render)
    {
        // armazena o tipo de coluna
        $this->columnTypes[] = $this->types[$render];
        
        // cria a coluna
        $column = new GtkTreeViewColumn();
        $column->set_title($title);
        
        // cria o renderizador para a coluna
        $classe = "GtkCellRenderer{$render}";
        $cell_renderer = new $classe();
        
        // adiciona o renderizador � coluna
        $column->pack_start($cell_renderer, true);
        
        // define qual coluna do modelo ir� ser exibida neste renderizador
        $column->add_attribute($cell_renderer, $render, $this->columns);
        
        // incrementa o n�mero de colunas
        $this->columns ++;
        parent::append_column($column);
    }

    /*
     * M�todo createModel
     * Cria o Modelo de dados.
     * deve ser criado ap�s adicionarmos todas colunas
     */
    function createModel()
    {
        // define os tipos das colunas do modelo
        $this->model->set_column_types($this->columnTypes);
        
        // atribui o modelo de dados � TreeView
        parent::set_model($this->model);
    }
    
    /*
     * M�todo addItem
     * Adiciona uma linha na lista
     */
    function addItem($items)
    {
        $indice = 0;
        // adiciona uma linha no modelo de dados
        $iter = $this->model->append();
        
        // percorre a linha adicionada
        foreach ($items as $item)
        {
            // verifica o tipo de dado (se imagem ou texto)
            if ($this->columnTypes[$indice] == GObject::TYPE_OBJECT)
            {
                $cell = GdkPixbuf::new_from_file($item);
            }
            else if ($this->columnTypes[$indice] == GObject::TYPE_STRING)
            {
                $cell = $item;
            }
            
            // atribui a c�lula de dados � linha do modelo
            $this->model->set($iter, $indice, $cell);
            $indice ++;
        }
    }

    /*
     * M�todo getSelected
     * Retorna o elemento selecionado
     */
    function getSelected()
    {
        // obt�m a sele��o atual da lista
        $treeselection = parent::get_selection();
        list($model, $iter) = $treeselection->get_selected();
        
        $selected = array();
        // verifica se h� elemento realmente selecionado
        if ($iter instanceof GtkTreeIter)
        {
            $indice = 0;
            // percorre cada uma das colunas
            foreach ($this->columnTypes as $type)
            {
                // armazena o elemento selecionado atrav�s do get_value
                $selected[] = $model->get_value($iter, $indice);
                $indice ++;
            }
            return $selected;
        }
    }

    /*
     * M�todo setSelected
     * Altera o elemento selecionado
     */
    function setSelected($values)
    {
        // obt�m a sele��o atual da lista
        $treeselection = parent::get_selection();
        list($model, $iter) = $treeselection->get_selected();
        
        // verifica se h� elemento realmente selecionado
        if ($iter instanceof GtkTreeIter)
        {
            $indice = 0;
            // percorre cada uma das colunas
            foreach ($values as $value)
            {
                // altera o elemento selecionado no modelo atrav�s do set()
                $model->set($iter, $indice, $value);
                $indice ++;
            }
        }
    }

    /*
     * M�todo delSelected
     * Elimina o elemento selecionado
     */
    function delSelected()
    {
        // obt�m a sele��o atual da lista
        $treeselection = parent::get_selection();
        list($model, $iter) = $treeselection->get_selected();
        
        // verifica se h� elemento realmente selecionado
        if ($iter instanceof GtkTreeIter)
        {
            // remove o elemento selecionado do modelo
            $model->remove($iter);
        }
    }
    
    /*
     * M�todo getItems
     * retorna matriz com todos itens da listagem
     */
    function getItems()
    {
        // obt�m a primeira linha (iter)
        $iter = $this->model->get_iter_first();
        // obt�m a qtde total de colunas do modelo
        $columns = $this->model->get_n_columns();
        
        $i = 0;
        // enquanto houver linhas...
        while ($iter)
        {
            // percorre as colunas
            for ($n=0; $n<= $columns -1; $n++)
            {
                // monta matriz de dados atrav�s do get_value()
                $data[$i][$n]= $this->model->get_value($iter, $n);
            }
            // retorna a pr�xima linha (iter)
            $iter = $this->model->iter_next($iter);
            $i++;
        }
        // retorna a matriz
        return $data;
    }
    
    /*
     * M�todo Clear
     * Limpa a lista
     */
    function Clear()
    {
        $this->model->clear();
    }
}
?>