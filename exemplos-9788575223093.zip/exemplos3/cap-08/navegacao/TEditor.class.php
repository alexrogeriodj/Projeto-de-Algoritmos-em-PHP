<?php
/*
 * classe TEditor
 * Cria um editor de textos simples
 */
class TEditor extends GtkWindow
{
    private $textview;   // objeto para visualiza��o do texto
    private $textbuffer; // objeto para armazenamento do texto
    
    /*
     * M�todo construtor
     * Cria a janela, a barra de ferramentas
     * o TextView/Buffer e define a��o dos bot�es
     */
    function __construct()
    {
        // cria janela
        parent::__construct();
        parent::set_size_request(400,400);
        parent::set_position(GTK::WIN_POS_CENTER);
        parent::set_title('Editor de Textos');
        
        // cria caixa vertical
        $vbox = new GtkVBox;
        
        // cria barra de ferramentas
        $toolbar = new GtkToolbar;
        
        // cria os bot�es da barra de ferramentas
        $new  = GtkToolButton::new_from_stock(GTK::STOCK_NEW);
        $save = GtkToolButton::new_from_stock(GTK::STOCK_SAVE);
        $open = GtkToolButton::new_from_stock(GTK::STOCK_OPEN);
        $font = GtkToolButton::new_from_stock(GTK::STOCK_SELECT_FONT);
        
        // define a a��o dos bot�es
        $new->connect_simple('clicked', array($this, 'onNewFile'));
        $save->connect_simple('clicked', array($this, 'onSaveFile'));
        $open->connect_simple('clicked', array($this, 'onOpenFile'));
        $font->connect_simple('clicked', array($this, 'onSelectFont'));
        
        // adiciona bot�es � toolbar
        $toolbar->insert($new,  -1);
        $toolbar->insert($open, -1);
        $toolbar->insert($save, -1);
        $toolbar->insert($font, -1);
        
        // adiciona barra de ferramentas � caixa vertical
        $vbox->pack_start($toolbar, false, false);
        
        // cria uma janela de rolagem
        $scroll = new GtkScrolledWindow;
        
        // cria TextView e TextBuffer
        $this->textview   = new GtkTextView;
        $this->textbuffer = new GtkTextBuffer;
        
        // define a fonte inicial do texto
        $pango = new PangoFontDescription('Courier 10');
        $this->textview->modify_font($pango);
        
        // atribui o TextBuffer ao TextView
        $this->textview->set_buffer($this->textbuffer);
        
        // adiciona o TextView � janela de rolagem
        $scroll->add($this->textview);
        
        // adiciona a janela de rolagem � caixa vertical
        $vbox->pack_start($scroll, true, true);
        
        // adiciona a caixa vertical � janela
        parent::add($vbox);
        parent::show_all();
    }

    /*
     * fun��o onNewFile
     * Limpa �rea de edi��o do arquivo (TextBuffer)
     */
    public function onNewFile()
    {
        // obt�m limites do texto (iters)
        $first = $this->textbuffer->get_start_iter();
        $end   = $this->textbuffer->get_end_iter();
        
        // deleta conte�do
        $this->textbuffer->delete($first, $end);
        parent::set_title('');
    }
    
    /*
     * fun��o onOpenFile
     * Abre o di�logo de abrir arquivo e coloca
     * o conte�do do arquivo no TextBuffer
     */
    public function onOpenFile()
    {
        // Cria o di�logo de abertura de arquivos.
        $dialog = new GtkFileChooserDialog('Opening the file', NULL,
                      Gtk::FILE_CHOOSER_ACTION_OPEN,
                      array(Gtk::STOCK_OK,     Gtk::RESPONSE_OK,
                            Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));
                            
        // Exibe o di�logo
        $response = $dialog->run();
        
        // Verifica a respota da a��o do usu�rio
        if ($response == Gtk::RESPONSE_OK)
        {
            // obt�m conte�do do arquivo
            $conteudo = file_get_contents($dialog->get_filename());
            
            // insere o conte�do no buffer de texto
            $this->carregaTexto($conteudo);
            // altera o t�tulo da janela para o nome do arquivo aberto
            parent::set_title($dialog->get_filename());
        }
        
        $dialog->destroy();
    }
    
    /*
     * fun��o carregaTexto
     * Substitui o texto do bufer pelo novo
     */
    public function carregaTexto($texto)
    {
        // limpa o buffer de texto
        $first = $this->textbuffer->get_start_iter();
        $end   = $this->textbuffer->get_end_iter();
        $this->textbuffer->delete($first, $end);
        
        // Insere o conte�do dentro do buffer de texto
        $this->textbuffer->insert_at_cursor($texto);
    }

    /*
     * fun��o onSaveFile
     * Exibe o di�logo de salvar arquivos
     * e escreve o conte�do do buffer de texto em um arquivo
     */
    public function onSaveFile()
    {
        // Cria o di�logo de salvar arquivo.
        $dialog = new GtkFileChooserDialog('Saving the file', NULL,
                      Gtk::FILE_CHOOSER_ACTION_SAVE,
                      array(Gtk::STOCK_OK,     Gtk::RESPONSE_OK,
                            Gtk::STOCK_CANCEL, Gtk::RESPONSE_CANCEL));
                            
        // exibe o di�logo
        $response = $dialog->run();
        
        // Verifica a respota da a��o do usu�rio
        if ($response == Gtk::RESPONSE_OK)  // if the user has clicked OK
        {
            // Obt�m o conte�do do buffer de texto
            $first = $this->textbuffer->get_start_iter();
            $end   = $this->textbuffer->get_end_iter();
            $text  = $this->textbuffer->get_text($first, $end);
            
            // Escreve o conte�do do buffer no arquivo
            file_put_contents($dialog->get_filename(), $text);
            // altera o t�tulo da janela para o nome escolhido
            parent::set_title($dialog->get_filename());
        }
        
        // fecha o di�logo
        $dialog->destroy();
    }
    
    /*
     * fun��o onSelectFont
     * Abre di�logo de sele��o de fonte
     * utilizando a fonte escolhida para exibir o texto
     */
    function onSelectFont()
    {
        // cria di�logo de sele��o de fonte
        $dialog = new GtkFontSelectionDialog('Selecione a Fonte');
        $response = $dialog->run();
        
        // Verifica resposta do usu�rio
        if ($response == Gtk::RESPONSE_OK)
        {
            // obt�m a fonte selecionada
            $font = $dialog->fontsel->get_font_name();
            
            // aplica a fonte selecionada no texto
            $pango = new PangoFontDescription($font);
            $this->textview->modify_font($pango);
        }
        // fecha di�logo
        $dialog->destroy();
    }
}
?>