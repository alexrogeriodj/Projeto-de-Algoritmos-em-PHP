<?php
class NovaPessoa
{
    private $window;
    private $campos;
    private $labels;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Incluir');
        $this->window->connect_simple('destroy', array($this->window, 'hide'));
        $this->window->set_default_size(540,280);
        $this->window->set_border_width(10);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $vbox = new GtkVBox;
        
        $this->labels['codigo'] = new GtkLabel('<span foreground="red"><b> C�digo: </b></span>');
        $this->campos['codigo'] = new GtkEntry;
        $this->campos['codigo']->set_size_request(80,-1);
        
        $this->labels['nome'] = new GtkLabel('Nome: ');
        $this->campos['nome'] = new GtkEntry;
        $this->campos['nome']->set_size_request(240,-1);
        
        $this->labels['endereco'] = new GtkLabel('Endere�o: ');
        $this->campos['endereco'] = new GtkEntry;
        $this->campos['endereco']->set_size_request(240,-1);
        
        $this->labels['idade'] = new GtkLabel('Idade: ');
        $this->campos['idade'] = GtkSpinButton::new_with_range(1,140,1); // de 1 � 140 com saltos de 1
        $this->campos['idade']->set_size_request(48,-1);
        
        $this->labels['fone'] = new GtkLabel('Telefone: ');
        $this->campos['fone'] = new GtkEntry;
        $this->campos['fone']->set_size_request(140,-1);
        
        $this->labels['cidade'] = new GtkLabel('Cidade: ');
        $this->campos['cidade'] = GtkComboBox::new_text();
        $this->campos['cidade']->set_size_request(240,-1);
        
        $this->campos['cidade']->insert_text(0, 'Porto Alegre');
        $this->campos['cidade']->insert_text(1, 'S�o Paulo');
        $this->campos['cidade']->insert_text(2, 'Rio de Janeiro');
        $this->campos['cidade']->insert_text(3, 'Belo Horizonte');
        
        foreach ($this->campos as $chave => $objeto)
        {
            $hbox = new GtkHBox;
            $hbox->pack_start($this->labels[$chave], false, false);
            $hbox->pack_start($this->campos[$chave], false, false);
            
            $this->labels[$chave]->set_size_request(200,-1);
            $this->labels[$chave]->set_alignment(1, 0.5); // xAlign, yalign (0.5, 1)
            $this->labels[$chave]->set_use_markup(true);
            
            $vbox->pack_start($hbox, false, false);
        }
        $vbox->pack_start(new GtkHSeparator, true, true);
        
        $buttonbox= new GtkHButtonBox;
        $buttonbox->set_layout(Gtk::BUTTONBOX_START);
        
        $botao = GtkButton::new_from_stock(Gtk::STOCK_SAVE);
        $botao->connect_simple('clicked', array($this, 'onSaveClick'));
        $buttonbox->pack_start($botao, false, false);
        
        $botao = GtkButton::new_from_stock(Gtk::STOCK_CLOSE);
        $botao->connect_simple('clicked', array($this->window, 'hide'));
        $buttonbox->pack_start($botao, false, false);
        
        $vbox->pack_start($buttonbox, false, false);
        
        $this->criaBanco();
        
        $this->window->add($vbox);
    }

    public function criaBanco()
    {
        $sql = 'CREATE TABLE pessoas (codigo, ' .
               '  nome, endereco, idade, telefone, cidade)';
        
        if (!file_exists('dados.db'))
        {
            $conn = sqlite_open('dados.db');
            sqlite_query($conn, $sql);
            sqlite_close($conn);
        }
    }
    
    public function onSaveClick()
    {
        $pessoa->codigo   = $this->campos['codigo']->get_text();
        $pessoa->nome     = $this->campos['nome']->get_text();
        $pessoa->endereco = $this->campos['endereco']->get_text();
        $pessoa->idade    = $this->campos['idade']->get_text();
        $pessoa->telefone = $this->campos['fone']->get_text();
        $pessoa->cidade   = $this->campos['cidade']->get_active();
        
        $sql = "INSERT INTO pessoas (codigo, nome, endereco," . 
                                    "idade, telefone, cidade)" . 
                "  VALUES ('{$pessoa->codigo}',   '{$pessoa->nome}',"  . 
                "          '{$pessoa->endereco}', '{$pessoa->idade}'," .
                "          '{$pessoa->telefone}', '{$pessoa->cidade}')";
        
        $conn = sqlite_open('dados.db');
        sqlite_query($conn, $sql);
        sqlite_close($conn);
        
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_INFO,
                                        Gtk::BUTTONS_OK, 'Registro inserido com sucesso!');
        $dialog->run();
        $dialog->destroy();
        
        $this->Clear();
    }
    
    private function Clear()
    {
        $this->campos['codigo']->set_text('');
        $this->campos['nome']->set_text('');
        $this->campos['endereco']->set_text('');
        $this->campos['idade']->set_text('');
        $this->campos['fone']->set_text('');
        $this->campos['cidade']->set_active(-1);
        
        $this->window->set_focus($this->campos['codigo']);
    }
    
    public function Show()
    {
        $this->window->show_all();
    }
}
?>