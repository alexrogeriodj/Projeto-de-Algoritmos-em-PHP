<?php
class EditaPessoa
{
    private $window;
    private $model;
    
    public function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_title('Listar');
        $this->window->connect_simple('destroy', array($this->window, 'hide'));
        $this->window->set_default_size(540,280);
        $this->window->set_border_width(10);
        $this->window->set_position(GTK::WIN_POS_CENTER);
        
        $vbox = new GtkVBox;
        $this->window->add($vbox);
        
        $scroll = new GtkScrolledWindow;
        $vbox->pack_start($scroll);
        $scroll->set_policy(GTK::POLICY_AUTOMATIC, GTK::POLICY_ALWAYS);
        
        $this->list = new GtkTreeView;
        $scroll->add($this->list);
        
        $this->model = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING,
												GObject::TYPE_STRING, GObject::TYPE_STRING);
        $this->list->set_model($this->model);
        
        $column1 = new GtkTreeViewColumn('C�digo');
        $column2 = new GtkTreeViewColumn('Nome');
        $column3 = new GtkTreeViewColumn('Endere�o');
        $column4 = new GtkTreeViewColumn('Idade');
        $this->model->set_sort_column_id(0, Gtk::SORT_ASCENDING);        
        
        $column1->set_sort_column_id(0);
        $column2->set_sort_column_id(1);
        
        $cell_renderer1 = new GtkCellRendererText();
        $cell_renderer2 = new GtkCellRendererText();
        $cell_renderer3 = new GtkCellRendererText();
        $cell_renderer4 = new GtkCellRendererText();
        
        $cell_renderer2->connect("edited", array($this, 'onEdit'), 1, 'nome');
        $cell_renderer3->connect("edited", array($this, 'onEdit'), 2, 'endereco');
        $cell_renderer4->connect("edited", array($this, 'onEdit'), 3, 'idade');
        
        $cell_renderer2->set_property('editable', true);
        $cell_renderer3->set_property('editable', true);
        $cell_renderer4->set_property('editable', true);
        
        $column1->pack_start($cell_renderer1, true);
        $column2->pack_start($cell_renderer2, true);
        $column3->pack_start($cell_renderer3, true);
        $column4->pack_start($cell_renderer4, true);
        
        $cell_renderer1->set_property('width', 70);
        $cell_renderer2->set_property('width', 170);
        $cell_renderer3->set_property('width', 170);
        $cell_renderer4->set_property('width', -1);
        
        $column1->set_attributes($cell_renderer1, 'text', 0);
        $column2->set_attributes($cell_renderer2, 'text', 1);
        $column3->set_attributes($cell_renderer3, 'text', 2);
        $column4->set_attributes($cell_renderer4, 'text', 3);
        
        $this->list->append_column($column1);
        $this->list->append_column($column2);
        $this->list->append_column($column3);
        $this->list->append_column($column4);
        
        $buttonbox= new GtkHButtonBox;
        $buttonbox->set_layout(Gtk::BUTTONBOX_START);
        
        $botao = GtkButton::new_from_stock(Gtk::STOCK_DELETE);
        $botao->connect_simple('clicked', array($this, 'onDelete'));
        $buttonbox->pack_start($botao, false, false);
        
        $botao = GtkButton::new_from_stock(Gtk::STOCK_CLOSE);
        $botao->connect_simple('clicked', array($this->window, 'hide'));
        $buttonbox->pack_start($botao, false, false);
        
        $vbox->pack_start($buttonbox, false, false);
        $this->list->show_all();
    }
    
    public function Show()
    {
        $this->exibeDados();
        $this->window->show_all();
    }
    
    public function exibeDados()
    {
        $conn = sqlite_open('dados.db');
        
        $query = sqlite_query($conn, 'select codigo, nome, endereco, idade '.
                                     ' from pessoas');
        
        while ($dados = sqlite_fetch_array($query))
        {
            $iter = $this->model->append();
            $this->model->set($iter, 0, $dados['codigo'],
                                     1, $dados['nome'],
                                     2, $dados['endereco'],
                                     3, $dados['idade']);
        }
        sqlite_close($conn);
    }
    
    public function onEdit($cell_renderer, $path, $new_text, $column_number, $column_name)
    {
        $treeselection = $this->list->get_selection();
        list($model, $iter) = $treeselection->get_selected();
        
        $model->set($iter, $column_number, $new_text);
        
        $code = $this->model->get_value($iter, 0);
        
        $conn  = sqlite_open('dados.db');
        $query = sqlite_query($conn, "update pessoas set $column_name='$new_text' where codigo='$code'");
        sqlite_close($conn);
    }

    public function onDelete()
    {
        $dialog = new GtkMessageDialog(null, Gtk::DIALOG_MODAL, Gtk::MESSAGE_QUESTION,
                                       Gtk::BUTTONS_YES_NO, 'Deseja continuar ?');
        
        $response = $dialog->run();
        $dialog->destroy();
        
        if ($response == Gtk::RESPONSE_YES)
        {
            $treeselection = $this->list->get_selection();
            list($model, $iter) = $treeselection->get_selected();
            
            if ($iter)
            {
                $code = $this->model->get_value($iter, 0);
                
                $this->model->remove($iter);
                
                $conn  = sqlite_open('dados.db');
                $query = sqlite_query($conn, "delete from pessoas where codigo='$code'");
                sqlite_close($conn);
            }
        }
    }
}
?>