<?php
include_once 'EditaPessoa.class.php';

$obj = new EditaPessoa;
$obj->Show();

Gtk::Main();
?>