<?php
include_once 'NovaPessoa.class.php';

$obj = new NovaPessoa;
$obj->Show();

Gtk::Main();
?>