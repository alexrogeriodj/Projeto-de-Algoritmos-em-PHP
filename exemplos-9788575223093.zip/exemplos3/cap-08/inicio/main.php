<?php
class Application
{
    private $window;
    
    function __construct()
    {
        $this->window = new GtkWindow;
        $this->window->set_size_request(400,200);
        $this->window->set_uposition(100,100);
        $this->window->set_title('Cadastro de Pessoas');
        
        $vbox = new GtkVBox;
        
        $menu['_Cadastros'][] = array('images/menu_abrir.png',  'Adicionar',  array($this, 'onAdicionar'));
        $menu['_Cadastros'][] = array('images/menu_salvar.png', 'Listar',     array($this, 'onListar'));
        $menu['_Cadastros'][] = array('',                       'Sair',       array('Gtk', 'main_quit'));
        
        $menu['_Ajuda'][] = array('images/menu_help.png',      'Sobre',       array($this, 'onSobre'));
        
        $MenuBar = new TMenu($menu);
        
        $this->window->add($vbox);
        $vbox->pack_start($MenuBar, false, false);
        
        $this->window->show_all();
    }
    
    function onAdicionar()
    {
        include_once 'NovaPessoa.class.php';
        $obj = new NovaPessoa;
        $obj->Show();
    }

    function onListar()
    {
        include_once 'EditaPessoa.class.php';
        $obj = new EditaPessoa;
        $obj->Show();
    }

    function onSobre()
    {
        $dialogo = new GtkAboutDialog;
        
        $dialogo->set_name('Pessoas');
        $dialogo->set_version('4.0');
        
        $dialogo->set_comments("Cadastro de Pessoas");
        $dialogo->set_copyright("Copyright (C) 2005-2006 Pablo Dall'Oglio");
        $dialogo->set_license("GPL\nEste aplicativo � um software livre\nVisite www.fsf.org.");
        $dialogo->set_logo(GdkPixbuf::new_from_file('pessoas.png'));
        $dialogo->set_website('http://www.pablo.blog.br');
        $dialogo->set_website_label('P�gina www');
        $dialogo->set_authors(array("Pablo Dall'Oglio"));
        
        $dialogo->run();
    }

    function onSair()
    {
        Gtk::main_quit();
    }
}

include_once 'TMenu.class.php';
new Application;
Gtk::Main();
?>
