<?php
# carrega a classe
require_once 'classes/Funcionario1.class.php';

$pedro = new Funcionario;
$pedro->Salario = 'Oitocentos e setenta e seis';
?>