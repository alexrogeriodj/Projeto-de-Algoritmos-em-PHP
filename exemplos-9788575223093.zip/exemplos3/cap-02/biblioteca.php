<?php
/**
 * fun��o quadrado
 * retorna o quadrado de um n�mero
 */
function quadrado($numero)
{
	   return $numero * $numero;
}
?>

