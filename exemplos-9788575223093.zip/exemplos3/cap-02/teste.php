<?php
//carreta arquivo com a função necessária
include 'biblioteca.php';

// imprime o quadado do número 4
echo quadrado(4);
?>