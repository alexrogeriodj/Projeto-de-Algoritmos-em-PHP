<?PHP
  
  $resultado = 5 + 4 - 3 / 2 * 1;
  echo($resultado .'<BR>');  // Resultado: 7.5
  
  $resultado = 5 % 4;
  $resultado++;
  echo($resultado .'<BR>');  // Resultado: 2
  
?>
