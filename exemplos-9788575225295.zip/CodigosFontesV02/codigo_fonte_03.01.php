<?PHP
 
  echo ('Ola mundo!');
  // Resultado: Ola mundo!
 
?>
