<?PHP
  
  $i = 0;
  
  while($i < 5)
  {
    echo($i .' '); // Resultado: 0 1 2 3 4 
    $i++;
  }
  
?>
