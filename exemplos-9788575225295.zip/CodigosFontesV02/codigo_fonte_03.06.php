<?PHP
  
  echo(substr('Brasil penta!', 2).'<BR>');
  // Resultado: asil penta!
  
  echo(substr('Brasil penta!', 2, 3).'<BR>');
  // Resultado: asi
  
  echo(substr('Brasil penta!', -2, 2).'<BR>');
  // Resultado: a!
  
?>
