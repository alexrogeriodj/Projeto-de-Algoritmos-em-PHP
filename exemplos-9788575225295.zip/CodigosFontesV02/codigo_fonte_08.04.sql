INSERT INTO TB_CARGOS VALUES(1, 'Analista de Neg�cios', 'Tecnologia da Informa��o');
INSERT INTO TB_CARGOS VALUES(2, 'Analista de Sistemas', 'Tecnologia da Informa��o');
INSERT INTO TB_CARGOS VALUES(3, 'Analista de BI', 'Tecnologia da Informa��o');
INSERT INTO TB_CARGOS VALUES(4, 'Administrador de Banco de Dados', 'Tecnologia da Informa��o');
INSERT INTO TB_CARGOS VALUES(5, 'Analista de Marketing', 'Marketing');
INSERT INTO TB_CARGOS VALUES(6, 'Programador', 'Tecnologia da Informa��o');
INSERT INTO TB_CARGOS VALUES(7, 'Contador', 'Contabilidade');
INSERT INTO TB_CARGOS VALUES(8, 'Administrador', 'Contabilidade');
INSERT INTO TB_CARGOS VALUES(9, 'Designer', 'Marketing');
