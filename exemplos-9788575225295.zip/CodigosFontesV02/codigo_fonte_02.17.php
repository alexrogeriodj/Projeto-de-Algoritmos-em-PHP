<?PHP
  
  for($i = 0; $i < 10; $i++) 
  {
    if($i == 4) 
    {
      break;
    }
      
    echo($i .' '); // Resultado: 0 1 2 3 
  }
  
?>
