<?PHP
  
  echo($_SERVER['SERVER_ADDR'].'<BR>');          
  // Resultado: 189.21.161.32, endere�o do IP do servidor
  
  echo($_SERVER['SERVER_NAME'].'<BR>');          
  // Resultado: nome_do_dominio.com.br do servidor
  
  echo($_SERVER['HTTP_ACCEPT_ENCODING'].'<BR>'); 
  // Resultado: gzip, deflate
  
?>
