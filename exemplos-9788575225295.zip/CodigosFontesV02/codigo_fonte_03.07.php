<?PHP
  
  echo(str_replace('penta', 'hexa', 'Brasil penta').'<BR>');
  // Resultado: Brasil hexa
  
  echo(str_replace('USUARIO', 'Andre', 'Bem vindo USUARIO ao site!').'<BR>');
  // Resultado: Bem vindo Andre ao site!
  
?>
