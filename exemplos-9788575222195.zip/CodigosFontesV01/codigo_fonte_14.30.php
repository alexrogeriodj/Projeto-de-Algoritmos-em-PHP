<?PHP
 
  echo "Seu IP �: ".$_SERVER["REMOTE_ADDR"]." e poder� ser armazenado em ".
       "nossos bancos de dados";
  
?>
