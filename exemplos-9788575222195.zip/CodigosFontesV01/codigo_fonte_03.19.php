<?PHP
  
  $valor = 12.34;
  $valorInt = (int)$valor;
  echo "ValorInt: ".$valorInt;
  // Resultado: 12
  
?>
