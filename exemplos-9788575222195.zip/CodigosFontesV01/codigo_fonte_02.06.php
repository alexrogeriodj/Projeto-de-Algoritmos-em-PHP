<?PHP
 
  $minhaVar = "Texto";
  echo($minhaVar."<BR>");  // Resultado: Texto
  
  $minhaVar = TRUE;
  echo($minhaVar."<BR>");  // Resultado: 1
  
  $minhaVar = FALSE;
  echo($minhaVar."<BR>");  // Resultado: <vazio>
 
  $minhaVar = 5.22;
  echo($minhaVar."<BR>");  // Resultado: 5.22
  
?>
