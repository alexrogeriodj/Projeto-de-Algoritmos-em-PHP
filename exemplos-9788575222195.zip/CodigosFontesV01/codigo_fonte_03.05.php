<?PHP
  
  echo(strchr('Brasil Pentacampeao', 'a').'<BR>');
  // Resultado: asil Pentacampeao
  
  echo(strrchr('Brasil Pentacampeao', 'a').'<BR>');
  // Resultado: ao
  
  echo(strchr('Brasil Pentacampeao', 'y').'<BR>');
  // Resultado: 
  
?>
