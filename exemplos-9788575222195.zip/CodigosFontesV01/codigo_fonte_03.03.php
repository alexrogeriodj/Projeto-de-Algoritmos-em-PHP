<?PHP
 
  $tamanho = strlen('Brasil');
 
  echo ($tamanho.'<BR>');
  // Resultado: 6
 
  echo (strlen('').'<BR>');
  // Resultado: 0
 
?>
