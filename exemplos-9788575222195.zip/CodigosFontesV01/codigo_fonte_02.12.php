<?PHP
  
  $i = 1;
  
  switch($i) 
  {
    case 0:
        echo ('O valor de i � 0');
        break;
    case 1:
        echo ('O valor de i � 1');
        break;
    case 2:
        echo ('O valor de i � 2');
        break;
  }
  
?>
