find . -name "*~" -exec rm "{}" ";"
