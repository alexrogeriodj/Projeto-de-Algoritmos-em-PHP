# Configura��o do PHP 5.2.4
./configure \
	--prefix=/usr/local/php \
	--with-apxs2=/usr/local/httpd/bin/apxs \
	--with-mysql=/usr/local/mysql \
	--with-mysqli=/usr/local/mysql/bin/mysql_config \
	--enable-soap \
