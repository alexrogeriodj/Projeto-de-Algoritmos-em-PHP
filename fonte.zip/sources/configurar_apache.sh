# Configura��o do Apache 2.2.6
./configure \
	--prefix=/usr/local/httpd \
	--enable-so \
