CREATE TABLE `cidades` (
	`codigo` int(10) unsigned NOT NULL auto_increment,
	`nome` varchar(50) NOT NULL default '',
	`populacao` bigint(20) unsigned NOT NULL default '0',
	PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
