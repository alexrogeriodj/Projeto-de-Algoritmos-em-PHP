insert into cidades(nome, populacao) values
	('S�o Paulo', 10000000),
	('Joinville', 500000),
	('Rio de Janeiro', 5000000),
	('Curitiba', 2500000),
	('Blumenau', 300000);
