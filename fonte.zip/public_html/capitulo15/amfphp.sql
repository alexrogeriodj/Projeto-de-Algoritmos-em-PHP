CREATE USER 'amfphp'@'localhost' IDENTIFIED BY 'amfphp';
CREATE DATABASE `amfphp`;
GRANT ALL PRIVILEGES ON `amfphp`.* TO 'amfphp'@'localhost';
