<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
//declarando uma interface
interface ImprimeAlgo {
	public function imprime();
}
//a classe abstrata MinhaClasseAbstrata implementa ImprimeAlgo
//por�m n�o precisa fazer isso no corpo de sua defini��o
//deixando isso para classes que estenderem dela
abstract class MinhaClasseAbstrata implements ImprimeAlgo {

	//deixando para as classes concretas implementarem esses m�todos
	public abstract function getValor();
	public abstract function prefixo($valor);

	public function mostrandoValor() {
		print $this->getValor() . "\n";
	}
}
//aqui � implementado o m�todo da interface ImprimeAlgo
class ClasseConcreta1 extends MinhaClasseAbstrata {
	public function getValor() {
		return "ClasseConcreta1\n";
	}

	public function prefixo($valor) {
		return "{$valor}ClasseConcreta1\n";
	}

	public function imprime() {
		echo "Imprimindo ClasseConcreta1\n";
	}
}
//aqui tamb�m � implementado o m�todo da interface ImprimeAlgo
class ClasseConcreta2 extends MinhaClasseAbstrata {
	public function getValor() {
		return "ClasseConcreta2\n";
	}

	public function prefixo($valor) {
		return "{$valor}ClasseConcreta2\n";
	}

	public function imprime() {
		echo "Imprimindo ClasseConcreta2\n";
	}
}

$classe1 = new ClasseConcreta1();
echo $classe1->getValor();
echo $classe1->prefixo('CLASSE1_') ."\n";
$classe1->imprime();

$classe2 = new ClasseConcreta2();
echo $classe2->getValor();
echo $classe2->prefixo('CLASSE2_') ."\n";
$classe2->imprime();

$abstrata = new MinhaClasseAbstrata();
?>
