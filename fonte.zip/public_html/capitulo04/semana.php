<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 

class Calendario {
    const NOME = "Classe Calendario";
}

class DiasDaSemana extends Calendario {
    const DOMINGO = "Domingo";
    const SEGUNDA_FEIRA = "Segunda-Feira";
    const TERCA_FEIRA = "Ter�a-Feira";
    const QUARTA_FEIRA = "Quarta-Feira";
    const QUINTA_FEIRA = "Quinta-Feira";
    const SEXTA_FEIRA = "Sexta-Feira";
    const SABADO = "S�bado";
    const NOME = "Classe DiasDaSemana";
        const TOTAL_DE_DIAS = 7;

    static $instancias = 0;

    private function __construct() {
        self::$instancias++;
    }

    public static function geraInstancia() {
        new self();
    }

    public static function imprimeConstantesNome() {
        return "A ".self::NOME." estende da ".parent::NOME; 
    }
}

for ($i = 0; $i < 10; $i++) {
    DiasDaSemana::geraInstancia();
}
echo "Total de objetos da classe DiasDaSemanda criados: ".DiasDaSemana::$instancias."\n";
echo "Hoje � ".DiasDaSemana::DOMINGO."\n";
echo "A semana tem um total de dias no valor de ".DiasDaSemana::TOTAL_DE_DIAS."\n";
echo DiasDaSemana::imprimeConstantesNome();
?>