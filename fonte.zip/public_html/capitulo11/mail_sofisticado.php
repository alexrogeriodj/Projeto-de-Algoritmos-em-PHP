<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require('class.phpmailer.php');
$mail = new PHPMailer();

$mail->Host = 'mail.servidor.com.br'; 
$mail->From = 'sistema@servidor.com.br';
$mail->Subject = 'Teste de envio - bulk e-mail';
$mail->AddAddress('destino@cliente.com.br');

//corpo da mensagem em HTML
$mail->isHTML(true);
$mail->Body = '<b>Texto em <i>HTML</i></b>.<br />Final da mensagem.';

//conte�do alternativo em texto plano
$mail->AltBody = "Texto plano.\nFinal da mensagem.";

//envio de anexos
$mail->AddAttachment('/home/docs/texto.doc', 'Documento_Final.doc');
$mail->AddAttachment('./listagem.txt', 'Lista de usuarios.txt');

//envio de anexos, a partir da passagem direto do seu conte�do
$lista = file('./lista_emails.txt');
$total = count($lista);
$conteudo = "Lista de e-mails - $total registros\n";
$conteudo .= implode("\n", $lista);
$conteudo .= "\nfim da lista";
$mail->AddStringAttachment($conteudo, 'lista.txt');

//Tenta enviar o e-mail e analisa resultado
if ($mail->Send()) {
	echo 'ok';
} else {
	echo 'erro: ' . $mail->ErrorInfo;
}

//limpar destinat�rios e arquivos anexos
$mail->ClearAllRecipients();
$mail->ClearAttachments();
?>
