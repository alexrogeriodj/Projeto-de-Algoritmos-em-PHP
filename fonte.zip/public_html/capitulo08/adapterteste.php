<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once("Produto.class.php");
require_once("Pedido.class.php");
require_once("PedidoLoja.class.php");
require_once("PedidoAdapter.class.php");
require_once("PedidoWeb.class.php");
require_once("PrePedido.class.php");
require_once("Venda.class.php");
require_once("FormaPagamento.class.php");

//criando os produtos
$produto = new Produto(1, 15.25);
$produto2 = new Produto(2, 10);
$produto3 = new Produto(3, 12.81);

//criando as formas
$formadin = new FormaPagamento("Dinheiro", 0);
$formacheque = new FormaPagamento("Cheque", 8.75);

//trabalhando o pr�-pedido
echo "<b>- Trabalhando Pr�-Pedido:</b> ";
echo "<br>";

$prepedido = new PrePedido();
$prepedido->adicionaProduto($produto);
$prepedido->adicionaProduto($produto2);
$prepedido->adicionaProduto($produto3);

echo "<br>Total pr�-pedido dos 3 Produtos: ". $prepedido->calculaTotal();

$prepedido->removeProduto($produto3->getCodigo());

echo "<br>Total pr�-pedido sem o produto 3: ". $prepedido->calculaTotal();

//trabalhando Pedido Loja
echo "<br>";
echo "<br><b>- Trabalhando Pedido Loja:</b> ";
echo "<br>";
$pedidoloja = new PedidoLoja($formacheque);
$pedidoloja->adicionaProduto($produto);
$pedidoloja->adicionaProduto($produto2);
$pedidoloja->adicionaProduto($produto3);

//indu��o de erro
try {
	$pedidoloja->calculaTotal();
} catch (Exception $e) {
	echo "<br>M�todo c�lcula total da classe PedidoLoja obsoleto.";
	echo "<br>Erro: " . $e->getMessage();
}

echo "<br>";

$pedidoloja->removeProduto($produto2->getCodigo());

echo "<br>Total bruto pedido loja sem o produto 2: ".$pedidoloja->calculaTotalBruto();

//trabalhando Pedido Web adaptado para as novas fun��es
echo "<br>";
echo "<br><b>- Trabalhando Pedido Web:</b>";
echo "<br>";

$pedidoweb = new PedidoWeb($formadin);
$pedidoweb->adicionaProduto($produto);
$pedidoweb->adicionaProduto($produto2);
$pedidoweb->adicionaProduto($produto3);

echo "<br>Total pedido web bruto: ".$pedidoweb->calculaTotalBruto();
echo "<br>Total pedido web l�quido: ".$pedidoweb->calculaTotalLiquido(1.06, 0);
echo "<br>Total pedido web final: ".$pedidoweb->calculaTotalFinal();

//agora a venda
echo "<br>";
echo "<br><b>- Trabalhando uma Venda com base em um Pedido Web:</b>";
echo "<br>";

$venda = new Venda($pedidoweb);

echo "<br>Total venda feita pelo pedido web valor bruto: ".$venda->calculaTotalBruto();
echo "<br>Total acr�scimos (+): ".$venda->getPedido()->getAcrescimo();
echo "<br>Total descontos  (-): ".$venda->getPedido()->getDesconto();
echo "<br>Total venda feita pelo pedido web valor l�quido: ".$venda->calculaTotalLiquido(0,0);
echo "<br>Total venda pedido web final: ".$venda->calculaTotalFinal();
echo "<br>Forma de pagamento utilizada na venda: ".$venda->getForma()->getDescricao();
echo "<br>Taxas da forma de pagamento utilizada na venda: ".$venda->getForma()->getTaxa();
echo "<br>";

//agora uma outra venda
echo "<br>";
echo "<br><b>- Trabalhando uma Venda com base em um Pedido Loja:</b>";
echo "<br>";

$venda = new Venda($pedidoloja);

echo "<br>Total venda feita pelo pedido web valor bruto: ".$venda->calculaTotalBruto();
echo "<br>Total acr�scimos (+): ".$venda->getPedido()->getAcrescimo();
echo "<br>Total descontos  (-): ".$venda->getPedido()->getDesconto();
echo "<br>Total venda feita pelo pedido web valor l�quido: ".$venda->calculaTotalLiquido(0,0);
echo "<br>Total venda pedido web final: ".$venda->calculaTotalFinal();
echo "<br>Forma de pagamento utilizada na venda: ".$venda->getForma()->getDescricao();
echo "<br>Taxas da forma de pagamento utilizada na venda: ".$venda->getForma()->getTaxa();
echo "<br>";

?>