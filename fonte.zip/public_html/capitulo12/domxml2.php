<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
class ManipulaDOM {
	const XML_VERSAO = '1.0';
	const XML_CARACTER_SET_ISO = 'ISO-8859-1';
	private $dom;
	private $arquivoXML;

	public function __construct($arquivo, $versaoXML, $caracterSet) {
		if (!file_exists($arquivo)) {
			$ponteiro = fopen($arquivo, 'w+');
			fclose($ponteiro);
		}
		$this->dom = new DOMDocument($versaoXML, $caracterSet);

		//se o arquivo n�o tem conte�do silenciamos o aviso de warning via @
		@$this->dom->load($arquivo);
		$this->arquivoXML = $arquivo;
	}

	public function imprimeEstruturaXML($elementos) {
		$elementosXML = $elementos->childNodes;
		foreach ($elementosXML as $valor) {
			if ($valor->nodeType == XML_TEXT_NODE) {
				if (strlen(trim($valor->nodeValue))) {
					echo trim($valor->nodeValue).'<br>';
				} 
			} else if ($valor->nodeType == XML_ELEMENT_NODE) {
				$this->imprimeEstruturaXML($valor);
			}
		}
	}

	public function criaElementoComAtributo($tagPrincipal, $tagAtributo, $valor) {
		$elemento = null;
		$elemento = $this->getDOM()->createElement($tagPrincipal);
		$elemento->setAttribute($tagAtributo, $valor);
		return $elemento;
	}

	public function criaElemento($tag) {
		$elemento = null;
		$elemento = $this->getDOM()->createElement($tag);
		return $elemento;
	}

	public function adicionaValorAoAtributo($valor, $atributo) {
		$valorObjeto = $this->getDOM()->createTextNode($valor);
		$atributo->appendChild($valorObjeto);
	}

	public function adicionaAtributoAoElemento($atributo, $elemento) {
		$elemento->appendChild($atributo);
	}

	public function adicionaElementoAoDocumento($elemento) {
		$this->getDOM()->appendChild($elemento);
	}

	public function salvarDocumento() {
		$this->getDOM()->save($this->getArquivoXML());
	}

	public function getDOM(){
		return $this->dom;
	}

	public function getArquivoXML() {
		return $this->arquivoXML;
	}
}

$manipulaDOM = new ManipulaDOM('catalogoextra.xml', ManipulaDOM::XML_VERSAO, ManipulaDOM::XML_CARACTER_SET_ISO);

$elementoCatalogo = $manipulaDOM->criaElemento('catalogo');
$manipulaDOM->adicionaElementoAoDocumento($elementoCatalogo);

$elementoProduto = $manipulaDOM->criaElementoComAtributo('produto', 'codigo', '1700');
$manipulaDOM->adicionaAtributoAoElemento($elementoProduto, $elementoCatalogo);

$elementoDescricao = $manipulaDOM->criaElemento('descricao');
$manipulaDOM->adicionaValorAoAtributo('Kaiser Chiefs -	Yours Truly Angry Mob', $elementoDescricao);
$manipulaDOM->adicionaAtributoAoElemento($elementoDescricao, $elementoProduto);

$elementoPreco = $manipulaDOM->criaElemento('preco');
$manipulaDOM->adicionaValorAoAtributo('23.30', $elementoPreco);
$manipulaDOM->adicionaAtributoAoElemento($elementoPreco, $elementoProduto);

$elementoTipo = $manipulaDOM->criaElemento('tipo');
$manipulaDOM->adicionaValorAoAtributo('CD', $elementoTipo);
$manipulaDOM->adicionaAtributoAoElemento($elementoTipo, $elementoProduto);

$manipulaDOM->salvarDocumento();
$manipulaDOM->imprimeEstruturaXML($manipulaDOM->getDOM()->documentElement);
?>