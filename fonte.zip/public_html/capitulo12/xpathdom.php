<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
//executa a consulta desejada e mostra o resultado
function realizaConsulta($titulo, $consulta) {
	global $dom;

	$xpath = new DOMXPath($dom);
	$resultado = $xpath->query($consulta);

	echo "<font color=\"blue\">$titulo</font><br>";
	echo "<b>Crit�rio pesquisa: $consulta</b><br>";

	foreach($resultado as $valor) {
		if ($valor instanceof DomNode)
			echo htmlentities($dom->saveXML($valor));
		else
			print_r($valor);
		echo '<br>';
	}
	echo '<br>';
}

$xml = <<<XML
<frota>
	<carro>
		<modelo>Palio</modelo>
		<fabricante>Fiat</fabricante>
		<ano>2001</ano>
	</carro>
	<carro>
		<modelo>Troller</modelo>
		<fabricante>Ford</fabricante>
		<ano>2003</ano>
	</carro>
	<carro>
		<modelo>Celta</modelo>
		<fabricante>Chevrolet</fabricante>
		<ano>2007</ano>
	</carro>
</frota>
XML;

$dom = new DomDocument();
$dom->loadXML($xml);

//todas as consultas s�o baseadas em elementos constantes na defini��o da xml
realizaConsulta('Procurando modelos com base no caminho.', '/frota/carro/modelo');
realizaConsulta('Usando // retorna todos os elementos incluindo o mesmo.', '//carro');
realizaConsulta('Os elementos desse n�vel e abaixo s�o retornados com * .', '//frota/carro/*');
realizaConsulta('Retorna o carro pelo �ndice.', '//frota/carro[2]');
realizaConsulta('Retorna o �ltimo carro da frota.', '//frota/carro[last()]');
realizaConsulta('Consultando por atributo.', '//frota/carro[modelo = "Troller"]');
realizaConsulta('Combinando v�rios atributos com o | de operador.', '//modelo | //ano');
realizaConsulta('Verificando via contains se existe o valor.', '//carro[contains(modelo,"li")]');
?>