<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
$xml = <<<xml_noticia
<?xml version="1.0" encoding="ISO-8859-1" ?>
<noticias>
	<noticia>
		<titulo>Bovespa Dispara</titulo>
		<texto>O Bovespa registrou recorde de investimentos nesse ano de 2007.</texto>
		<assunto>Economia</assunto>
	</noticia>
</noticias>	
xml_noticia;

$xmlObjeto = new SimpleXMLElement($xml);

$noticia = $xmlObjeto->addChild('noticia');
$noticia->addChild('titulo','Economia cresce');
$noticia->addChild('texto','A economia do Brasil vai crescer acima dos 4% em 2007.');
$noticia->addChild('assunto','Economia');

$noticia = $xmlObjeto->addChild('noticia');
$noticia->addChild('titulo', 'JEC na Arena');
$noticia->addChild('texto', 'JEC inicia no Campeonato Catarinense com jogo na Arena Joinville.');
$noticia->addChild('assunto', 'Esporte');

$valores = array();
foreach ($xmlObjeto->children() as $elemento) {
	if ($elemento instanceof SimpleXMLElement) {
		$valores = get_object_vars($elemento);
		foreach ($valores as $tag => $valor) {
			echo '<b>'.ucfirst($tag).':</b> '.$valor.'<br>';
		}
		echo '<br>';
	}
}

$ponteiro = fopen('noticias.xml', 'w+');
fwrite($ponteiro, $xmlObjeto->asXML());
fclose($ponteiro);
?>