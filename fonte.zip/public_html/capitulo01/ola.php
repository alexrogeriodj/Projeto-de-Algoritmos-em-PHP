<html>
	<head>
		<title> 
		Testando o PHP
		<title> 
	</head>
	<body>
		<?php
			echo '<b>Al� Mundo. Seja bem-vindo ao PHP.</b>';
		?>
	</body>
</html>