<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once ('classes/Loader.class.php');
require_once ('includes/retornasmarty.inc.php');
require_once ('includes/confconexao.inc.php');
require_once ('includes/retornaconexao.inc.php');
session_start();

function operacao(UsuarioHelper $usuhelper, DAOBanco $banco) {
	$codigo = 0;
	$operacao = "";
	if (isset($_POST['edtoperacao'])) {
		$operacao = $_POST['edtoperacao'];
	}
	else {
		$operacao = isset($_GET['operacao']) ? $_GET['operacao'] : $_POST['operacao'];
	}
	if (isset($_POST['edtcodigo'])) {
		$codigo = $_POST['edtcodigo'];
	}
	else {
		$codigo = isset($_GET['codigo']) ? $_GET['codigo'] : $_POST['codigo'];
	}
	$salvar = isset($_GET['btnsalvar']) ? $_GET['btnsalvar'] : $_POST['btnsalvar'];
	$resultados = array();
	$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_IGUAL, array("cod_usuario" => $codigo));
	if (strcasecmp($operacao, Constantes::EDITAR) == 0 && !is_null($salvar)) {
		try {
			if (validarLoginSenha($usuhelper, $banco, $_POST['edtlogin'], $_POST['edtsenha'])) {
				$mensagem = "login ou senha j� cadastrado favor alterar";
				mostraTemplate(array() , $mensagem, $codigo, $operacao);
			}
			else {
				try {
					$camposValores = populaCampos();
					$usuhelper->alterar($banco, $camposValores, $filtro);
					$mensagem = "Registro: " . $codigo . " alterado com sucesso";
				}
				catch (Exception $e) {
					$mensagem = "N�o foi poss�vel alterar o registro: " . $codigo . ". Erro: " . $e->getMessage();
				}
				try {
					$resultados = $usuhelper->consultar($banco, null, $filtro);
				}
				catch (Exception $e) {
					$mensagem = "N�o foi poss�vel consultar o registro alterado" . ". Erro: " . $e->getMessage();
				}
				mostraTemplate($resultados, $mensagem, $codigo, $operacao);
			}
		}
		catch (Exception $e) {
			mostraTemplate(array() , $e->getMessage() , $codigo, $operacao);
		}
	}
	else if (strcasecmp($operacao, Constantes::INSERIR) == 0 && !is_null($salvar)) {
		try {
			if (validarLoginSenha($usuhelper, $banco, $_POST['edtlogin'], $_POST['edtsenha'])) {
				$mensagem = "login ou senha j� cadastrado favor alterar";
				mostraTemplate(array() , $mensagem, $codigo, $operacao);
			}
			else {
				try {
					$camposValores = populaCampos();
					$usuhelper->incluir($banco, $camposValores);
					$mensagem = "Registro inclu�do com sucesso";
				}
				catch (Exception $e) {
					$mensagem = "N�o foi poss�vel incluir o registro" . ". Erro: " . $e->getMessage();
				}
				mostraTemplate(array() , $mensagem, $codigo, $operacao);
			}
		}
		catch (Exception $e) {
			mostraTemplate(array() , $e->getMessage() , $codigo, $operacao);
		}
	}
	else if (strcasecmp($operacao, Constantes::EDITAR) == 0) {
		try {
			$mensagem = null;
			$resultados = $usuhelper->consultar($banco, null, $filtro);
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel consultar o registro" . ". Erro: " . $e->getMessage();
		}
		mostraTemplate($resultados, $mensagem, $codigo, $operacao);
	}
	else {
		mostraTemplate(array() , null, $codigo, $operacao);
	}
}

function validarLoginSenha(UsuarioHelper $usuhelper, DAOBanco $banco, $login, $senha) {
	try {
		 return $usuhelper->validarLoginSenha($banco, $login, $senha);
	}
	catch (Exception $e) {
		 throw new Exception($e->getMessage());
	}
}

function populaCampos() {
	$camposValores = array();
	$camposValores['nome'] = $_POST['edtnome'];
	$camposValores['email'] = $_POST['edtemail'];
	$camposValores['login'] = $_POST['edtlogin'];
	$camposValores['senha'] = $_POST['edtsenha'];
	return $camposValores;
}

function mostraTemplate($resultados, $mensagem = null, $codigo = null, $operacao = null) {
	$nome = "";
	$email = "";
	$login = "";
	$senha = "";
	if (count($resultados) > 0) {
		foreach ($resultados as $usuario) {
			$nome = $usuario->getNome();
			$email = $usuario->getEmail();
			$login = $usuario->getLogin();
			$senha = $usuario->getSenha();
		}
	}
	else {
		if (!is_null($operacao)) {
			$nome = $_POST['edtnome'];
			$email = $_POST['edtemail'];
			$login = $_POST['edtlogin'];
			$senha = $_POST['edtsenha'];
		}
	}
	$smarty = retornaSmarty();
	$smarty->assign("mensagem", $mensagem);
	$smarty->assign("nome", $nome);
	$smarty->assign("email", $email);
	$smarty->assign("login", $login);
	$smarty->assign("senha", $senha);
	$smarty->assign("codigo", $codigo);
	$smarty->assign("operacao", $operacao);
	$smarty->display("cadusuarios.tpl");
}
if (isset($_SESSION[Constantes::OBJETO_USUARIO])) {
	$banco = $_SESSION[BANCO_SESSAO];
	$usuhelper = new UsuarioHelper();
	operacao($usuhelper, $banco);
}
else {
	header("location:login.php");
}
?>