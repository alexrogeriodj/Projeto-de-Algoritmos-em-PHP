<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once ('classes/Loader.class.php');
require_once ('includes/retornasmarty.inc.php');
require_once ('includes/confconexao.inc.php');
require_once ('includes/retornaconexao.inc.php');
session_start();

function operacao(NoticiaHelper $nothelper, DAOBanco $banco) {
	$codigo = 0;
	$operacao = "";
	if (isset($_POST['edtoperacao'])) {
		$operacao = $_POST['edtoperacao'];
	}
	else {
		$operacao = isset($_GET['operacao']) ? $_GET['operacao'] : $_POST['operacao'];
	}
	if (isset($_POST['edtcodigo'])) {
		$codigo = $_POST['edtcodigo'];
	}
	else {
		$codigo = isset($_GET['codigo']) ? $_GET['codigo'] : $_POST['codigo'];
	}
	$salvar = isset($_GET['btnsalvar']) ? $_GET['btnsalvar'] : $_POST['btnsalvar'];
	date_default_timezone_set("America/Sao_Paulo");
	$resultados = array();
	$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_IGUAL, array("cod_noticia" => $codigo));
	if (strcasecmp($operacao, Constantes::EDITAR) == 0 && !is_null($salvar)) {
		try {
			$camposValores = populaCampos();
			$nothelper->alterar($banco, $camposValores, $filtro);
			$mensagem = "Registro: " . $codigo . " alterado com sucesso";
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel alterar o registro: " . $codigo . ". Erro: " . $e->getMessage();
		}
		try {
			$resultados = $nothelper->consultar($banco, null, $filtro);
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel consultar o registro alterado" . ". Erro: " . $e->getMessage();
		}
		mostraTemplate($banco, $resultados, $mensagem, $codigo, $operacao);
	}
	else if (strcasecmp($operacao, Constantes::INSERIR) == 0 && !is_null($salvar)) {
		try {
			$camposValores = populaCampos();
			$nothelper->incluir($banco, $camposValores);
			$mensagem = "Registro inclu�do com sucesso";
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel incluir o registro" . ". Erro: " . $e->getMessage();
		}
		mostraTemplate($banco, array() , $mensagem, $codigo, $operacao);
	}
	else if (strcasecmp($operacao, Constantes::EDITAR) == 0) {
		try {
			$mensagem = null;
			$resultados = $nothelper->consultar($banco, null, $filtro);
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel consultar o registro" . ". Erro: " . $e->getMessage();
		}
		mostraTemplate($banco, $resultados, $mensagem, $codigo, $operacao);
	}
	else if (strcasecmp($operacao, Constantes::INSERIR) == 0) {
		mostraTemplate($banco, $array, null, $codigo, $operacao);
	}
}

function populaCampos() {
	$camposValores = array();
	$camposValores['cod_usuario'] = $_POST['lstusuarios'];
	$camposValores['titulo'] = $_POST['txttitulo'];
	$camposValores['conteudo'] = $_POST['txtconteudo'];
	$camposValores['habilita'] = $_POST['lsthabilitar'];
	$camposValores['fonte'] = $_POST['txtfonte'];
	//os valores de data e hora variam conforme o ambiente e o banco de dados
	$camposValores['dt_publicacao'] = date("Y-m-d");
	$camposValores['hr_publicacao'] = date("H:i:s");
	return $camposValores;
}

function mostraTemplate(DAOBanco $banco, $resultados, $mensagem = null, $codigo = null, $operacao = null) {
	$usuhelper = new UsuarioHelper();
	$usuarios = array();
	$usucods = array();
	$usunomes = array();
	$opcoeshab = array(Noticia::HABILITA_NAO,Noticia::HABILITA_SIM);
	$opcoeshabnome = array("N�o","Sim");
	$usucodpad = 0;
	$opcoeshabpad = 0;
	$titulo = "";
	$conteudo = "";
	$fonte = "";
	try {
		$usuarios = $usuhelper->consultar($banco, null);
	}
	catch (Exception $e) {
		$mensagem = "N�o foi poss�vel consultar usu�rios" . ". Erro: " . $e->getMessage();
	}
	foreach ($usuarios as $usuario) {
		$usucods[] = $usuario->getCodigo();
		$usunomes[] = $usuario->getNome();
	}
	if (count($resultados) > 0) {
		foreach ($resultados as $noticia) {
			$usuario = $noticia->getUsuario();
			$usucodpad = $usuario->getCodigo();
			$titulo = $noticia->getTitulo();
			$conteudo = $noticia->getConteudo();
			$fonte = $noticia->getFonte();
			$opcoeshabpad = $noticia->getHabilita();
		}
	}
	else {
		if (!is_null($operacao)) {
			$usucodpad = $_POST['lstusuarios'];
			$titulo = $_POST['txttitulo'];
			$conteudo = $_POST['txtconteudo'];
			$fonte = $_POST['txtfonte'];
			$opcoeshabpad = $_POST['lsthabilitar'];
		}
	}
	$smarty = retornaSmarty();
	$smarty->assign("mensagem", $mensagem);
	$smarty->assign("usucods", $usucods);
	$smarty->assign("usunomes", $usunomes);
	$smarty->assign("usucodpad", $usucodpad);
	$smarty->assign("titulo", $titulo);
	$smarty->assign("conteudo", $conteudo);
	$smarty->assign("fonte", $fonte);
	$smarty->assign("opcoeshab", $opcoeshab);
	$smarty->assign("opcoeshabnome", $opcoeshabnome);
	$smarty->assign("opcoeshabpad", $opcoeshabpad);
	$smarty->assign("codigo", $codigo);
	$smarty->assign("operacao", $operacao);
	$smarty->display("cadnoticias.tpl");
}
if (isset($_SESSION[Constantes::OBJETO_USUARIO])) {
	$banco = $_SESSION[BANCO_SESSAO];
	$nothelper = new NoticiaHelper();
	operacao($nothelper, $banco);
}
else {
	header("location:login.php");
}
?>