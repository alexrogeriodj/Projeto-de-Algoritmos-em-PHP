<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once ('classes/Loader.class.php');
require_once ('includes/retornasmarty.inc.php');
require_once ('includes/confconexao.inc.php');
require_once ('includes/retornaconexao.inc.php');
session_start();

function operacao(NoticiaHelper $nothelper, DAOBanco $banco) {
	$operacao = "";
	$codigo = 0;
	if (isset($_GET['operacao'])) {
		$operacao = $_GET['operacao'];
	}
	else if (isset($_POST['operacao'])) {
		$operacao = $_POST['operacao'];
	}
	if (isset($_GET['codigo'])) {
		$codigo = $_GET['codigo'];
	}
	else if (isset($_POST['codigo'])) {
		$codigo = $_POST['codigo'];
	}
	if (strcasecmp($operacao, Constantes::EXCLUIR) == 0) {
		$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_IGUAL, array("cod_noticia" => $codigo));
		try {
			$nothelper->excluir($banco, $filtro);
			$mensagem = "Registro: " . $codigo . " exclu�do com sucesso";
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel excluir o registro: " . $codigo . ". Erro: " . $e->getMessage();
		}
		mostraTemplate($nothelper, $banco, $mensagem);
	}
	else if (strcasecmp($operacao, Constantes::CONSULTAR) == 0) {
		if (strcasecmp($_POST['lstcampo'], "cod_noticia") == 0) {
			$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_IGUAL, array("cod_noticia" => $_POST['edtpesquisa']));
			$resultados = array();
			try {
				$resultados = $nothelper->consultar($banco, null, $filtro);
			}
			catch (Exception $e) {
				$mensagem = "N�o foi poss�vel consultar not�cia " . ". Erro: " . $e->getMessage();
			}
			mostraTemplate($nothelper, $banco, $mensagem, $resultados);
		}
		else if (strcasecmp($_POST['lstcampo'], "titulo") == 0) {
			$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_CONTEM, array("titulo" => $_POST['edtpesquisa']));
			$resultados = array();
			try {
				$resultados = $nothelper->consultar($banco, null, $filtro);
			}
			catch (Exception $e) {
				$mensagem = "N�o foi poss�vel consultar not�cia " . ". Erro: " . $e->getMessage();
			}
			mostraTemplate($nothelper, $banco, $mensagem, $resultados);
		}
		else {
		$resultados = array();
			try {
				$resultados = $nothelper->consultar($banco, null);
			}
			catch (Exception $e) {
				$mensagem = "N�o foi poss�vel consultar not�cia " . ". Erro: " . $e->getMessage();
			}
			mostraTemplate($nothelper, $banco, $mensagem, $resultados);
		}
	}
	else {
		mostraTemplate($nothelper, $banco);
	}
}

function mostraTemplate(NoticiaHelper $nothelper, DAOBanco $banco, $mensagem = null, $resultados = null) {
	$codigos = array();
	$titulos = array();
	$habnoticias = array();
	$links_excluir = array();
	$links_editar = array();
	$cor_linha = array('#D0D0D0','#FFFFFF');
	$campesquisa = array("vazio","cod_noticia","titulo");
	$campesqdescr = array("","C�digo","T�tulo");
	$link_incluir = "cadnoticias.php?operacao=" . Constantes::INSERIR;
	$link_consultar = "admnoticias.php?operacao=" . Constantes::CONSULTAR;
	$campadrao = 0;
	if (is_null($resultados)) {
		try {
			$resultados = $nothelper->consultar($banco, null);
		}
		catch (Exception $e) {
			$mensagem = "N�o foi consultar registros de not�cias" . ". Erro: " . $e->getMessage();
		}
	}
	$mensagemtot = "total de registros: " . count($resultados);
	$mensagemexc = "Confirma excluir not�cia c�digo: ";
	foreach ($resultados as $noticia) {
		$codigos[] = $noticia->getCodigo();
		$titulos[] = $noticia->getTitulo();
		$habnoticias[] = $noticia->getHabilita();
		$links_editar[] = "cadnoticias.php?operacao=" . Constantes::EDITAR . "&" . "codigo=" . $noticia->getCodigo();
		$links_excluir[] = $_SERVER['PHP_SELF'] . "?operacao=" . Constantes::EXCLUIR . "&" . "codigo=" . $noticia->getCodigo();
	}
	$smarty = retornaSmarty();
	$smarty->assign("mensagem", $mensagem);
	$smarty->assign("mensagemtot", $mensagemtot);
	$smarty->assign("mensagemexc", $mensagemexc);
	$smarty->assign("codigos", $codigos);
	$smarty->assign("titulos", $titulos);
	$smarty->assign("habnoticias", $habnoticias);
	$smarty->assign("links_editar", $links_editar);
	$smarty->assign("links_excluir", $links_excluir);
	$smarty->assign("link_incluir", $link_incluir);
	$smarty->assign("link_consultar", $link_consultar);
	$smarty->assign("cor_linha", $cor_linha);
	$smarty->assign("campesquisa", $campesquisa);
	$smarty->assign("campesqdescr", $campesqdescr);
	$smarty->assign("campadrao", $campadrao);
	$smarty->display("admnoticias.tpl");
}
if (isset($_SESSION[Constantes::OBJETO_USUARIO])) {
	$banco = $_SESSION[BANCO_SESSAO];
	$nothelper = new NoticiaHelper();
	operacao($nothelper, $banco);
}
else {
	header("location:login.php");
}
?>