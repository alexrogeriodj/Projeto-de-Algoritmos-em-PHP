<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once ('Loader.class.php');

class NoticiaDAOPersistivel extends DAOPersistivel {
	const NOME_TABELA = "CMS_NOTICIA";
	
	public function __construct() {
		parent::__construct(NoticiaDAOPersistivel::NOME_TABELA);
	}
	
	public function incluir(DAOBanco $banco, $camposValores) {
		return parent::incluir($banco, $camposValores);
	}
	
	public function alterar(DAOBanco $banco, $camposValores, FiltroSQL $filtro = null) {
		return parent::alterar($banco, $camposValores, $filtro);
	}
	
	public function excluir(DAOBanco $banco, FiltroSQL $filtro = null) {
		return parent::excluir($banco, $filtro);
	}
	public function consultar(DAOBanco $banco, $campos, FiltroSQL $filtro = null) {
		$resultados = array();
		$resultados = parent::consultar($banco, $campos, $filtro);
		return $this->criaObjetos($resultados);
	}
	
	public function criaObjetos($resultados) {
		$resultnoticias = array();
		foreach ($resultados as $linha) {
			$noticia = new Noticia();
			foreach ($linha as $campo => $valor) {
				if (strcasecmp($campo, "cod_noticia") == 0) {
					$noticia->setCodigo($valor);
				}
				elseif (strcasecmp($campo, "cod_usuario") == 0) {
					$usuario = new Usuario();
					$usuario->setCodigo($valor);
					$noticia->setUsuario($usuario);
				}
				elseif (strcasecmp($campo, "titulo") == 0) {
					$noticia->setTitulo($valor);
				}
				elseif (strcasecmp($campo, "conteudo") == 0) {
					$noticia->setConteudo($valor);
				}
				elseif (strcasecmp($campo, "habilita") == 0) {
					$noticia->setHabilita($valor);
				}
				elseif (strcasecmp($campo, "fonte") == 0) {
					$noticia->setFonte($valor);
				}
				elseif (strcasecmp($campo, "dt_publicacao") == 0) {
					$noticia->setData($valor);
				}
				elseif (strcasecmp($campo, "hr_publicacao") == 0) {
					$noticia->setHora($valor);
				}
			}
			$resultnoticias[] = $noticia;
		}
		return $resultnoticias;
	}
}
?>