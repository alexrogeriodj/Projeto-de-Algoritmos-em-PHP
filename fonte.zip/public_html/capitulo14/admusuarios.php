<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once ('classes/Loader.class.php');
require_once ('includes/retornasmarty.inc.php');
require_once ('includes/confconexao.inc.php');
require_once ('includes/retornaconexao.inc.php');
session_start();

function operacao(UsuarioHelper $usuhelper, DAOBanco $banco) {
	$operacao = "";
	$codigo = 0;
	if (isset($_GET['operacao'])) {
		$operacao = $_GET['operacao'];
	}
	else if (isset($_POST['operacao'])) {
		$operacao = $_POST['operacao'];
	}
	if (isset($_GET['codigo'])) {
		$codigo = $_GET['codigo'];
	}
	else if (isset($_POST['codigo'])) {
		$codigo = $_POST['codigo'];
	}
	if (strcasecmp($operacao, Constantes::EXCLUIR) == 0) {
		$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_IGUAL, array(
			"cod_usuario" => $codigo
		));
		try {
			$usuhelper->excluir($banco, $filtro);
			$mensagem = "Registro: " . $codigo . " exclu�do com sucesso";
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel excluir o registro: " . $codigo . ". Erro: " . $e->getMessage();
		}
		mostraTemplate($usuhelper, $banco, $mensagem);
	}
	else if (strcasecmp($operacao, Constantes::CONSULTAR) == 0) {
		 if (strcasecmp($_POST['lstcampo'], "cod_usuario") == 0) {
			$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_IGUAL, array("cod_usuario" => $_POST['edtpesquisa']));
			$resultados = array();
			try {
				$resultados = $usuhelper->consultar($banco, null, $filtro);
			}
			catch (Exception $e) {
				$mensagem = "N�o foi poss�vel consultar usu�rio " . ". Erro: " . $e->getMessage();
			}
			mostraTemplate($usuhelper, $banco, $mensagem, $resultados);
		}
		else if (strcasecmp($_POST['lstcampo'], "nome") == 0) {
			$filtro = new FiltroSQL(FiltroSQL::CONECTOR_E, FiltroSQL::OPERADOR_CONTEM, array("nome" => $_POST['edtpesquisa']));
			$resultados = array();
			try {
				$resultados = $usuhelper->consultar($banco, null, $filtro);
			}
			catch (Exception $e) {
				$mensagem = "N�o foi poss�vel consultar not�cia " . ". Erro: " . $e->getMessage();
			}
			mostraTemplate($usuhelper, $banco, $mensagem, $resultados);
		}
		else {
			$resultados = array();
			try {
				$resultados = $usuhelper->consultar($banco, null);
			}
			catch (Exception $e) {
				$mensagem = "N�o foi poss�vel consultar not�cia " . ". Erro: " . $e->getMessage();
			}
			mostraTemplate($usuhelper, $banco, $mensagem, $resultados);
		}
	}
	else {
		mostraTemplate($usuhelper, $banco);
	}
}

function mostraTemplate(UsuarioHelper $usuhelper, DAOBanco $banco, $mensagem = null, $resultados = null) {
	$codigos = array();
	$nomes = array();
	$links_excluir = array();
	$links_editar = array();
	$cor_linha = array('#D0D0D0','#FFFFFF');
	$campesquisa = array("vazio","cod_usuario","nome");
	$campesqdescr = array("","C�digo","Nome");
	$link_incluir = "cadusuarios.php?operacao=" . Constantes::INSERIR;
	$link_consultar = "admusuarios.php?operacao=" . Constantes::CONSULTAR;
	$campadrao = 0;
	if (is_null($resultados)) {
		try {
			$resultados = $usuhelper->consultar($banco, null);
		}
		catch (Exception $e) {
			$mensagem = "N�o foi poss�vel consultar registros de usu�rios" . ". Erro: " . $e->getMessage();
		}
	}
	$mensagemtot = "total de registros: " . count($resultados);
	$mensagemexc = "Ao excluir este usu�rio se este tiver not�cias ";
	$mensagemexc.= "cadastradas estas tamb�m ir�o ser exclu�das. Confirma exclus�o c�digo: ";
	foreach ($resultados as $usuario) {
		$codigos[] = $usuario->getCodigo();
		$nomes[] = $usuario->getNome();
		$links_editar[] = "cadusuarios.php?operacao=" . Constantes::EDITAR . "&" . "codigo=" . $usuario->getCodigo();
		$links_excluir[] = $_SERVER['PHP_SELF'] . "?operacao=" . Constantes::EXCLUIR . "&" . "codigo=" . $usuario->getCodigo();
	}
	$smarty = retornaSmarty();
	$smarty->assign("mensagem", $mensagem);
	$smarty->assign("mensagemtot", $mensagemtot);
	$smarty->assign("mensagemexc", $mensagemexc);
	$smarty->assign("codigos", $codigos);
	$smarty->assign("nomes", $nomes);
	$smarty->assign("links_editar", $links_editar);
	$smarty->assign("links_excluir", $links_excluir);
	$smarty->assign("link_incluir", $link_incluir);
	$smarty->assign("link_consultar", $link_consultar);
	$smarty->assign("cor_linha", $cor_linha);
	$smarty->assign("campesquisa", $campesquisa);
	$smarty->assign("campesqdescr", $campesqdescr);
	$smarty->assign("campadrao", $campadrao);
	$smarty->display("admusuarios.tpl");
}
if (isset($_SESSION[Constantes::OBJETO_USUARIO])) {
	$banco = $_SESSION[BANCO_SESSAO];
	$usuhelper = new UsuarioHelper();
	operacao($usuhelper, $banco);
}
else {
	header("location:login.php");
}
?>