CREATE TABLE `cms`.`cms_usuario` (
	`cod_usuario` int(10) unsigned NOT NULL auto_increment,
	`nome` varchar(60) NOT NULL default '',
	`email` varchar(100) NOT NULL default '',
	`login` varchar(10) NOT NULL default '',
	`senha` varchar(15) NOT NULL default '',
	PRIMARY KEY (`cod_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE  `cms`.`cms_noticia` (
	`cod_noticia` int(10) unsigned NOT NULL auto_increment,
	`cod_usuario` int(10) unsigned NOT NULL,
	`titulo` text NOT NULL,
	`conteudo` longtext NOT NULL,
	`habilita` char(1) NOT NULL default 'N',
	`fonte` text,
	`dt_publicacao` date NOT NULL default '0000-00-00',
	`hr_publicacao` time NOT NULL default '00:00:00',
	PRIMARY KEY (`cod_noticia`),
	CONSTRAINT `fk1_cms_noticia` FOREIGN KEY (`cod_usuario`)
	REFERENCES `cms_usuario` (`cod_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

insert into cms_usuario (cod_usuario, nome, email, login, senha)
values (1, 'Administrador', 'admin@admin.cms', 'admin', 'admin');
