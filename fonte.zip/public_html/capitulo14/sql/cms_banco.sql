CREATE USER 'cms'@'localhost' IDENTIFIED BY 'cms';
CREATE DATABASE `cms`;
GRANT ALL PRIVILEGES ON `cms`.* TO 'cms'@'localhost';
