<?php
/**
 * C�digo-fonte do livro "PHP Profissional"
 * Autores: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons, 
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor, 
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "PHP Profissional" book
 * Authors: Alexandre Altair de Melo <alexandre@phpsc.com.br>
 *          Mauricio G. F. Nascimento <mauricio@prophp.com.br>
 *
 * http://www.novatec.com.br/livros/phppro
 * ISBN: 978-85-7522-141-9
 * Editora Novatec, 2008 - all rights reserved
 *
 * LICENSE: This source file is subject to Attibution version 2.5 Brazil of the Creative Commons 
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please 
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
 
require_once('Smarty.class.php');
$template = new Smarty();
$template->template_dir = '../../tpl';
$template->compile_dir = '../../tplc';
$template->cache_dir = '../../tplcache';
$template->caching = 1;

//Not�cias lidas a partir do banco de dados
$noticias = array(	10 => '2818c426f619afa4f84f3e4a9510f82b',
					20 => '0653047a4f48ff348fa6d5b4618cd7ac',
					30 => 'c2b958bb99e07021a18e2a755c8ae54b',
					40 => '5085aaf24961c3f9be12a978e4638bbb',
					50 => 'a6c73db3813afbd77daeafb2ec879f03');

//qual a not�cia foi selecionada?
$id = isset($_GET['id']) ? $_GET['id'] : 0;
if ($id)
	$template->assign('selecao', $id);
	
if (isset($_GET['clear']))
	$template->clear_cache('cache4.tpl', $_GET['clear']);

else if (isset($_GET['clear_all']))
	$template->clear_all_cache('cache4.tpl');
	
$template->assign('noticias', $noticias);
$template->display('cache4.tpl', $id);
?>
